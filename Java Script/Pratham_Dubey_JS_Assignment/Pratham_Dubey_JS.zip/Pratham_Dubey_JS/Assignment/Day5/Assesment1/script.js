function $(id){
    return document.getElementById(id);
}

$("add-button").onclick = function(){
    if($("item-input").value!=""){
        var ul = document.createElement("ul");
        ul.id = "ul_list";
        var li = document.createElement("li");
        li.id = `li${ul.childElementCount+1}`
        
        li.textContent = $("item-input").value;
        ul.appendChild(li);
        $("items-container").appendChild(ul);

        var remButton = document.createElement("button");
        remButton.textContent="Remove";
        
        li.style.display="flex";
        li.style.justifyContent="space-between";
        
        li.appendChild(remButton);
        remButton.onclick=function(){
            this.parentElement.remove();
        }
        var mark = document.createElement("button");
        mark.textContent = "Mark Purchase";
        li.appendChild(mark);
        
        mark.onclick = function(){
            if(mark.textContent === "Mark Purchase"){
                this.parentElement.style.textDecoration ="line-through";
                this.parentElement.style.color ="#888";
                this.textContent = "Purchased";
                
            }
            else{
                this.parentElement.style.textDecoration ="none";
                this.parentElement.style.color ="black";
                this.textContent = "Mark Purchase";

            }
        }
    }
    $("item-input").value = "";
}

