// Assignment 5: Parallel Execution
// Execute multiple asynchronous operations in parallel using `Promise.all`.


// Assignment 4: Chaining Async Functions
// Chain multiple async functions together.

// Instructions: 
// 1. Create two async functions, `fetchPosts` and `fetchComments`.
// 2. In `fetchPosts`, use the `fetch` API to get posts from `https://jsonplaceholder.typicode.com/posts`.
// 3. In `fetchComments`, use the `fetch` API to get comments for a specific post from `https://jsonplaceholder.typicode.com/comments?postId=1`.
// 4. Create a third async function named `fetchAllData` that uses `await` to call both `fetchPosts` and `fetchComments`.
// 5. Log the combined data from both functions to the console.
// 6. Call `fetchAllData` and observe the output.


async function  fetchPosts(){
    const data = await fetch('https://jsonplaceholder.typicode.com/posts');
    const res = await data.json();
    return res;
}

async function fetchComments(){
    const data = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1');
    const res = await data.json();
    return res;
}



async function fetchAllData(){
    const res = await Promise.all([fetchPosts(),fetchComments()]);
    console.log(res);
}

fetchAllData();