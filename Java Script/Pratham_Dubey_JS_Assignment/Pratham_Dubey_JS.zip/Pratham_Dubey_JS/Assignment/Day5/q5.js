// Assignment 1: Basic Async/Await

// Understand how to use async/await with simple functions.

// Instructions:

// 1. Create an async function named `fetchData`.

// 2. Inside the function, use `setTimeout` to simulate fetching data from a server. Use `await` to wait for 2 seconds.

// 3. After 2 seconds, log a message to the console saying, "Data fetched!".

// 4. Call the `fetchData` function and observe the output.

async function fetchData(){
    await setTimeout(()=>{
        console.log("Data Fetched");
        return 'Data fetched'
    },2000)
}   
fetchData()

