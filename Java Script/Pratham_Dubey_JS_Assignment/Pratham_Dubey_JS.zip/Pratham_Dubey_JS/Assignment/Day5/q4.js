// Assignment 4: Using `Promise.all()`

// Create multiple promises and use `Promise.all()` to wait for all of them to complete.

// Instructions:

// 1. Create three functions `taskA()`, `taskB()`, and `taskC()` that return promises.

// 2. Each function should resolve after a certain time with a specific message.

// 3. Use `Promise.all()` to execute these tasks concurrently and log the results once all tasks are complete.

function taskA(){
    return new Promise((resolve,reject) =>{
        setTimeout(()=>{
            resolve('Executed in 1000ms');
        },1000);
    })
}

function taskB(){
    return new Promise((resolve,reject) =>{
        setTimeout(()=>{
            resolve('Executed in 2000ms');
        },2000);
    })
}

function taskC(){
    return new Promise((resolve,reject) =>{
        setTimeout(()=>{
            resolve('Executed in 3000ms');
        },3000);
    })
}

Promise.all([taskA(),taskB(),taskC()]).then((res)=>{
    console.log(res);
})