// creating crud 

async function getPosts() {
    try {
        const url = 'https://jsonplaceholder.typicode.com/posts';
        const response = await fetch(url);
        if (response.ok) {
            const posts = await response.json();
            console.log('Posts:', posts);
        } else {
            console.error('Error fetching posts.');
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}

async function createPost() {
    try {
        const url = 'https://jsonplaceholder.typicode.com/posts';
        const data = {
            userId: 1,
            title: 'New Post',
            body: 'This is a new post.',
        };
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        if (response.ok) {
            const newPost = await response.json();
            console.log('New Post:', newPost);
        } else {
            console.error('Error creating post.');
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}

async function deletePost() {
    try {
        const postId = 1; // Replace with the actual post ID to delete
        const url = `https://jsonplaceholder.typicode.com/posts/${postId}`;
        const response = await fetch(url, {
            method: 'DELETE',
        });
        if (response.ok) {
            console.log(`Post with ID ${postId} deleted successfully.`);
        } else {
            console.error(`Error deleting post with ID ${postId}.`);
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}

async function updatePost() {
    try {
        const postId = 1; // Replace with the actual post ID to update
        const url = `https://jsonplaceholder.typicode.com/posts/${postId}`;
        const data = {
            title: 'Updated Post',
            body: 'This post has been updated.',
        };
        const response = await fetch(url, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        if (response.ok) {
            const updatedPost = await response.json();
            console.log('Updated Post:', updatedPost);
        } else {
            console.error(`Error updating post with ID ${postId}.`);
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}


