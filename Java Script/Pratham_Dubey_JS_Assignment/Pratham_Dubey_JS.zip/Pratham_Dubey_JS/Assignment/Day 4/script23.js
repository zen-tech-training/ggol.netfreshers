// script.js

async function fetchListOfItems() {
    try {
      const url = 'https://jsonplaceholder.typicode.com/posts';
      const response = await fetch(url);
  
      if (response.ok) {
        const items = await response.json();
        const itemList = document.getElementById('itemList');
  
        // Clear existing list items
        itemList.innerHTML = '';
  
        // Create list items for each item
        items.forEach((item) => {
          const li = document.createElement('li');
          li.textContent = item.title;
          itemList.appendChild(li);
        });
      } else {
        document.getElementById('itemList').textContent = 'Error fetching items.';
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  }

