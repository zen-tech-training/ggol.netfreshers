async function makePostRequest() {
    try {
      const url = 'https://jsonplaceholder.typicode.com/posts';
      const data = {
        userId: 1,
        id: 101,
        title: 'Sample Post',
        body: 'This is a sample post request.',
      };
  
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
  
      if (response.ok) {
        const jsonResponse = await response.json();
        document.getElementById('postResponse').textContent = JSON.stringify(jsonResponse, null, 2);
      } else {
        document.getElementById('postResponse').textContent = 'Error making the request.';
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  }

