var parentUL = $('todoList');
        function $(id){
            return document.getElementById(id);
        }
        var lis = []
        var removeButton = []
        var count = 0;
        $('addButton').onclick = function(){
            if($('newTodo').value){
                count++;
                lis = document.createElement('li');
                lis.innerHTML += $('newTodo').value;
                lis.style.backgroundColor = "white";
                lis.style.border = "1px solid black";
                lis.style.borderRadius ="10px";
                lis.id = `li${count}`;
                
                
                removeButton = document.createElement('button');
                removeButton.id= `removeButton${count}`;
                removeButton.innerHTML += "Remove";
                removeButton.name = `btnName`;
                removeButton.onclick = function() {
                    this.parentElement.remove();
                }
                

                lis.appendChild(removeButton);
                parentUL.appendChild(lis);
                document.getElementById('newTodo').value="";
            }
        }
        