async function fetchPosts() {
  try {
    const res = await fetch("https://jsonplaceholder.typicode.com/posts");
    const data = await res.json();
    return data;
  } catch (error) {
    console.error(error);
  }
}

async function fetchComments() {
  try {
    const res = await fetch(
      "https://jsonplaceholder.typicode.com/comments?postId=1"
    );
    const data = await res.json();
    return data;
  } catch (error) {
    console.error(error);
  }
}

async function fetchAllData() {
  try {
    const res1 = await fetchPosts();
    const res2 = await fetchComments();
    console.log("Result for Posts API:" , res1);
    console.log("\n\nResult for Comments API:" , res2);
  } catch (error) {
    console.error(error);
  }
}

fetchAllData();
