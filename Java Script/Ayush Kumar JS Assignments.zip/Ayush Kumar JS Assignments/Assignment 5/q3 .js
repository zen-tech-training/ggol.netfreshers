const errorProneTask = new Promise((resolve,reject) =>{
    // Resolve the promise after 1 second
    // setTimeout(() => resolve("Task 1 successful."),1000);
    setTimeout(() => reject("Task 1 failed."),1000);
});


errorProneTask.then((res)=>{
    console.log("Resolved: "+res);
}).catch((err)=>{
    console.error("Rejected: "+err);
})