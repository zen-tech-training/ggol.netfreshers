const taskA = new Promise((resolve,reject) =>{
    setTimeout(resolve,1000,'Task A completed within 1 sec.');
});
const taskB = new Promise((resolve,reject) =>{
    setTimeout(resolve,3000,'Task B completed within 3 sec.');
});
const taskC = new Promise((resolve,reject) =>{
    setTimeout(resolve,2000,'Task C completed within 2 sec.');
});

Promise.all([taskA, taskB, taskC])
.then((values) =>{
    console.log(values);
})
.catch(err =>{
    console.error('Error '+err);
})
