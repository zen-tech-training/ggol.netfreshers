
const task1 = new Promise((resolve,reject) =>{
    // Resolve the promise after 1 second
    setTimeout(() => resolve("Task 1 completed."),1000);
});
const task2 = new Promise((resolve,reject) =>{
    // Resolve the promise after 1 second
    setTimeout(() => resolve("Task 2 completed."),1000);
});
const task3 = new Promise((resolve,reject) =>{
    // Resolve the promise after 1 second
    setTimeout(() => resolve("Task 3 completed."),1000);
});


task1.then((res)=>{
    console.log(res);
    return task2;
}).then((res)=>{
    console.log(res);
    return task3;
}).then((res)=>{
    console.log(res);
}).catch((err)=>console.error(err));