async function fetchPosts() {
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/posts");
      const data = await res.json();
      return data;
    } catch (error) {
      console.error(error);
    }
  }
  
  async function fetchComments() {
    try {
      const res = await fetch(
        "https://jsonplaceholder.typicode.com/comments?postId=1"
      );
      const data = await res.json();
      return data;
    } catch (error) {
      console.error(error);
    }
  }
  
  async function fetchAllData() {
    try {
        Promise.all([fetchPosts(),fetchComments()])
        .then((values) =>{
            console.log(values);
        })
        .catch(err =>{
            console.error('Error '+err);
        })
    } catch (error) {
      console.error(error);
    }
  }
  
  fetchAllData();
  