async function getUserData(){
    try {
        const data = await fetch("https://jsonplaceholder.typicode.com/users/1");
        console.log(await data.json());
    } catch (error) {
        console.error(error);
    }
}
getUserData();