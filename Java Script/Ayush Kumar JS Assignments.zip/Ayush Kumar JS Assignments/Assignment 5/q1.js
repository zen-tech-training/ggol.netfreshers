function waitTime(time){
    return new Promise((resolve,reject) =>{
        // resolve(setTimeout(function (){console.log("Logged after "+time+" ms.")}, time)); // Problem
        // setTimeout(resolve, time, "Logged after "+time+" ms.");  // Works
        setTimeout(()=>{                                      // Works
            console.log("Logged after "+time+" ms.");
            resolve("Success");
        })
    });
}
    
waitTime(1000).then((res)=>{
    console.log(res);
}).catch((err)=>console.error(err));

waitTime(2000).then((res)=>{
    console.log(res);
}).catch((err)=>console.error(err));

waitTime(3000).then((res)=>{
    console.log(res);
}).catch((err)=>console.error(err));





// function waitTime(time){
//     return new Promise((resolve,reject) =>{
//         // resolve(setTimeout(function (){console.log("Logged after "+time+" ms.")}, time));
//         setTimeout(resolve, time, console.log("Logged after "+time+" ms."));
//     });
// }
    
// waitTime(1000).then(()=>{
//     console.log("Success.");
// }).catch((err)=>console.error(err));

// waitTime(2000).then(()=>{
//     console.log("Success.");
// }).catch((err)=>console.error(err));

// waitTime(3000).then(()=>{
//     console.log("Success.");
// }).catch((err)=>console.error(err));