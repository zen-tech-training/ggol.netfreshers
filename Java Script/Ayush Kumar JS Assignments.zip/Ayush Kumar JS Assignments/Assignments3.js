// Javascript Function Overloading


// Q1 
const someObj = {
    // twoArguments
    twoArgument:function(arg1,arg2){
        return arg1 + arg2;
    },
    // threeArguments
    threeArgument:function(arg1,arg2,arg3){
        return arg1 + arg2 + arg3;
    },
    // fourArguments
    fourArgument:function(arg1,arg2,arg3,arg4){
        return arg1 + arg2 + arg3 + arg4;
    },

    overloadedFun:function(){
        if(arguments.length === 2){
            return this.twoArgument(arguments[0], arguments[1]);
        }else if(arguments.length === 3){
            return this.threeArgument(arguments[0] , arguments[1], arguments[2]);
        }else if(arguments.length === 4){
            return this.fourArgument(arguments[0],arguments[1],arguments[2], arguments[3]);
        }
    }
}

console.log(someObj.overloadedFun(1,2));
console.log(someObj.overloadedFun(1,2,3));
console.log(someObj.overloadedFun(1,2,3,4));

// Q2
const someObj1 = {
    twoNumbers:function(arg1,arg2){
        return "The two numbers are "+arg1+" "+arg2; 
    },
    threeNumbers:function(arg1,arg2,arg3){
        return "The three numbers are "+arg1+" "+arg2+" "+arg3; 
    },
    twoStrings:function(arg1,arg2){
        return "Two strings are "+arg1 + " and " +arg2;
    },
    oneStringOneNum:function(arg1,arg2){
        return "One string and one number are "+arg1+ " and "+ arg2;
    },

    overloadedFun:function(){
        var str = 0, num =0;
        for(var i in arguments){
            if(typeof(arguments[i]) == 'string')
                str++;
            else if(typeof(arguments[i]) == 'number')
                num++;
        }
        if(arguments.length === 2 && num === 2){
            return this.twoNumbers(arguments[0], arguments[1]);
        }else if(arguments.length === 3 && num === 3){
            return this.threeNumbers(arguments[0] , arguments[1], arguments[2]);
        }else if(arguments.length === 2 && str === 2){
            return this.twoStrings(arguments[0], arguments[1]);
        }else if(arguments.length === 2 && str === 1 && num === 1){
            return this.oneStringOneNum(arguments[0], arguments[1]);
        }else {
            return "No similar case found.";
        }
    }
}

console.log(someObj1.overloadedFun(1,2));
console.log(someObj1.overloadedFun(1,2,3));
console.log(someObj1.overloadedFun(1,"hello"));
console.log(someObj1.overloadedFun("world","hello"));

// Q3

function Human(name){
    this.name = name;
}
Human.prototype.speak = function(){
    return "Humans speak.";
}
Human.prototype.introduction = function(){
    return "Hi, I'm a human.";
}

function Student(college, course){
    this.college = college;
    this.course = course;
}
var objHuman = Object.create(Human.prototype);
Object.setPrototypeOf(Student, objHuman);
Student.prototype.constructor = Student;
Student.prototype.introduction = function(){
    return "Hi, I'm a student of"+this.college+", and am enrolled in "+this.courses+".";
}

// Q4

function Person(name){
    this.name = name;
}
var personObj = Object.create(Person.prototype);
Object.setPrototypeOf(Developer, personObj);
Developer.prototype.constructor = Developer;
function Developer(name, lang){
    Person.call(this, name);
    this.lang = lang;
}

var devObj = new Developer("Ayush", "CPP");
console.log(devObj.__proto__);
console.log(Developer.prototype);
console.log(devObj.__proto__.__proto__);
console.log(Object.getPrototypeOf(Developer));
console.log(Object.getPrototypeOf(Person));

// Q5
let shoppingCart = (function(){
 
    var products = [];
    return {
        addItem:function(productId, name, price, quantity){
            if(products.find((product)=> product.productId === productId)){
                console.log("Item exists");
                return;
            }
            const product = {
                productId,
                name,
                price,
                quantity
            }
            products.push(product);
        },
        id:function(id,quantity){
            const product = products.find((product) => product.productId === id);
            if(product){
                product.quantity += quantity;
            }else{
                console.log("Id doesn't exist");
            }
        },
        removeItem : function(id){
            products = products.filter((product) => product.productId !== id)
            console.log("Item deleted Successfully");
        },
        getAllItems:function(){
            for(let product of products){
                console.log(`Product Id: ${product.productId} Name:${product.name},price:${product.price} quantity:${product.quantity}`)
            }
        },
 
        getTotalPrice:function(){
            let totalPrice = 0;
            for(let product of products){
                totalPrice += product.price*product.quantity;
            }
            console.log("Price of Product: ",totalPrice);
        }
 
    }
 
})();
 
shoppingCart.addItem(1,'egg',5,5);
shoppingCart.addItem(2,'bread',2,1);
shoppingCart.getAllItems()
shoppingCart.getTotalPrice()
shoppingCart.removeItem(2)
shoppingCart.getAllItems()

// Q6

function Vehicle(make, model) {
    this.make = make;
    this.model = model;
  }
   
  Car.prototype = new Vehicle();
  Car.prototype.constructor = Car;
   
  function Car(make, model) {
    Vehicle.call(this,make,model) ;
    this.wheels = 4;
  }
   
  Bike.prototype = new Vehicle();
  Bike.prototype.constructor = Bike;
   
   
  function Bike(make, model) {
      Vehicle.call(this,make,model);
    this.wheels = 2;
  }
   
  const car = new Car('KIA','SELTOS');
  const bike = new Bike('TVS','Apache');
   
  console.log("The Type of Car  is : ",typeof car);
  console.log("The Type of Bike  is : ",typeof bike);
   
  if(car instanceof Car){
      console.log("Instance of Car object : Car");
  }else if(car instanceof Bike){
      console.log("Instance of Car object : Bike");
  }else if(car instanceof Vehicle){
      console.log("Instance of Car object : Vehicle");
  }
   
   
  if(bike instanceof Car){
      console.log("Instance of bike object : Car");
  }else if(bike instanceof Bike){
      console.log("Instance of bike object : Bike");
  }else if(bike instanceof Vehicle){
      console.log("Instance of bike object : Vehicle");
  }
   
  if(car.constructor === Car){
      console.log("CarObject.constructor property pointing to : Car");
  }else if(car.constructor === Bike){
      console.log("CarObject.constructor property pointing to : Bike");
  }else if(car.constructor === Vehicle){
      console.log("CarObject.constructor property pointing to : Vehicle");
  }
   
   
  if(bike.constructor === Car){
      console.log("BikeObject.constructor property pointing to : Car");
  }else if(bike.constructor === Bike){
      console.log("BikeObject.constructor property pointing to : Bike");
  }else if(bike.constructor === Vehicle){
      console.log("BikeObject.constructor property pointing to : Vehicle");
  }
   
  console.log(Object.getPrototypeOf(car) === Car.prototype)
  console.log(Object.getPrototypeOf(bike) === Bike.prototype)