const input = document.getElementById('todokInput');
const addButton = document.getElementById('addTodoButton');
const todoList = document.getElementById('todoList');

function handleRemoveButton() {
    const removeButton = document.createElement('button');
    removeButton.innerHTML = '❌';
    removeButton.classList.add('removeButton');
    return removeButton;
}

function handleCompleteButton() {
    const completeButton = document.createElement('button');
    completeButton.innerHTML = '✔️';
    completeButton.classList.add(`completeButton`);
    return completeButton;
}

// Function to add a new to-do
function addTodo() {
    const todoText = input.value.trim();
    // console.log(todoText);

    if (todoText !== '') {
        // Create elements
        const masterdiv = document.createElement(`div`);
        masterdiv.classList.add('masterdiv');

        const leftDiv = document.createElement(`div`);
        leftDiv.classList.add('leftDiv');
        leftDiv.textContent = todoText;

        const rightDiv = document.createElement(`div`);
        rightDiv.classList.add('rightDiv');

        const completeButton = handleCompleteButton();
        completeButton.addEventListener(`click`, () => {
            console.log(`task completed`);
            leftDiv.style.textDecoration = "line-through"
        });

        const removeButton = handleRemoveButton();
        removeButton.addEventListener('click', () => {
            // console.log(`delete this task`);
            masterdiv.remove();
        });

        rightDiv.appendChild(completeButton);
        rightDiv.appendChild(removeButton);

        masterdiv.appendChild(leftDiv);
        masterdiv.appendChild(rightDiv);

        todoList.appendChild(masterdiv);

        input.value = '';
    }
}

// Event listener for adding a to-do
addButton.addEventListener('click', addTodo);

// Event listener for pressing the enter key
input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        addTodo();
    }
});

// Focus on input field on page load
document.addEventListener('DOMContentLoaded', function () {
    input.focus();
});
