// 2: Promise Chaining
// Create a series of functions that return promises and chain them together to perform a sequence of async operations.

// Instructions:
// 1. Create three functions `task1() `, `task2()`, and `task3()` that return promises.
// 2. Each function should resolve after a certain time with a specific message (e.g., "Task 1 complete").
// 3. Chain these functions together so they execute in sequence.
// 4. Log each task’s completion message.

function task1(timer) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(`Task 1 resolved after ${timer} milliseconds`);
        }, timer);
    });
}

function task2(timer) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(`Task 2 resolved after ${timer} milliseconds`);
        }, timer);
    });
}

function task3(timer) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(`Task 3 resolved after ${timer} milliseconds`);
        }, timer);
    });
}

task1(2000)
    .then((response) => {
        console.log("Success: ", response);
        return task2(5000);
    })
    .then((response) => {
        console.log("Success: ", response);
        return task3(8000);
    })
    .then((response) => {
        console.log("Success: ", response);
    })
    .catch((error) => {
        console.log("Error: ", error);
    })