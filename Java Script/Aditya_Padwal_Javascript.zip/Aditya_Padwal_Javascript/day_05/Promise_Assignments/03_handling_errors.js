// 3: Handling Errors
// Write a promise that simulates an error condition and handle it using `catch()`.

// Instructions:
// 1. Create a function `errorProneTask()` that returns a promise.
// 2. The promise should randomly either resolve with a success message or reject with an error message.
// 3. Handle both the success and error cases using `then()` and `catch()`.

var errorProneTask = (flag) => {
    return new Promise((resolve, reject) => {
        if(flag >= 0.5) {
            resolve(`Flag greater than 0.5 => ${flag}`);
        } else {
            reject(`Flag value less than 0.5 => ${flag}`);
        }
    });
}

var num = Math.random().toFixed(2);
errorProneTask(num)
    .then((response)=> {
        console.log("Success: ", response);
    }) 
    .catch((error) => {
        console.log("Error: ", error);
    })