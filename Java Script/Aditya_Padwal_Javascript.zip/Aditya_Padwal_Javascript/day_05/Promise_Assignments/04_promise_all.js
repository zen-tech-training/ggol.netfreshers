// Assignment 4: Using `Promise.all()`
// Create multiple promises and use `Promise.all()` to wait for all of them to complete.

// Instructions:
// 1. Create three functions `taskA()`, `taskB()`, and `taskC()` that return promises.
// 2. Each function should resolve after a certain time with a specific message.
// 3. Use `Promise.all()` to execute these tasks concurrently and log the results once all tasks are complete.

var taskA = (timer) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(`taskA resolved after ${timer} milliseconds`);
        }, timer);
    });
}

var taskB = (timer) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(`taskB resolved after ${timer} milliseconds`);
        }, timer);
    });
}

var taskC = (timer) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(`taskC resolved after ${timer} milliseconds`);
        }, timer);
    });
};

Promise.all([taskA(2000), taskB(4000), taskC(6000)])
    .then((response) => {
        console.log("Success");
        console.log(response);
    })
    .catch((error) => {
        console.log("Failure: ", error);
    })



