// Assignment 5: Parallel Execution
// Execute multiple asynchronous operations in parallel using `Promise.all`.
// Instructions:

// 1. Modify the `fetchAllData` function from Assignment 4.
// 2. Instead of awaiting each function one after another, use `Promise.all` to execute `fetchPosts` and `fetchComments` in parallel.
// 3. Log the combined data to the console once both promises are resolved.
// 4. Call `fetchAllData` and observe the output.

async function fetchPosts() {
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/posts`);
        const data = await response.json();
        return data;
    } catch(error) {
        console.log(`Error: `, error);
    }
}

async function fetchComments() {
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/comments?postId=1`);
        const data = await response.json();
        return data;
    } catch(error) {
        console.log(`Error: `, error);
    }
}

async function fetchAllData() {
    const [posts, comments] = await Promise.all([fetchPosts(), fetchComments()]);
    console.log(`Posts retreived successfully: `, posts);
    console.log(`Comments retreived successfully: `, comments);
}
fetchAllData();