// Assignment 2: Handling API Requests
// Use async/await to handle real API requests.

// Instructions:
// 1. Create an async function named `getUserData`. 2. Use the `fetch` API to make a GET request to `https://jsonplaceholder.typicode.com/users/1`.
// 3. Use `await` to wait for the response and convert it to JSON.
// 4. Log the user data to the console.
// 5. Call the `getUserData` function and observe the output.

async function getUserData() {
    const response = await fetch(`https://jsonplaceholder.typicode.com/users/1`);
    console.log(response);
    const data = await response.json();
    console.log(data);
}

getUserData();

// The same code using promises will be as follows

// let fetchData = () => {
//     const response = fetch(`https://jsonplaceholder.typicode.com/users/1`);
//     return response;
// }

// fetchData()
//     .then((response) => {
//         const data = response.json();
//         return data;
//     })
//     .then((data) => {
//         console.log(data);
//     })
//     .catch((error) => {
//         console.log(error);
//     })