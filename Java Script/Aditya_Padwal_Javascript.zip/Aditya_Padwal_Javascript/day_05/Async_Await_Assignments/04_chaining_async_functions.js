// Assignment 4: Chaining Async Functions
// Chain multiple async functions together.

// Instructions:
// 1. Create two async functions, `fetchPosts` and `fetchComments`. 2. In `fetchPosts`, use the `fetch` API to get posts from `https://jsonplaceholder.typicode.com/posts`.
// 3. In `fetchComments`, use the `fetch` API to get comments for a specific post from `https://jsonplaceholder.typicode.com/comments?postId=1`.
// 4. Create a third async function named `fetchAllData` that uses `await` to call both `fetchPosts` and `fetchComments`.
// 5. Log the combined data from both functions to the console.
// 6. Call `fetchAllData` and observe the output.

async function fetchPosts() {
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/posts`);
        const data = await response.json();
        return data;
    } catch(error) {
        console.log(`Error: `, error);
    }
}

async function fetchComments() {
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/comments?postId=1`);
        const data = await response.json();
        return data;
    } catch(error) {
        console.log(`Error: `, error);
    }
}

async function fetchAllData() {
    try {
        const posts = await fetchPosts();
        console.log(`Posts retrived successfull: `, posts);
        const comments = await fetchComments();
        console.log(`Comments retrived successfully: `, comments);
    } catch(error) {
        console.log(`Error: `, error);
    }
}
fetchAllData();