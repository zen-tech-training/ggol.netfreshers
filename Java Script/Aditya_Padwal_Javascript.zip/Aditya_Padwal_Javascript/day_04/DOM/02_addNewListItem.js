function addListItem() {
    // console.log('Adding List Item');

    var newItem = document.createElement("li");
    newItem.innerHTML = `Item 3`;

    var unorderedList = document.getElementById(`myList`);
    unorderedList.appendChild(newItem);
}