function changeColor() {
    console.log("Changing color!");
    document.getElementById('colorBox').style.backgroundColor = "black";
}