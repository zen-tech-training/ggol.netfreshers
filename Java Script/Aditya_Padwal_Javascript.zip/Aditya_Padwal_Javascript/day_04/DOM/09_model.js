function openModal() {
    document.getElementById("myModal").style.display = "block";
    document.getElementById("modalOverlay").style.display = "block";
}

function closeModal() {
    document.getElementById("myModal").style.display = "none";
    document.getElementById("modalOverlay").style.display = "none";
}

// Optional: Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById("myModal");
    const overlay = document.getElementById("modalOverlay");
    if (event.target === overlay) {
        closeModal();
    }
}
