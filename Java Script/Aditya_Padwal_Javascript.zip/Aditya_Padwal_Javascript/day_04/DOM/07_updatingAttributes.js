function changeImage() {
    const imageElement = document.getElementById("myImage");
    const currentSrc = imageElement.src;

    if (currentSrc.includes("image1.jfif")) {
        imageElement.src = "image2.jfif"; 
    } else {
        imageElement.src = "image1.jfif"; 
    }
}
