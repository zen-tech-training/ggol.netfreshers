function validateForm() {
    const emailInput = document.getElementById("email");
    const emailValue = emailInput.value.trim();
    const messageElement = document.getElementById("message");

    // Regular expression to validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailValue === "") {
        messageElement.textContent = "Please enter an email address.";
        emailInput.focus();
        return false;
    } else if (!emailRegex.test(emailValue)) {
        messageElement.textContent = "Please enter a valid email address.";
        emailInput.focus();
        return false;
    } else {
        messageElement.textContent = "Form submitted successfully!";
        return true;
    }
}