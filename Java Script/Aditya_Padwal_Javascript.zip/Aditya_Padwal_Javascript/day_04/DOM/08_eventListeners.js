document.addEventListener("DOMContentLoaded", function () {
    const hoverDiv = document.getElementById("hoverDiv");
    const hoverText = document.getElementById("hoverText");

    hoverDiv.addEventListener("mouseover", function () {
        hoverText.textContent = "Text has been changed!";
    });

    hoverDiv.addEventListener("mouseout", function () {
        hoverText.textContent = "Hover over the box to change this text.";
    });
});
