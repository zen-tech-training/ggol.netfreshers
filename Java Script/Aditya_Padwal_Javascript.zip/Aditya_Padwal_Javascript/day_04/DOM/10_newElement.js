function createNewElement() {
    // Create a new div element
    const newDiv = document.createElement("div");

    // Set its text content
    newDiv.textContent = "Hello, World!";

    // Append the new div to the body
    document.body.appendChild(newDiv);
}
