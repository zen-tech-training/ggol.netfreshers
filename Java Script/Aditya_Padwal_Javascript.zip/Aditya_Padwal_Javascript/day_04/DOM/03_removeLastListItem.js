function removeItem(){
    // need to click twice to remove list item
    // var lastListItem = document.getElementById(`myList`).lastChild;
    // document.getElementById(`myList`).removeChild(lastListItem);

    // need to click only once to remove list item
    var lastListItem = document.getElementById(`myList`).lastElementChild;
    document.getElementById(`myList`).removeChild(lastListItem);
}