function toggleBorderColor() {
    const inputField = document.getElementById("myInput");
    inputField.classList.toggle("active"); // Toggle the 'active' class
}
