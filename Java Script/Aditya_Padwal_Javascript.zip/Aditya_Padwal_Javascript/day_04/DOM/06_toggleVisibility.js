function toggleVisibility() {
    const divElement = document.getElementById("toggleDiv");
    if (divElement.style.display === "none" || divElement.style.display === "") {
        divElement.style.display = "block";
    } else {
        divElement.style.display = "none";
    }
}
