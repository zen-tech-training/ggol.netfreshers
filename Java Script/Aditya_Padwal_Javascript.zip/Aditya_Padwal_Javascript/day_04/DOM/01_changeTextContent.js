// Assignment 1: Changing Text Content
// Write a JavaScript function that changes the text content of a specific HTML element when a button is clicked.

function changeText() {
    var newText =  `Changed Text`
    document.getElementById(`text`).innerHTML = newText;
}