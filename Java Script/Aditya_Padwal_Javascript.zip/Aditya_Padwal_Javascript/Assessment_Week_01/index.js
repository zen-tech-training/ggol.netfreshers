const input = document.getElementById('item-input');
const addButton = document.getElementById('add-button');
const shoppingList = document.getElementById('items-container');

// handling item purchases
function handlePurchaseItem() {
    const completeButton = document.createElement('button');
    completeButton.innerHTML = 'Purchased';
    completeButton.classList.add(`purchaseButton`);
    return completeButton;
}
// removing items from cart
function handleRemoveItem() {
    const removeButton = document.createElement('button');
    removeButton.innerHTML = 'Remove';
    removeButton.classList.add('removeButton');
    return removeButton;
}

// adding items to cart
function addItem() {
    // console.log(`Add Item`);
    const shoppingItem = input.value.trim();
    
    if(shoppingItem !== '') {
        // console.log(shoppingItem);
        const masterdiv = document.createElement(`div`);
        masterdiv.classList.add('item');

        const leftDiv = document.createElement(`div`);
        leftDiv.classList.add('leftDiv');
        leftDiv.innerHTML = shoppingItem;

        const rightDiv = document.createElement(`div`);
        rightDiv.classList.add('rightDiv');

        const purchaseItem = handlePurchaseItem();
        purchaseItem.addEventListener(`click`, () => {
            // console.log(`Item Purchased!`);
            leftDiv.style.textDecoration = "line-through"
        });

        const removeItem = handleRemoveItem();
        removeItem.addEventListener('click', () => {
            // console.log(`Remove item!`);
            masterdiv.remove();
        });

        rightDiv.appendChild(purchaseItem);
        rightDiv.appendChild(removeItem);

        masterdiv.appendChild(leftDiv);
        masterdiv.appendChild(rightDiv);

        shoppingList.appendChild(masterdiv);

        // clear input
        input.value = '';
    }
}

// Event listener for adding an item to shopping cart
addButton.addEventListener('click', addItem);

// Event listener for pressing the enter key
input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        addItem();
    }
});

// Focus on input field on page load
document.addEventListener('DOMContentLoaded', function () {
    input.focus();
});