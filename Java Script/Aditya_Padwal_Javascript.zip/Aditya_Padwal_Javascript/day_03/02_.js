// Assignment 02

function handleArguments(param1, param2, param3) {
  if (
      typeof param1 === "string" &&
      typeof param2 === "string" &&
      param3 === undefined
  ) {
      return param1 + param2;
  } 
  else if (
      typeof param1 === "number" &&
      typeof param2 === "number" &&
      param3 === undefined
  ) {
      return param1 + param2;
  } 
  else if (
      typeof param1 === "number" &&
      typeof param2 === "number" &&
      typeof param3 === "number"
  ) {
      return param1 + param2 + param3;
  } 
  else if (
      typeof param1 === "string" &&
      typeof param2 === "number" &&
      param3 === undefined
  ) {
      return param1 + param2;
  } 
  else {
      let total = 0;
      for (let value of arguments) {
          if (typeof value === "number") {
              total += value;
          }
      }
      return total;
  }
}

console.log(handleArguments("Hello", "World"));    
console.log(handleArguments(2, 3));               
console.log(handleArguments(1, 2, 3));           
console.log(handleArguments("Value is: ", 5));    
console.log(handleArguments(2, " is a number"));  
console.log(handleArguments(1, "two", 3, "four")) 