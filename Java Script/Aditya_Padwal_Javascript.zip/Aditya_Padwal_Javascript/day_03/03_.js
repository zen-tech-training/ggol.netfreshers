// Assignment 03

const Person = {
  setup: function (fullName) {
      this.fullName = fullName;
  },
  talk: function () {
      console.log("Hi, I'm " + this.fullName);
  },
  selfIntroduce: function () {
      console.log("My name is " + this.fullName);
  },
};

const Learner = Object.create(Person);

Learner.setup = function (fullName, institution, subjects) {
  Person.setup.call(this, fullName);
  this.institution = institution;
  this.subjects = subjects;
};

Learner.selfIntroduce = function () {
  console.log("I am a learner named " + this.fullName + " at " + this.institution);
};

Learner.takeTests = function () {
  console.log("Taking tests...");
};

let jane = Object.create(Learner);
jane.setup("Jane Smith", "Sample University", ["History", "Biology"]);

jane.selfIntroduce();
jane.talk();
jane.takeTests();
jane.selfIntroduce();