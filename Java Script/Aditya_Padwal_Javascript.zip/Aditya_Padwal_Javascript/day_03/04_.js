// Assignment 04

class Individual {
  constructor(fullName) {
      this.fullName = fullName;
  }

  greet() {
      console.log(`Hello, I am ${this.fullName}`);
  }
}

class Coder extends Individual {
  constructor(fullName, programmingLanguage) {
      super(fullName);
      this.programmingLanguage = programmingLanguage;
  }

  greet() {
      console.log(`Hi, I'm ${this.fullName} and I code in ${this.programmingLanguage}`);
  }

  create() {
      console.log(`${this.fullName} is coding in ${this.programmingLanguage}`);
  }
}

let emma = new Coder("Emma", "Python");

console.log("Prototype of Coder:");
console.log(Coder.prototype);
console.log("__proto__ of emma:");
console.log(emma.__proto__);
console.log("getPrototypeOf of emma:");
console.log(Object.getPrototypeOf(emma));