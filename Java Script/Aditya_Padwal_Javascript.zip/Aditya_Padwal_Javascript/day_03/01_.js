// Assignment 01 function overloading...
function sumValues() {
  if (arguments.length === 2) {
      return arguments[0] + arguments[1];
  } 
  else if (arguments.length === 3) {
      return arguments[0] + arguments[1] + arguments[2];
  } 
  else if (arguments.length === 4) {
      return arguments[0] + arguments[1] + arguments[2] + arguments[3];
  } 
  else {
      throw new Error("Invalid number of arguments for sumValues function.");
  }
}

console.log(sumValues(2, 3));       
console.log(sumValues(2, 3, 5));        
console.log(sumValues(2, 3, 5, 7));   