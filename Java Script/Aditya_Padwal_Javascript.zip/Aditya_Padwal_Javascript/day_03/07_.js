// Assignment 07

let carObj = new Car("Hyundai", "Creta");

let bikeObj = new Bike("Tesla", "Model X");

console.log(typeof carObj);
console.log(typeof bikeObj);

console.log(carObj instanceof Vehicle);
console.log(carObj instanceof Car);
console.log(carObj instanceof Bike);

console.log(bikeObj instanceof Vehicle);
console.log(bikeObj instanceof Car);
console.log(bikeObj instanceof Bike);

console.log(carObj.constructor === Car);
console.log(bikeObj.constructor === Bike);

console.log(Object.getPrototypeOf(carObj) === Car.prototype);
console.log(Object.getPrototypeOf(bikeObj) === Bike.prototype);
