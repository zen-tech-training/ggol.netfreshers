// Assignment 05

const PurchaseModule = (function () {
  const purchaseList = [];

  function getItemIndex(productCode) {
      return purchaseList.findIndex((item) => item.productCode === productCode);
  }

  return {
      addProduct: function (productCode, name, price, quantity = 1) {
          const index = getItemIndex(productCode);
          if (index !== -1) {
              purchaseList[index].quantity += quantity;
          } else {
              purchaseList.push({
                  productCode: productCode,
                  name: name,
                  price: price,
                  quantity: quantity,
              });
          }
      },
      removeProduct: function (productCode) {
          const index = getItemIndex(productCode);
          if (index !== -1) {
              purchaseList.splice(index, 1);
          }
      },
      getAllProducts: function () {
          return purchaseList;
      },
      calculateTotalCost: function () {
          let totalCost = 0;
          purchaseList.forEach((item) => {
              totalCost += item.price * item.quantity;
          });
          return totalCost;
      },
  };
})();

PurchaseModule.addProduct(1001, "Item A", 10.99, 2);
PurchaseModule.addProduct(1002, "Item B", 5.99);
PurchaseModule.addProduct(1001, "Item A", 10.99, 1);
console.log("All Products:", PurchaseModule.getAllProducts());

console.log("Total Cost:", PurchaseModule.calculateTotalCost());

PurchaseModule.removeProduct(1002);

console.log(
  "All Products after removing Item B:",
  PurchaseModule.getAllProducts()
);

console.log(
  "Total Cost after removing Item B:",
  PurchaseModule.calculateTotalCost()
);