// Done
function flattenArray(arr) {
    let result = [];
    
    function flatten(nestedArr) {
      for (let i = 0; i < nestedArr.length; i++) {
        if (Array.isArray(nestedArr[i])) {
          flatten(nestedArr[i]);
        } else {
          result.push(nestedArr[i]);
        }
      }
    }
    
    flatten(arr);
    return result;
  }
  
  var nestedArray = [1, [2, 3], [4, [5, 6]]];
  var result = flattenArray(nestedArray);
  console.log(result); // Output: [1, 2, 3, 4, 5, 6]
  