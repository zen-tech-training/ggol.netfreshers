// Done
function sumOfNumbers(arr) {
    return arr.reduce((sum, num) => sum + num, 0);
  }
  
  const numbers = [10, 20, 30, 40, 50];
  const total = sumOfNumbers(numbers);
  console.log(total); // Output: 150
  