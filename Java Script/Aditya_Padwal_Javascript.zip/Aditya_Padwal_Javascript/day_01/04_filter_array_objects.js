// Done
const people = [
    { name: 'John', age: 25 },
    { name: 'Jane', age: 20 },
    { name: 'Bob', age: 30 },
    { name: 'Alice', age: 18 },
    { name: 'Tom', age: 22 }
  ];
  
  function filterByAge(arr, age) {
    return arr.filter(obj => obj.age > age);
  }
  
  const adultsOnly = filterByAge(people, 18);
  console.log(adultsOnly);
  