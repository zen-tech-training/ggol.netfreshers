// Done
// 1. Program to reverse a string

// Method 1: Using inbuilt functions
let string = `Hello World`;

function reverseString(str) {
    let ans1 = str.split('');
    console.log(ans1);
    
    let ans2 = ans1.reverse();
    console.log(ans2);
    
    let ans3 = ans2.join('');
    
    return ans3;
}

console.log('Original String: ', string);
let finalAns = reverseString(string);
console.log(finalAns);

// Method 2: Without using reverse inbuilt function
let inputString = "Hello World";

function revString(str) {
  let charArray = str.split('');
  let size = charArray.length;
  let i = 0;
  let j = size - 1;

  while (i < j) {
    let temp = charArray[i];
    charArray[i] = charArray[j];
    charArray[j] = temp;
    i++;
    j--;
  }

  return charArray.join('');
}

console.log("Before Reversing: ", inputString);
let reversedString = revString(inputString);
console.log("After Reversing: ", reversedString);
