// Done
let string1 = "radar";
let string2 = "hello";

function checkPalindrome(str){
    let string = str.split('');
    let i = 0;
    let j = string.length - 1;

    while(i < j)
    {
        if(string[i] !== string[j])
        {
            return false;
        }
        i++;
        j--;
    }
    return true;
}

console.log("radar is palindrome? => ", checkPalindrome(string1));
console.log("hello is palindrome? => ", checkPalindrome(string2));