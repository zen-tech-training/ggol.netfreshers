// Done
function objectToArray(obj) {
    const result = [];
    
    for (const key in obj) {
      result.push([key, obj[key]]);
    }
    
    return result;
  }
  
  var obj = {name: 'John', age: 30};
  var result = objectToArray(obj);
  console.log(result); // Output: [['name', 'John'], ['age', 30]]
  