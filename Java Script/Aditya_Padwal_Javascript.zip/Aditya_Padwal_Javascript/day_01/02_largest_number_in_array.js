// Done
// 2. Largest element in array

// Method 1: Using simple method
let array1 = [2, -1, 6, -3, 4, 7, -1, 8, 9, 2, -3, 1];
let maxNumber = array1[0];

for(let i=0; i<array1.length; i++)
{
    if(array1[i] > maxNumber)
    {
        maxNumber = array1[i];
    }
}

console.log("Largest number is: ", maxNumber);

// Method 2: Using in-built functions
let array2 = [2, -1, 6, -3, 4, 7, -1, 8, 9, 2, -3, 1];
let ans = (arr) => {
    return Math.max(...arr);
}
console.log(ans(array2));

// Method 3: Using the reduce method
let array3 = [2, -1, 6, -3, 4, 7, -1, 8, 9, 2, -3, 1];
let finalAns = array2.reduce((a, b) => Math.max(a, b), -Infinity);
console.log(finalAns);