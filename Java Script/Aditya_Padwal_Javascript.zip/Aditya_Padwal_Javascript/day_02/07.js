// 7. Using Getters and Setters
// Book:
//     - Create a constructor function `Book` with properties `title`, `author`, and `year`.
//     - Add a getter method `getSummary` that returns a summary string of the book.
//     - Add a setter method `setYear` that updates the year and logs a message when the year is set.

function Book(title, author, year) {
    this.title = title;
    this.author = author;
    this.year = year; 
}

// Getter method for summary
Book.prototype.getSummary = function() {
    return `${this.title} was written by ${this.author} in ${this.year}.`;
};

// Setter method for year
Book.prototype.setYear = function(newYear) {
    this.year = newYear;
    console.log(`The year has been updated to ${newYear}.`);
};

let book = new Book('JavaScript', 'Aditya', 2018);
console.log(book.getSummary()); 
book.setYear(2019); 
console.log(book.getSummary());