// 6: Creating and Using Static Methods
// Math Utilities:
//     - Create a constructor function `MathUtil`.
//     - Add a static method `add` that takes two numbers and returns their sum.
//     - Add a static method `subtract` that takes two numbers and returns their difference.
//     - Add a static method `multiply` that takes two numbers and returns their product.
//     - Add a static method `divide` that takes two numbers and returns their quotient.

function MathUtil() {
    // Empty constructor as static methods do not require instance initialization
}

// Static method for addition
MathUtil.add = function(a, b) {
    return a + b;
};

// Static method for subtraction
MathUtil.subtract = function(a, b) {
    return a - b;
};

// Static method for multiplication
MathUtil.multiply = function(a, b) {
    return a * b;
};

// Static method for division
MathUtil.divide = function(a, b) {
    if (b === 0) {
        throw new Error('Division by zero is not allowed');
    }
    return a / b;
};

console.log(MathUtil.add(5, 3));      
console.log(MathUtil.subtract(5, 3)); 
console.log(MathUtil.multiply(5, 3)); 
console.log(MathUtil.divide(6, 3));   
console.log(MathUtil.divide(6, 0));   
