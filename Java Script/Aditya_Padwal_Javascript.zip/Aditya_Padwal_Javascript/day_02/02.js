// 2: Prototypal Inheritance
//   Animal and Dog Classes:
//     - Create a constructor function `Animal` with properties `name` and `sound`.
//     - Add a method `makeSound` to the `Animal` prototype that logs the sound.
//     - Create a constructor function `Dog` that inherits from `Animal`.
//     - Add a method `fetch` to the `Dog` prototype.

function Animal(name, sound){
    this.name = name;
    this.sound = sound;
}

Animal.prototype.makeSound = function(){
    console.log(`Animal ${this.name} makes the sound ${this.sound}`);
}

// prototype chaining
Dog.prototype = new Animal(`Roger`, `Bhou`);
Animal.prototype.constructor = Animal;

function Dog(name, sound) {
    // classical inheritance
    Animal.call(this, name, sound)
};

Dog.prototype.fetch = function() {
    console.log(`Dog named ${this.name} fetches the ball`);
}

var animal = new Animal("Cow", "Moo");
animal.makeSound();

var dog = new Dog(`Sheru`, `Bhau`);
dog.makeSound();
dog.fetch();