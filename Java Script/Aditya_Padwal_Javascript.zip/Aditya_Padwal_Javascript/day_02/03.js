// 3: Encapsulation and Private Variables
// Bank Account:
//     - Create a constructor function `BankAccount` with a private variable `balance`.
//     - Add methods `deposit`, `withdraw`, and `getBalance` to manage the balance.

function BankAccount() {
    var balance = 0;

    this.deposit = function(amt) {
        balance += amt;
    }

    this.withdraw = function(amt) {
        balance -= amt;
    }

    this.getBalance = function() {
        console.log(`Account balance is Rs.${balance}`);
    }
}

var user = new BankAccount();

user.getBalance();
user.deposit(1000);
user.getBalance();
user.withdraw(500);
user.getBalance();