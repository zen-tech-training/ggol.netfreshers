// 1: Creating and Using Objects
// Create a Simple Object:
//     - Create an object `car` with properties `make`, `model`, and `year`.
//     - Add a method `getCarInfo` that returns a string with the car's information.

var car = {
    make: 2024,
    model: `ABC`,
    year: 2020
}

function getCarInfo(car) {
    console.log(`Make of car is: ${car.make}. Model of the car is ${car.model}. Year of the car is ${car.year}`);
}

getCarInfo(car);

