// 9: Implementing Polymorphism
// Shape and Specific Shapes:
//     - Create a constructor function `Shape` with a method `getArea` that returns 0.
//     - Create a constructor function `Square` that inherits from `Shape` and has a property `sideLength`.
//     - Override the `getArea` method in `Square` to return the area of the square.
//     - Create a constructor function `Triangle` that inherits from `Shape` and has properties `base` and `height`.
//     - Override the `getArea` method in `Triangle` to return the area of the triangle.

function Shape() {
}
Shape.prototype,getArea = function() {
    return 0;
}

Square.prototype = Object.create(Shape.prototype);
Square.prototype.constructor = Square;

Triangle.prototype = Object.create(Shape.prototype);
Triangle.prototype.constructor = Triangle;

function Square(sideLength) {
    // classical inheritance
    Shape.call(this);
    this.sideLength = sideLength;
}
Square.prototype.getArea = function() {
    return this.sideLength * this.sideLength;
}

function Triangle(base, height) {
    // classical inheritance
    Shape.call(this);
    this.base = base;
    this.height = height;
}
Triangle.prototype.getArea = function() {
    return 0.5 * this.base * this.height;
}

var square = new Square(5);
console.log(`Area of square: `, square.getArea());

var triangle = new Triangle(3, 10);
console.log(`Area of triangle: `, triangle.getArea());