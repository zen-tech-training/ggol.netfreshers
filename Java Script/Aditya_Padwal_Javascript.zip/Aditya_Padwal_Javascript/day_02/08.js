// 8: Composition Over Inheritance
// User with Address:
//     - Create a constructor function `User` with properties `username` and `password`.
//     - Create a constructor function `Address` with properties `street`, `city`, and `country`.
//     - Add an `address` property to the `User` constructor that holds an `Address` instance.
//     - Add a method `getAddress` to the `User` prototype that returns the user's address as a formatted string.

function Address(street, city, country) {
    this.street = street;
    this.city = city;
    this.country = country;
}

function User(username, password, street, city, country) {
    this.username = username;
    this.password = password;
    this.address = new Address(street, city, country);
}

// Method to get formatted address
User.prototype.getAddress = function() {
    return `${this.address.street}, ${this.address.city}, ${this.address.country}`;
};

let user1 = new User('Aditya Padwal', '12345678', 'MG Road', 'Pune', 'India');
console.log(user1.getAddress()); 

let user2 = new User('John Johnson', 'qwerty456', 'Main Street', 'NYC', 'USA');
console.log(user2.getAddress()); 
