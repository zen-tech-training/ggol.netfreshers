// 5: Inheritance with Method Overriding
// Vehicle and Car:
//     - Create a constructor function `Vehicle` with properties `make`, `model`, and `year`.
//     - Add a method `getDetails` to the `Vehicle` prototype that returns a string with the vehicle's details.
//     - Create a constructor function `Car` that inherits from `Vehicle` and adds a property `doors`.
//     - Override the `getDetails` method in the `Car` prototype to include the number of doors.

function Vehicle(make, model, year) {
    this.make = make;
    this.model = model;
    this.year = year;
}

Vehicle.prototype.getDetails = function() {
    console.log(`Make: ${this.make}, Model: ${this.model}, Year: ${this.year}`);
}

// prototype chaining
// Car.prototype = new Vehicle();
Car.prototype = Object.create(Vehicle.prototype); // alternative to above
Car.prototype.constructor = Car;

function Car(make, model, year, doors) {
    // classical inheritance
    Vehicle.call(this, make, model, year);
    this.doors = doors;
}

Car.prototype.getDetails = function() {
    console.log(`Make: ${this.make}, Model: ${this.model}, Year: ${this.year}, Doors: ${this.doors}`);
}

var vehicle = new Vehicle(`Hatchback`, `Old`, `2010`);
vehicle.getDetails();

var car = new Car(`SUV`, `Latest`, `2023`, `4`);
car.getDetails();