// 10: Using Mixins
// Flyable and Swimmable Mixins :
//     - Create a mixin `Flyable` that adds a method `fly` to an object.
//     - Create a mixin `Swimmable` that adds a method `swim` to an object.
//     - Create a constructor function `Duck` that uses both mixin

// Flyable mixin
let Flyable = {
    fly: function() {
        console.log(`${this.name} is flying!`);
    }
};

// Swimmable mixin
let Swimmable = {
    swim: function() {
        console.log(`${this.name} is swimming!`);
    }
};

// Duck constructor using mixins
function Duck(name) {
    this.name = name;
}

// Applying Flyable and Swimmable mixins to Duck prototype
Object.assign(Duck.prototype, Flyable, Swimmable);

// Example usage
let duck1 = new Duck('Daffy');
duck1.fly();  // Output: Daffy is flying!
duck1.swim(); // Output: Daffy is swimming!

let duck2 = new Duck('Donald');
duck2.fly();  // Output: Donald is flying!
duck2.swim(); // Output: Donald is swimming!

// Allows adding functionality (such as fly and swim methods)
//  to objects at runtime without modifying their original prototype chain.