// 4: Polymorphism
// Shapes:
//     - Create a base constructor function `Shape` with a method `getArea` that returns 0.
//     - Create derived constructor functions `Circle` and `Rectangle` that override the `getArea` method
//       to calculate the area of the shape.

function Shape() {
    this.getArea = function() {
        return 0;
    }
}

function Circle(radius) {
    // classical inheritance
    Shape.call(this);

    this.getArea = function() {
        // calculate area of circle
        return Math.PI * radius * radius;
    }
}

function Rectangle(width, height) {
    // classical inheritance
    Shape.call(this);

    this.getArea = function() {
        // calculate area of rectangle
        return width * height;
    }
}

// prototype chaining
Circle.prototype = new Shape();
Circle.prototype.constructor = Circle;

// prototype chaining
Rectangle.prototype = new Shape();
Rectangle.prototype.constructor = Rectangle;

// Example usage
let circle = new Circle(5);
let rectangle = new Rectangle(10, 20);

console.log("Area of circle:", circle.getArea()); 
console.log("Area of rectangle:", rectangle.getArea());
