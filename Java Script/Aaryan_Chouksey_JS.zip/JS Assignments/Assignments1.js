// Javascript Assignments Q1 to Q10



// Q1
function revereString(str) {
    return str.split('').reverse().join('');
}

// Q2
function largestInArray(arr) {
    var largest = 0;
    for( i in arr ){
        if (arr[i] > largest) {
            largest = arr[i];
        }
    }
    return largest;
}

// Q3
function palindrome(str) {
    return str === revereString(str);
}

// Q4
function sumOfArray(arr) {
    var sum = 0;
    for( i in arr ){
        sum += arr[i];
    }
    return sum;
}

// Q5
function removeDuplicates(arr) {
    return arr.filter((item,index) => arr.indexOf(item) === index);
}

// Q6
function flatArray(arr) {
    return arr.flat();
}


// Q7
function intersectionArray(arr1, arr2) {
    return arr1.filter(element => arr2.includes(element));
}


// Q8
function objectToArray(obj) {
    const entries = Object.entries(obj);
    return entries;
}

// Q9
function filterArray(arr) {
    var newArr = [];
    for( ele of arr){
        if (ele.age > 18)
            newArr.push(ele);
    }
    return arr;
}


// Q10
function sortArrayObjects(arr, property) {
    return arr.sort(function (a,b) {
        let comparison = 0;
        if (a[property] > b[property]) {
            comparison = 1;
        } else if (a[property] < b[property]) {
            comparison = -1;
        }
        return comparison;
    });
}

