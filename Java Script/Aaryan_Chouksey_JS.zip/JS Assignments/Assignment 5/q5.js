async function fetchData(){
    try{
        console.log("Waiting...");
        setTimeout(()=>{
            console.log("Data Fetched");
        },2000);
    }
    catch(err){
        console.error(err);
    }
}

fetchData();



// setTimeout is running asynchronously and cause of that
// nothing is returned to the .then() funciton and therefore undefined 
// is printed.

// const fetchData = async () => {
//   try {
//     console.log("Waiting...");
//     // return "Data Fetched";
//     setTimeout(() => {
//       return "Data Fetched";
//     }, 2000);
//   } catch (err) {
//     console.error(err);
//   }
// };

// fetchData()
//   .then((res) => console.log("After call: " + res))
//   .catch((err) => console.error(err));

// console.log(fetchData());

// async function fetching(){
// console.log(fetchData());

// const res = await fetchData();
// console.log(res);
// }
