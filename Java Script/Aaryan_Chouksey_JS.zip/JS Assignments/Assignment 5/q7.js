async function getUserData(){
    try {
        // Correct
        // const data = await fetch("https://jsonplaceholder.typicode.com/users/1");
        const data = await fetch("https://jsonplaceholder.typicode.com/users");
        
        // Incorrect - Type Error in case of wrong url
        // const data = await fetch("https://jsonpla.typicode.com/users/1");
        // const data = await fetch("https://jsonplaceholdervb.com");
        console.log(await data.json());
    } catch (error) {
        console.error("Error occoured: "+error);
    }
}
getUserData();