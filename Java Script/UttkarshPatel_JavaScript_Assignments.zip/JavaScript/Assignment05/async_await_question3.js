async function getUserData() {
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users/100');
        const userData = await response.json();
        console.log(userData);
    } catch (error) {
        console.error('Error fetching user data:', error);
    }
}

getUserData();