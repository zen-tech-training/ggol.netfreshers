async function fetchPosts() {
    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
    if (!response.ok) {
        throw new Error('Failed to fetch posts');
    }
    return await response.json();
}

async function fetchComments() {
    const response = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1');
    if (!response.ok) {
        throw new Error('Failed to fetch comments');
    }
    return await response.json();
}

async function fetchAllData() {
    try {
        const [posts, comments] = await Promise.all([fetchPosts(), fetchComments()]);
        const combinedData = { posts, comments };
        
        console.log(combinedData);
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

fetchAllData();
