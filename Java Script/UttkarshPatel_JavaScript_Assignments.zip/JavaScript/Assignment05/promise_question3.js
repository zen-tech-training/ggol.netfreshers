function errorProneTask() {
    return new Promise((resolve, reject) => {
        const number = Math.random();

        if (number < 0.5) {
            resolve("Success! Task completed.");
        } else {
            reject("Error: Task failed.");
        }
    });
}

errorProneTask()
    .then((message) => {
        console.log(message);
    })
    .catch((error) => {
        console.error(error);
    });