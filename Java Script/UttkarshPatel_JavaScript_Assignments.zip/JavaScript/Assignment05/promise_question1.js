function wait(timeToWait){
    return new Promise((res, rej)=>{
        setTimeout(()=>{
            console.log(`Completed after ${timeToWait}`);
            res();
        }, timeToWait);
    })
}

wait(1000);
wait(2000);
wait(3000);
wait(4000);