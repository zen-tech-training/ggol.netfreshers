function taskA() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Task A complete");
        }, 1000); 
    });
}

function taskB() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Task B complete");
        }, 2000); 
    });
}

function taskC() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Task C complete");
        }, 1500); 
    });
}

Promise.all([taskA(), taskB(), taskC()])
    .then((results) => {
        console.log("All completed: ");
        results.forEach(result => console.log(result));
    })
    .catch((error) => {
        console.error("An error occurred:", error);
    });