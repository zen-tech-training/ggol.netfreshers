function task1() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Task 1 complete");
        }, 1000); 
    });
}

function task2() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Task 2 complete");
        }, 2000); 
    });
}

function task3() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Task 3 complete");
        }, 1500);
    });
}

task1()
    .then((message) => {
        console.log(message);
        return task2();
    })
    .then((message) => {
        console.log(message);
        return task3();
    })
    .then((message) => {
        console.log(message);
    })
    .catch((error) => {
        console.error("An error occurred:", error);
    })
    .finally(() => {
        console.log("All tasks completed.");
    });