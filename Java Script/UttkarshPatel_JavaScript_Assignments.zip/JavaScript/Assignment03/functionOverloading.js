const map = new Map();

function createTypeString(typeArr){
    return typeArr.join("");
}

function extractTypes(args){
    let typeString = "";
    for(let arg of args){
        let type = typeof arg;
        // console.log(arg + " - " + type)
        if(type === "object"){
            if(Array.isArray(arg)){
                type = "array";
            }
        }
        typeString += type;
    }
    // console.log(typeString)
    return typeString;
}

function addFunction(func, typeArr){
    const typeString = createTypeString(typeArr);
    map.set(typeString, func);
}

addFunction(function(a, b){
    console.log(a+b)
}, ["number", "number"]);

addFunction(function(a, b){
    console.log(a+b + "STRING")
}, ["number", "string"]);

addFunction(function(a, b){
    console.log("THIS IS FOR THE ARRAY");
}, ["array"]);

function callFunction(...args){
    map.get(extractTypes(args))(...args);
}

callFunction(1, 2)
callFunction(1, "2")
callFunction([1, "2"])