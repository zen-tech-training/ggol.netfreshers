function question1(){
// 1. Create Pseudo classical Inheritance by using Object.create and Object.setPrototypeOf for
// Human – Base / Super Class
// 	name – string
// Prototype Level Method 
// 	Speak	
// 	Introduction

// Student
// 	College – string
// 	Courses – string []
// Prototype Level Method
// 	Introduction (overridden)
// 	takeExams

    function Human(name){
        this.name = name;
    }
    Human.prototype.speak = function(){
        console.log("HUMAN IS SPEAKING");
    }
    Human.prototype.introduction = function(){
        console.log("Hi my name is " + this.name)
    }

    function Student(name, college, ...courses){
        Human.call(this, name);
        this.college = college;
        this.courses = courses
    }

    Student.prototype = new Human();
    Student.prototype.constructor = Student;

    Student.prototype.introduction = function(){
        console.log("I'm " + this.name + " a student of " + this.college);
    }
    Student.prototype.takeExams = function(){
        console.log("I give exams of subjects: \n\t");
        console.log(...this.courses);
    }

    var student = new Student('Uttkarsh','VIT',['C++','JavaScript','Java']);
    student.introduction();
    student.takeExams();
}

function question2(){
// 2. Create a Class Hierarchy between
// Person – Base / Super
// Developer - Derived / Sub

// Display Both objects / classes prototype, __proto__ and getPrototypeOf
    function Person(name){
        this.name = name;
    }

    function Developer(name, ...languages){
        Person.call(this, name);
        this.languagesKnown = languages;
    }

    Developer.prototype = new Person();
    Developer.prototype.constructor = Developer;

    const person = new Person("Dennis Ritchie");
    const developer = new Developer("Brian Kernighan");

    console.log(person.__proto__);
    console.log(Person.prototype);
    console.log(Object.getPrototypeOf(person));

    console.log(developer.__proto__);
    console.log(Developer.prototype);
    console.log(Object.getPrototypeOf(developer));
}


function question3(){
// 1. Create a Shopping Cart Module, which would allow user to deal with cart data,
// Product in Shopping Cart would be with following details. productId, name, price, quantity
// Methods provided by Module are, addItem – Add Item would add one product item, if again called for the same product 
// id, it would increase the quantity.
// 	removeItem – Remove product (all quantities by product id)
// 	getAllItems – Get all products details.
// 	getTotalPrice - Total Price of all items in the cart

    function Item(productID, name, price, quantity){
        this.productID = productID;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    var ShoppingCart = (function(){
        var items = [];

        return {
            addItem: function(productID, name, price, quantity){
                items.push(new Item(productID, name, price, quantity));
            },
            removeItem: function(productID){
                items = items.filter(item=>item.productID!==productID);
            },
            getAllItems: function(){
                items.map((item, idx)=>{
                    console.log(`${idx+1}. ${item.name} | ${item.quantity} x ${item.price} = ${item.quantity * item.price}`);
                });
                console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            },
            getTotalPrice: function(){
                var totalPrice = items.reduce((accumulator, currentItem)=>accumulator + (currentItem.price * currentItem.quantity), 0);
                console.log("TOTAL PRICE = " + totalPrice);
            }
        }
    })();

    ShoppingCart.addItem("101", "Apple", 10, 5);
    ShoppingCart.addItem("103", "Mango", 20, 5);
    ShoppingCart.addItem("102", "Orange", 30, 5);
    ShoppingCart.getAllItems();
    ShoppingCart.removeItem("102");
    ShoppingCart.getAllItems();
    ShoppingCart.getTotalPrice();
}

function question4(){
    function Vehicle(make, model){
        this.make = make;
        this.model = model;
    }

    function Car(make, model){
        this.wheels = 4;
    }

    function Bike(make, model){
        this.wheels = 2;
    }

    Car.prototype = new Vehicle();
    Car.prototype.constructor = Car;
    Bike.prototype = new Vehicle();
    Bike.prototype.constructor = Bike;

    const car = new Car();
    const bike = new Bike();

    console.log(typeof car);
    console.log(typeof bike);
    console.log("~~~~~~~~~~~~~~~~~~~~~");
    console.log(car instanceof Vehicle);
    console.log(car instanceof Car);
    console.log(car instanceof Bike);
    console.log("~~~~~~~~~~~~~~~~~~~~~");
    console.log(bike instanceof Vehicle);
    console.log(bike instanceof Car);
    console.log(bike instanceof Bike);
    console.log("~~~~~~~~~~~~~~~~~~~~~");
    console.log(car.constructor);
    console.log(bike.constructor);
    console.log("~~~~~~~~~~~~~~~~~~~~~");
    console.log(Object.getPrototypeOf(car) === Car.prototype);
    console.log(Object.getPrototypeOf(bike) === Bike.prototype);

}

// question1();
// question2();
// question3();
// question4();