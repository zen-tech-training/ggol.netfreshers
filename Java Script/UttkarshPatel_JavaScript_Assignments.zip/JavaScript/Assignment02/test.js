function Person(){
    this.firstName = "Uttkarsh";
    this.sayName = function(){
        console.log(this);
    }
}

let p = new Person();
p.sayName()