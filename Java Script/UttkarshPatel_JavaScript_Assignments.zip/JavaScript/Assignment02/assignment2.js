function question1() {
    // Creating and using objects
    //     Create a Simple Object:
    //     - Create an object `car` with properties `make`, `model`, and `year`.
    //     - Add a method `getCarInfo` that returns a string with the car's information.

    function Car(make, model, year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    Car.prototype.getCarInfo = function () {
        console.log("HERE")
        console.log(`CAR INFO - \n\tMAKE=${this.make} \n\tMODEL=${this.model} \n\tYEAR${this.year}\n\n`);
    }
    console.log("1")

    var car = new Car("Sedan", "x5", 2007);
    car.getCarInfo();
}

function question2() {
    //  Prototypal Inheritance
    //  Animal and Dog Classes:
    //     - Create a constructor function `Animal` with properties `name` and `sound`.
    //     - Add a method `makeSound` to the `Animal` prototype that logs the sound.
    //     - Create a constructor function `Dog` that inherits from `Animal`.
    //     - Add a method `fetch` to the `Dog` prototype.
    function Animal(name, sound) {
        this.name = name;
        this.sound = sound;
    }

    Animal.prototype.makeSound = function () {
        console.log(`${this.name} makes ${this.sound} sound`);
    }

    function Dog(name, sound) {
        // Animal.call(this, name, sound);
        Dog.prototype = Animal;
        this.fetch = function () {
            console.log("FETCHING...");
        }
    }

    // Dog.prototype = new Animal(); // Cannot do for inheritance as we need to pass arguments
    var dog = new Dog("dog", "bark");
    dog.fetch()
    console.log(dog.constructor)

}


function question3() {
    // Encapsulation and Private Variables
    // Bank Account:
    //     - Create a constructor function `BankAccount` with a private variable `balance`.
    //     - Add methods `deposit`, `withdraw`, and `getBalance` to manage the balance.
    function BankAccount() {
        var balance = 0;
        this.deposit = (deposittedAmount) => {
            balance += deposittedAmount;
        };
        this.withdraw = function (withdrawnAmount) {
            if (balance < withdrawnAmount) {
                console.log("Insufficient funds in the account");
            }
            else {
                balance -= withdrawnAmount;
            }
        };
        this.getBalance = function () {
            console.log(balance);
        }

    }

    var uttAcc = new BankAccount();
    console.log(uttAcc.balance) // = undefined
    uttAcc.getBalance();
    uttAcc.deposit(100);
    uttAcc.getBalance();
    uttAcc.withdraw(50);
    uttAcc.getBalance();
}


function question4() {
    function Shape() {
        this.getArea = function () {
            return 0;
        }
    }

    function Circle(radius) {
        Shape.call(this);
        this.radius = radius;
        this.getArea = function () {
            console.log("The area of the circle is = " + 3.14 * this.radius * this.radius);
        }
    }

    function Rectangle(length, width) {
        Shape.call(this);
        this.length = length;
        this.width = width;

        this.getArea = function () {
            console.log("The area of the rectangle is = " + this.length * this.width);
        }
    }

    const rect = new Rectangle(10, 20);
    const circ = new Circle(7);
    rect.getArea();
    circ.getArea();
}

function question5() {
    function Vehicle(make, model, year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    Vehicle.prototype.getDetails = function () {
        console.log(`MAKE=${this.make} MODEL=${this.model} YEAR${this.year}`);
    }

    function Car() {
        Vehicle.call(this, 123, "sedan", 2008);
        this.doors = "4";
    }
    Car.prototype.getDetails = function () {
        console.log(`MAKE=${this.make} MODEL=${this.model} YEAR${this.year} DOOR_COUNT=${this.doors}`);
    }

    const car = new Car();
    car.getDetails();
}

function question6() {
    // Creating and Using Static Methods
    // Math Utilities:
    //     - Create a constructor function `MathUtil`.
    //     - Add a static method `add` that takes two numbers and returns their sum.
    //     - Add a static method `subtract` that takes two numbers and returns their difference.
    //     - Add a static method `multiply` that takes two numbers and returns their product.
    //     - Add a static method `divide` that takes two numbers and returns their quotient.

    function MathUtil() {
    }
    MathUtil.add = function(a, b){
        console.log("Addition " + (a+b));
    }

    MathUtil.subtract = function(a, b){
        console.log("Divide " + (a-b));
    }
    
    MathUtil.multiply = function(a, b){
        console.log("Divide " + (a*b));
    }

    MathUtil.divide = function(a, b){
        console.log("Divide " + (a/b));
    }

    MathUtil.add(9, 10);
}

function question7(){
    //     Using Getters and Setters
    // Book:
    //     - Create a constructor function `Book` with properties `title`, `author`, and `year`.
    //     - Add a getter method `getSummary` that returns a summary string of the book.
    //     - Add a setter method `setYear` that updates the year and logs a message when the year is set.

    function Book(title, author, year){
        var bTitle = title;
        var bAuthor = author;
        var bYear = year;

        this.getSummary = function(){
            console.log(`SMMARY OF THE BOOK = ${bTitle} ${bAuthor} ${bYear}`);
        }

        this.setYear = function(newYear){
            bYear = newYear;
            console.log("NEW YEAR SET!");
        }
    }
    const book = new Book("Digital Fortress", "Dan Brown", "2010");
    book.getSummary();
    book.setYear("2017");
    book.getSummary();
}

function question8(){
    // Composition Over Inheritance
    // User with Address:
    //     - Create a constructor function `User` with properties `username` and `password`.
    //     - Create a constructor function `Address` with properties `street`, `city`, and `country`.
    //     - Add an `address` property to the `User` constructor that holds an `Address` instance.
    //     - Add a method `getAddress` to the `User` prototype that returns the user's address as a formatted string.
    function User(username, userPassword){
        this.username = username;
        var password = userPassword;
        
        this.setAddress = function(street, city, country){
            this.address = new Address(street, city, country);
        }
    }

    User.prototype.getAddress = function(){
        console.log(`${this.username}'s address=${this.address.street} ${this.address.city} ${this.address.country}`)
    }

    function Address(street, city, country){
        this.street = street;
        this.city = city;
        this.country = country;
    }
    const user = new User("Uttkarsh", "root");
    user.setAddress( "Bow Street", "P-Town", "India")
    user.getAddress();
}

function question9(){
    // Implementing Polymorphism
    // Shape and Specific Shapes:
    //     - Create a constructor function `Shape` with a method `getArea` that returns 0.
    //     - Create a constructor function `Square` that inherits from `Shape` and has a property `sideLength`.
    //     - Override the `getArea` method in `Square` to return the area of the square.
    //     - Create a constructor function `Triangle` that inherits from `Shape` and has properties `base` and `height`.
    //     - Override the `getArea` method in `Triangle` to return the area of the triangle.
    function Shape(){
        this.getArea = function(){
            return 0;
        }
    }

    function Square(side){
        Shape.call(this);
        this.sideLength = side;
        this.getArea = function(){
            console.log("Area of square = " + (this.sideLength * this.sideLength));
        }
    }

    function Triangle(base, height){
        Shape.call(this);
        this.base = base;
        this.height = height;
        
        this.getArea = function(){
            console.log("Area of triangle is = " + (this.base * this.height * 0.5));
        }
    }

    const square = new Square(5);
    const triangle = new Triangle(5, 12);
    square.getArea();
    triangle.getArea();
}

function question10(){
//  Using Mixins
// Flyable and Swimmable Mixins :
//     - Create a mixin `Flyable` that adds a method `fly` to an object.
//     - Create a mixin `Swimmable` that adds a method `swim` to an object.
//     - Create a constructor function `Duck` that uses both mixin
}

// question1();
// question2();
// question3();
// question4();
// question5();
// question6();
// question7();
// question8();
// question9();
question10();
