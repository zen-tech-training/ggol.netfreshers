class Person {
    constructor(name, age) {
      this.name = name;
      this.age = age;
    }
  
    static isAdult(person) {
      return person.age > 18;
    }
  
    static compareAge(person1, person2) {
      return person1.age - person2.age;
    }
  }
  
 
  const person1 = new Person('Alice', 22);
  const person2 = new Person('Bob', 17);
  
  console.log(Person.isAdult(person1));
  console.log(Person.isAdult(person2)); 
  
  const people = [person1, person2];
  const adults = people.filter(Person.isAdult);
  const sortedByAge = [...people].sort(Person.compareAge);
  
  function reverseString(string) {
    return string.split('').reverse().join('');
  }
  
  function findLargestNumber(numbers) {
    return Math.max(...numbers);
  }
  
  function isPalindrome(string) {
    const cleanedString = string.replace(/[\W_]/g, '').toLowerCase();
    return cleanedString === cleanedString.split('').reverse().join('');
  }
  
  function filterAdults(people) {
    return people.filter(person => person.age > 18);
  }
  
  function sumNumbers(numbers) {
    return numbers.reduce((sum, number) => sum + number, 0);
  }
  
  function removeDuplicates(items) {
    return [...new Set(items)];
  }
  
  function flattenArray(nestedArray) {
    return nestedArray.flat(Infinity);
  }
  
  function findIntersection(array1, array2) {
    return array1.filter(item => array2.includes(item));
  }
  
  function objectToPairs(object) {
    return Object.entries(object);
  }
  
  function sortPeopleByAge(people) {
    return people.sort((person1, person2) => person1.age - person2.age);
  }
  