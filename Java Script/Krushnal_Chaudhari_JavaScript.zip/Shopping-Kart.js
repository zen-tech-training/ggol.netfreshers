// Krushnal Rajendra Chaudhari

function $(id){

return document.getElementById(id);

}

$('add-button').addEventListener('click', addToList);

let count = 1;

function addToList(){

let li = document.createElement('li');

""

let inputList = $('item-input').value.trim()+" ";

if(inputList.trim()=="" ||!inputList.trim()){

alert('Item cannot be empty');

return;

}

let remBtn = document.createElement('button');

remBtn.textContent = 'Remove';

remBtn.style.backgroundColor = 'red';

remBtn.style.border = 'transparent';

remBtn.style.padding = '10px';

remBtn.style.color = 'white';

remBtn.style.cursor = 'pointer';

remBtn.style.borderRadius = '4px'

remBtn.addEventListener('click', function(){

li.remove();

count--;

$('counterP').innerHTML = `${count} items`;

})

li.appendChild(document.createTextNode(inputList))

li.appendChild(remBtn);

let mark = document.createElement('button');

mark.textContent = 'purchase';

mark.style.backgroundColor = 'green';

mark.style.border = 'transparent';

mark.style.padding = '10px';

mark.style.color = 'white';

mark.style.cursor = 'pointer';

mark.style.borderRadius = '4px';

mark.addEventListener('click', function(){

if(mark.innerText=="purchase"){

mark.innerText="purchased";

mark.style.backgroundColor = 'yellow';

// mark.parentElement.style.backgroundColor='#ec93dd';

mark.parentElement.style.textDecorationLine='line-through';

}

else{

mark.innerText="purchase";

mark.style.backgroundColor = 'green';

mark.parentElement.style.backgroundColor='white';

mark.parentElement.style.textDecorationLine='';

}

})

li.appendChild(mark);

$('items-container').appendChild(li) ;

count ++;

$('item-input').value = '';

}