function item(make, model, year) {
    this.make = make;
    this.model = model;
    this.year = year;
  }
  
  item.prototype.info = function() {
    return `${this.make} ${this.model} ${this.year}`;
  };
  
  function entity(name, sound) {
    this.name = name;
    this.sound = sound;
  }
  
  entity.prototype.emit = function() {
    console.log(`${this.name} says ${this.sound}`);
  };
  
  function canine(name) {
    entity.call(this, name, 'bark');
  }
  
  canine.prototype = Object.create(entity.prototype);
  canine.prototype.constructor = canine;
  
  canine.prototype.retrieve = function() {
    console.log('retrieved');
  };
  
  function account(initial) {
    let balance = initial || 0;
  
    this.add = function(amount) {
      balance += amount;
    };
  
    this.subtract = function(amount) {
      if (balance >= amount) {
        balance -= amount;
      }
    };
  
    this.total = function() {
      return balance;
    };
  }
  
  function shape() {}
  
  shape.prototype.area = function() {
    return 0;
  };
  
  function circle(radius) {
    shape.call(this);
    this.radius = radius;
  }
  
  circle.prototype = Object.create(shape.prototype);
  circle.prototype.constructor = circle;
  
  circle.prototype.area = function() {
    return Math.PI * this.radius * this.radius;
  };
  
  function rectangle(width, height) {
    shape.call(this);
    this.width = width;
    this.height = height;
  }
  
  rectangle.prototype = Object.create(shape.prototype);
  rectangle.prototype.constructor = rectangle;
  
  rectangle.prototype.area = function() {
    return this.width * this.height;
  };
  
  function transport(make, model, year) {
    this.make = make;
    this.model = model;
    this.year = year;
  }
  
  transport.prototype.details = function() {
    return `${this.make} ${this.model} ${this.year}`;
  };
  
  function auto(make, model, year, doors) {
    transport.call(this, make, model, year);
    this.doors = doors;
  }
  
  auto.prototype = Object.create(transport.prototype);
  auto.prototype.constructor = auto;
  
  auto.prototype.details = function() {
    return `${transport.prototype.details.call(this)} ${this.doors}`;
  };
  
  function utility() {}
  
  utility.add = function(a, b) {
    return a + b;
  };
  
  utility.subtract = function(a, b) {
    return a - b;
  };
  
  utility.multiply = function(a, b) {
    return a * b;
  };
  
  utility.divide = function(a, b) {
    return a / b;
  };
  
  function book(title, author, year) {
    this.title = title;
    this.author = author;
    let _year = year;
  
    Object.defineProperty(this, 'year', {
      get: function() {
        return _year;
      },
      set: function(newValue) {
        _year = newValue;
      }
    });
  }
  
  book.prototype.summary = function() {
    return `${this.title} by ${this.author}, published in ${this.year}`;
  };
  
  function user(username, password) {
    this.username = username;
    this.password = password;
    this.address = null;
  }
  
  user.prototype.setAddress = function(street, city, country) {
    this.address = new address(street, city, country);
  };
  
  user.prototype.getAddress = function() {
    return `${this.address.street}, ${this.address.city}, ${this.address.country}`;
  };
  
  function address(street, city, country) {
    this.street = street;
    this.city = city;
    this.country = country;
  }
  
  function square(sideLength) {
    shape.call(this);
    this.sideLength = sideLength;
  }
  
  square.prototype = Object.create(shape.prototype);
  square.prototype.constructor = square;
  
  square.prototype.area = function() {
    return this.sideLength * this.sideLength;
  };
  
  function triangle(base, height) {
    shape.call(this);
    this.base = base;
    this.height = height;
  }
  
  triangle.prototype = Object.create(shape.prototype);
  triangle.prototype.constructor = triangle;
  
  triangle.prototype.area = function() {
    return 0.5 * this.base * this.height;
  };

  function overloadedFunction() {
    const args = Array.from(arguments);
    const allNumbers = args.every(arg => typeof arg === 'number');
    const allStrings = args.every(arg => typeof arg === 'string');
  
    
    if (allNumbers) {
      return args.reduce((sum, num) => sum + num, 0);
    }
  
  
    if (allStrings && args.length === 2) {
      return args.join(' ');
    }
  
    if (allNumbers && args.length === 2) {
      return args[0] + args[1];
    }
  
    if (allNumbers && args.length === 3) {
      return args[0] + args[1] + args[2];
    }
  
    if (args.length === 2 && typeof args[0] === 'string' && typeof args[1] === 'number') {
      return args[0] + args[1].toString();
    }
  
    return 'Invalid input or not supported by the overloaded function.';
  }
  
  console.log(overloadedFunction(1, 2));
  console.log(overloadedFunction(1, 2, 3)); 
  console.log(overloadedFunction(1, 2, 3, 4)); 
  console.log(overloadedFunction('hello', 'world')); 
  console.log(overloadedFunction('hello', 5)); 
  
  