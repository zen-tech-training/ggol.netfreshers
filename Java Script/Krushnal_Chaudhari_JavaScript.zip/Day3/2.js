
function Person(name) {
    this.name = name;
  }
  

  function Developer(name, skills) {
    Person.call(this, name);
    this.skills = skills;
  }
  
  Developer.prototype = Object.create(Person.prototype);
  Object.setPrototypeOf(Developer.prototype, Person.prototype);
  
  console.log(Developer.prototype); 
  console.log(Developer.prototype.__proto__); 
  console.log(Object.getPrototypeOf(new Developer())); 
  