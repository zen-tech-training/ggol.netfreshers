var ShoppingCart = (function() {
    var cart = [];
  
    function addItem(productId, name, price) {
      var existingProduct = cart.find(product => product.productId === productId);
      if (existingProduct) {
        existingProduct.quantity++;
      } else {
        cart.push({ productId, name, price, quantity: 1 });
      }
    }
  
    function removeItem(productId) {
      cart = cart.filter(product => product.productId !== productId);
    }
  
    function getAllItems() {
      return cart;
    }
  
    function getTotalPrice() {
      return cart.reduce((total, product) => total + (product.price * product.quantity), 0);
    }
  
    return {
      addItem: addItem,
      removeItem: removeItem,
      getAllItems: getAllItems,
      getTotalPrice: getTotalPrice
    };
  })();
  