
function Human(name) {
    this.name = name;
  }
  
  Human.prototype.speak = function() {
    console.log("Hello, my name is " + this.name);
  };
  
  Human.prototype.introduction = function() {
    console.log("I am a human and my name is " + this.name);
  };
  

  function Student(name, college, courses) {
    Human.call(this, name);
    this.college = college;
    this.courses = courses;
  }
  
  Student.prototype = Object.create(Human.prototype);
  Object.setPrototypeOf(Student.prototype, Human.prototype);
  
  Student.prototype.introduction = function() {
    console.log("I am a student at " + this.college + " and my name is " + this.name);
  };
  
  Student.prototype.takeExams = function() {
    console.log(this.name + " is taking exams.");
  };
  