
function changeText() {
    document.getElementById('text').textContent = 'Changed text';
  }
  

  function addListItem() {
    var ul = document.getElementById('myList');
    var li = document.createElement('li');
    li.appendChild(document.createTextNode('New Item'));
    ul.appendChild(li);
  }
  

  function removeListItem() {
    var list = document.getElementById('myList2');
    list.removeChild(list.lastChild);
  }
  

  function changeColor() {
    document.getElementById('colorBox').style.backgroundColor = 'blue';
  }
  
  // Function for Assignment 1: Changing Text Content
function changeText() {
    document.getElementById('text').textContent = 'Changed text';
  }
  
  // Function for Assignment 2: Adding New Elements
  function addListItem() {
    var ul = document.getElementById('myList');
    var li = document.createElement('li');
    li.textContent = 'New Item';
    ul.appendChild(li);
  }
  
  // Function for Assignment 3: Removing Elements
  function removeListItem() {
    var list = document.getElementById('myList2');
    list.removeChild(list.lastChild);
  }
  
  // Function for Assignment 4: Changing Styles
  function changeColor() {
    document.getElementById('colorBox').style.backgroundColor = 'blue';
  }
  
  // Function for Assignment 5: Form Validation
  function validateForm() {
    var email = document.getElementById('email').value;
    var message = document.getElementById('message');
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (emailPattern.test(email)) {
      message.textContent = 'Valid email address.';
      return true;
    } else {
      message.textContent = 'Invalid email address.';
      return false;
    }
  }
  
  // Function for Assignment 6: Toggling Visibility
  function toggleVisibility() {
    var div = document.getElementById('toggleDiv');
    div.style.display = div.style.display === 'none' ? 'block' : 'none';
  }
  
  // Function for Assignment 7: Updating Attributes
  function changeImage() {
    var img = document.getElementById('myImage');
    img.src = img.src === 'C:\\Users\\kc110396\\Desktop\\Assignment\\6\\images (1).jfif' ? 'C:\\Users\\kc110396\\Desktop\\Assignment\\6\\images (2).jfif' : 'C:\\Users\\kc110396\\Desktop\\Assignment\\6\\images (1).jfif';
  }
  
  // Function for Assignment 8: Event Listener
  document.addEventListener('DOMContentLoaded', function() {
    var hoverDiv = document.getElementById('hoverDiv');
    hoverDiv.addEventListener('mouseover', function() {
      document.getElementById('hoverText').textContent = 'Text changed!';
    });
  });
  