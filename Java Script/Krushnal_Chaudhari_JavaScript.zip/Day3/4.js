function Vehicle(make, model) {
    this.make = make;
    this.model = model;
  }
  
  function Car(make, model) {
    Vehicle.call(this, make, model);
    this.wheels = 4;
  }
  
  Car.prototype = Object.create(Vehicle.prototype);
  Object.setPrototypeOf(Car.prototype, Vehicle.prototype);
  
  function Bike(make, model) {
    Vehicle.call(this, make, model);
    this.wheels = 2;
  }
  
  Bike.prototype = Object.create(Vehicle.prototype);
  Object.setPrototypeOf(Bike.prototype, Vehicle.prototype);
  
  var carObj = new Car('Toyota', 'Corolla');
  var bikeObj = new Bike('Yamaha', 'FZ');
  
  console.log(typeof carObj); 
  console.log(carObj instanceof Vehicle); 
  console.log(carObj instanceof Car); 
  console.log(carObj instanceof Bike);
  
  console.log(typeof bikeObj); 
  console.log(bikeObj instanceof Vehicle); 
  console.log(bikeObj instanceof Car);
  console.log(bikeObj instanceof Bike); 
  
  console.log(carObj.constructor === Car); 
  console.log(bikeObj.constructor === Bike); 
  
  console.log(Object.getPrototypeOf(carObj) === Car.prototype); 
  console.log(Object.getPrototypeOf(bikeObj) === Bike.prototype);   