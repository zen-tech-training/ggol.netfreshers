function addListItem(){
    var li = document.createElement('li');
    li.innerText = 'Item 3';
    document.getElementById('myList').appendChild(li);
}