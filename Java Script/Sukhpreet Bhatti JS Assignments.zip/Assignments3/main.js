// 1. Write an overloaded function in javascript that would take care of 
// 	Addition of 2 numbers
// 	Addition of 3 numbers and 
// 	Addition of 4 numbers.

function twoArguments(arg1, arg2) {
  return arg1 + arg2;
}

function threeArguments(arg1, arg2, arg3) {
  return arg1 + arg2 + arg3;
}

function forthArguments(arg1, arg2, arg3, arg4) {
  return arg1 + arg2 + arg3 + arg4;
}


function overloadedFun(...x) {
  if (arguments.length === 4) {
    return forthArguments(arguments[0]);
  } else if (arguments.length === 2) {
    return twoArguments(arguments[0], arguments[1]);
  } else if (arguments.length === 3) {
    return threeArguments(arguments[0], arguments[1], arguments[2]);
  }
}

// console.log(overloadedFun(1, 2));
// console.log(overloadedFun(1, 2, 3));
// console.log(overloadedFun(1, 2, 3, 4));


// 2. Write an overloaded function in javascript that would take care of
// Function with two strings
// Function with two numbers
// Function with three numbers
// Function with one String and one number
// And common implementation for the rest of all combinations.


function overloadedFunction() {
  if (arguments.length === 2) {
    if (typeof arguments[0] === 'string' && typeof arguments[1] === 'string') {
      console.log('Function with two strings');
      // Your implementation here
    } else if (typeof arguments[0] === 'number' && typeof arguments[1] === 'number') {
      console.log('Function with two numbers');
      // Your implementation here
    } else if ((typeof arguments[0] === 'string' && typeof arguments[1] === 'number') || (typeof arguments[0] === 'number' && typeof arguments[1] === 'string')) {
      console.log('Function with one string and one number');
      // Your implementation here
    } else {
      console.log('Common implementation for other combinations');
      // Your implementation here
    }
  } else if (arguments.length === 3 && typeof arguments[0] === 'number' && typeof arguments[1] === 'number' && typeof arguments[2] === 'number') {
    console.log('Function with three numbers');
    // Your implementation here
  } else {
    console.log('Common implementation for other combinations');
    // Your implementation here
  }
}


// Runtime Type Information

function Vehicle(make, model) {
  this.make = make;
  this.model = model;
}

function Car(make, model) {
  Vehicle.call(this,make,model);
  this.wheels = 4;
}

Car.prototype = new Vehicle();
Car.prototype.constructor = Car;

function Bike(make, model) {
  Vehicle.call(this,make,model);
  this.wheels = 2;
}

Bike.prototype = new Vehicle();
Bike.prototype.constructor = Bike;


const car = new Car('Tata','Nexon');
const bike = new Bike('TVS','Apache');

// console.log(typeof car);
// console.log(typeof bike);

// console.log(car instanceof Vehicle);
// console.log(car instanceof Car);
// console.log(car instanceof Bike);

// console.log(bike instanceof Vehicle);
// console.log(bike instanceof Car);
// console.log(bike instanceof Bike);

// console.log(car.constructor);
// console.log(bike.constructor);

// console.log(Object.getPrototypeOf(car)===Car.prototype);
// console.log(Object.getPrototypeOf(bike)===Bike.prototype);

