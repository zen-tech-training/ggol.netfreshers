function changeText(){
    document.getElementById('text').innerText = 'The text is changed';
}