document.getElementById('hoverDiv').addEventListener('mouseover', ()=>{
    document.getElementById('hoverText').innerText = 'changed';
});