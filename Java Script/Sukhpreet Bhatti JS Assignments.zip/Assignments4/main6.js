function changeImage(){
    document.getElementById('myImage').attributes[1] = 'image2.jpg';
}