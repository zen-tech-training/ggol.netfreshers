// 1: Reverse a String
function reverse(st){
    let res = '';
    for (x=st.length-1;x>=0;x--){
        res = res + st[x]
    }
    return res
}
console.log(reverse('hello'));

// 2: Find the Largest Number in an Array
function largest(arr){
    if (arr.length==0){
        return -1;
    }
    var mx = arr[0];
    for (x in arr){
        if (arr[x]>=mx){
            mx = arr[x];
        }
    }
    return mx;
}
console.log(largest([3,4,8,2,9]));

// 3: Check if a String is a Palindrome
function palindrome(st){
    var i = 0;
    var j = st.length - 1;
    while (i<j){
        if (st[i]===st[j]){
            i+=1;
            j-=1;
        }
        else{
            return 'Given string is not Palindrome';
        }
        return 'Given string is Palindrome';
    }
}
console.log(palindrome('abcdcba'));

// 4: Filter Array of Objects
function filterArr(people) {
    return people.filter(person => person.age > 18);
}

const peopleArray = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 17 },
    { name: 'Charlie', age: 30 },
];

console.log(filterArr(peopleArray)); 

// 5: Sum of All Numbers in an Array
function sum(arr){
    var res = 0
    for (x of arr){
        res+=x;
    }
    return res;
}

console.log(sum([4,5,3,8,9,0,-2,-5]));

// 6: Remove Duplicates from an Array
function duplicate(arr){
    var cnt  = {};
    var res = [];
    for (var x of arr){
        if (!cnt[x]){
            cnt[x] = 1;
            res.push(x);
        }
    }
    return res;
}

console.log(duplicate([3,5,8,4,3,8,1,0,0]));

// 8: Find Intersection of Two Arrays
function intersection(arr1, arr2) {
    const set1 = new Set(arr1);
    const intersection = [];

    for (const item of arr2) {
        if (set1.has(item)) {
            intersection.push(item);
        }
    }

    return intersection;
}
console.log(intersection([1, 2, 3, 4],[3, 4, 5, 6]));

// 9: Convert an Object to an Array of Key-Value Pairs
function convert(obj){

    res = [];
    for (const key in obj){
        res.push([key,obj[key]]);
    }
    return res;
}
var obj = {name: 'John', age: 30};
console.log(convert(obj));

// 10: Sort an Array of Objects by a Property
function sortObject(people) {
    const n = people.length;

    for (let i = 0; i < n - 1; i++) {
        for (let j = 0; j < n - i - 1; j++) {
            if (people[j].age > people[j + 1].age) {
                const temp = people[j];
                people[j] = people[j + 1];
                people[j + 1] = temp;
            }
        }
    }
    return people;
}

const peoples = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 30 },
    { name: 'Charlie', age: 20 },
];

const sortedPeople = sortObject(peoples);
console.log(sortedPeople);