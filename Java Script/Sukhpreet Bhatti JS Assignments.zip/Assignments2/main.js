//1---
let car = {
    make: 'Toyota',
    model: 'Corolla',
    year: 2005,
    getCarInfo: function () {
        return this.make + ' ' + this.model + ', ' + this.year;
    }
};

//2 ----
function Animal(name, sound) {
    this.name = name;
    this.sound = sound;
}

Animal.prototype.makeSound = function () {
    console.log(this.sound);
};

function Dog(name, sound) {
    Animal.call(this, name, sound);
}

Dog.prototype = Object.create(Animal.prototype);

Dog.prototype.fetch = function () {
    console.log(this.name + ' is fetching!');
};


//3----
function BankAccount(initialBalance) {
    let balance = initialBalance;

    this.deposit = function (amount) {
        balance += amount;
    };

    this.withdraw = function (amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            console.log('Insufficient balance');
        }
    };

    this.getBalance = function () {
        return balance;
    };
}


//4----

function Shape() { }

Shape.prototype.getArea = function () {
    return 0;
};

function Circle(radius) {
    this.radius = radius;
}

Circle.prototype = Object.create(Shape.prototype);

Circle.prototype.getArea = function () {
    return Math.PI * this.radius * this.radius;
};

function Rectangle(width, height) {
    this.width = width;
    this.height = height;
}

Rectangle.prototype = Object.create(Shape.prototype);

Rectangle.prototype.getArea = function () {
    return this.width * this.height;
};


// 5---
function Vehicle(make, model, year) {
    this.make = make;
    this.model = model;
    this.year = year;
}

Vehicle.prototype.getDetails = function () {
    return this.make + ' ' + this.model + ', ' + this.year;
};

function Car(make, model, year, doors) {
    Vehicle.call(this, make, model, year);
    this.doors = doors;
}

Car.prototype = Object.create(Vehicle.prototype);

Car.prototype.getDetails = function () {
    return Vehicle.prototype.getDetails.call(this) + ', ' + this.doors + ' doors';
};


//6---
function MathUtil() { }

MathUtil.add = function (a, b) {
    return a + b;
};

MathUtil.subtract = function (a, b) {
    return a - b;
};

MathUtil.multiply = function (a, b) {
    return a * b;
};

MathUtil.divide = function (a, b) {
    if (b !== 0) {
        return a / b;
    } else {
        console.log('Cannot divide by zero');
    }
};


// 7---

function Book(title, author, year) {
    this.title = title;
    this.author = author;
    this.year = year;
}

Object.defineProperty(Book.prototype, 'getSummary', {
    get: function () {
        return this.title + ' by ' + this.author + ', published in ' + this.year;
    }
});

Object.defineProperty(Book.prototype, 'setYear', {
    set: function (newYear) {
        this.year = newYear;
        console.log('Year set to ' + newYear);
    }
});

//   8---


function User(username, password) {
    this.username = username;
    this.password = password;
    this.address = new Address('123 Main St', 'Anytown', 'USA');
}

function Address(street, city, country) {
    this.street = street;
    this.city = city;
    this.country = country;
}

User.prototype.getAddress = function () {
    return this.address.street + ', ' + this.address.city + ', ' + this.address.country;
};


// 9--

function Shape() {}

Shape.prototype.getArea = function() {
  return 0;
};

function Square(sideLength) {
  this.sideLength = sideLength;
}

Square.prototype = Object.create(Shape.prototype);

Square.prototype.getArea = function() {
  return this.sideLength * this.sideLength;
};

function Triangle(base, height) {
  this.base = base;
  this.height = height;
}

Triangle.prototype = Object.create(Shape.prototype);

Triangle.prototype.getArea = function() {
  return 0.5 * this.base * this.height;
};


