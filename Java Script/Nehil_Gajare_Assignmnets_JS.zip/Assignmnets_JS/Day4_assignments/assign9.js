function openModal(){
    var modal = document.getElementById('myModal')
    modal.style.display='block'
}
function closeModal(){
    var modal = document.getElementById('myModal')
    modal.style.display='none'
}