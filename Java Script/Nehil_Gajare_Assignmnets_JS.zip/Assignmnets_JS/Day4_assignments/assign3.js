function removeListItem(){

    var ul = document.getElementById('myList');
    const lists = document.getElementsByTagName('li')
    ul.removeChild(lists[lists.length-1])
    // console.log(lists);
}