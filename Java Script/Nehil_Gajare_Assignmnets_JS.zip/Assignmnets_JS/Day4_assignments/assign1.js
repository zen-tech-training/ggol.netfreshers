function changeText(){
    document.getElementById('text').innerHTML="Text Changed!!"
}