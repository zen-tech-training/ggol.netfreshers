function changeColor(){
    var colorDiv = document.getElementById('colorBox')
    colorDiv.style.backgroundColor='red'
}