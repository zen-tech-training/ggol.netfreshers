
function fetchWithErrorHandling() {

    var url = "https://jsonplaceholder.typicode.com/invalid-url"

    
    var method='GET';

    const output = new Promise(function(resolve,reject){
        var xhttp = new XMLHttpRequest();
        xhttp.open(method,url,true);

        xhttp.onreadystatechange = function(){
            if(xhttp.readyState === 4 && xhttp.status===200){
                resolve(JSON.parse(xhttp.responseText));
            }
            else{
                reject(new Error("Request failed with error status:"+xhttp.status));
            }
        }

        xhttp.send();

    })

    output.then((res)=>{
        document.getElementById('message').innerText=res;
    }).catch((err)=>{
        document.getElementById('message').innerText=err;
    })

    
}