function fetchListOfItems(){
    var url ='https://jsonplaceholder.typicode.com/posts';

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function(){
        if(xhttp.readyState === 4 && xhttp.status===200){
            var result = JSON.parse(xhttp.responseText);
            // console.log(result);
            showArr(result)
        }
    }

    xhttp.open('GET',url,true)

    xhttp.send();
}

function showArr(res){
    
    var ul = document.getElementById('itemList');

    for(var i in res){
        console.log(res[i]);
        var li = document.createElement('li');
        li.innerText = res[i].userId+" "+res[i].id+" "+res[i].title;
        li.style.backgroundColor = 'lightblue'
        ul.appendChild(li)
    }


}