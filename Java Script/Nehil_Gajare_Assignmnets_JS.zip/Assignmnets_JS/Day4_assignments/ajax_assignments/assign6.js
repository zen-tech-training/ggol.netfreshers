var url ="https://jsonplaceholder.typicode.com/posts"
// var out=""
var output= {}
var count=1
function showArr(res){
    
    for(var i in res){
        // out=res[i].userId+" "+res[i].id+" "+res[i].title
        output[count]={
            userId:res[i].userId,
            id:res[i].id,
            title:res[i].title
        }
        count+=1
    }
    for(var i in output){
        console.log(output[i]);
    }
    // console.log(output);
}

function getPost(){
    var xhttp = new XMLHttpRequest();

    

    xhttp.onreadystatechange = function(){
        if(xhttp.readyState === 4 && xhttp.status===200){
            var res = JSON.parse(xhttp.responseText)
            // console.log(res);
            showArr(res)
        }
    }

    xhttp.open('GET',url,true);
    xhttp.send();
}

function createPost(){
    var xHttp = new XMLHttpRequest();
    // var url = "https://jsonplaceholder.typicode.com/posts"
    

    xHttp.onreadystatechange = function(){
        if(xHttp.readyState === 4 && xHttp.status === 201){
            console.log(xHttp.responseText);
            const resp =JSON.parse(xHttp.responseText)
            output[count]={
                userId:resp.userId,
                id:resp.id,
                title:resp.title
            }
            count+=1
            for(var i in output){
                console.log(output[i]);
            }
            // const newPostId = resp.id;
        }
    }

    xHttp.open("POST",url,true)
    xHttp.setRequestHeader('Content-Type','application/json;charset=UTF-8');

    xHttp.send(JSON.stringify({
        userId:1,
        title:"New Title",
        body:"This is new body"
    }))
}

function deletePost(){
    var idd = document.getElementById('delete').value
    console.log(idd);
    for(var i in output){
        // console.log(output[i]);
        if(idd == output[i].id){
            delete output[i]
        }
    }
    for(var i in output){
        console.log(output[i]);
    }

}

function updatePost(){
    var up = document.getElementById('update').value
    var upId = document.getElementById('updateId').value
    // console.log(typeof upId , typeof output[99].id);
    for(var i in output){
        if(output[i].id == upId){
            console.log(("avdsdc"));
            output[i].title = up
        }
        else{
            console.log("Id not found");
        }
    }
    for(var i in output){
        console.log(output[i]);
    }
    // console.log((up));
}