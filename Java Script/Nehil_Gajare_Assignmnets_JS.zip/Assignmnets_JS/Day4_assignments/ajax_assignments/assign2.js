
function fetchJsonData() {

    var url = "https://jsonplaceholder.typicode.com/posts/1"

    xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (xhttp.readyState === 4 && xhttp.status === 200) {
            var res = xhttp.responseText
            var resjson = JSON.parse(res);
            document.getElementById('title').innerText = resjson.title
            document.getElementById('body').innerText = resjson.body
        } 
    }
    xhttp.open('GET', url, true)
    xhttp.send()
}