function makePostRequest(){
    var xHttp = new XMLHttpRequest();
    var url = "https://jsonplaceholder.typicode.com/posts"
    

    xHttp.onreadystatechange = function(){
        if(xHttp.readyState === 4 && xHttp.status === 201){
            // console.log(xHttp.responseText);
            const resp =JSON.parse(xHttp.responseText)
            out+="<br/>"+resp.userId+" "+resp.id+" "+resp.title
            document.getElementById('postResponse').innerHTML=out
            // console.log("new data added:"+out);
            const newPostId = resp.id;
        }
    }

    xHttp.open("POST",url,true)
    xHttp.setRequestHeader('Content-Type','application/json;charset=UTF-8');

    xHttp.send(JSON.stringify({
        userId:11,
        title:"New Title added",
        body:"This is new body"
    }))
    loadArr()
}
document.onreadystatechange = loadArr;
var out=""
function showArr(resjson){
    
    for(var i in resjson){
        out+= "<br/>"+resjson[i].userId+" "+resjson[i].id+" "+resjson[i].title
    }
    document.getElementById('postResponse').innerHTML=out
}

function loadArr(){
    var url = "https://jsonplaceholder.typicode.com/posts"

    xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (xhttp.readyState === 4 && xhttp.status === 200) {
            var res = xhttp.responseText
            var resjson = JSON.parse(res);
            showArr(resjson)
        }
    }
    xhttp.open('GET', url, true)
    xhttp.send()
}