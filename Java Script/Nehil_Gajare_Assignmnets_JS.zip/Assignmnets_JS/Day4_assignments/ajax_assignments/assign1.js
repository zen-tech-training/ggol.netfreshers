
function makeGetRequest() {

    var url = "https://jsonplaceholder.typicode.com/posts/1"

    xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (xhttp.readyState === 4 && xhttp.status === 200) {
            document.getElementById('response').innerHTML =(xhttp.responseText)
        }
    }
    xhttp.open('GET', url, true)
    xhttp.send() 
}