const d = document.getElementById('hoverDiv')
var p = document.getElementById('hoverText')
d.addEventListener('mouseover',func)
d.addEventListener('mouseleave',outfunc)
function func(){
    p.innerText = "Text is changed after hovering"
}
function outfunc(){
    p.innerText="Hover over the box to change this text"
}