
var form = document.getElementById("myForm");
function validateForm(event) { 
    event.preventDefault(); 
    var emailInput = document.getElementById('email').value
    console.log(emailInput);
} 
form.addEventListener('submit', validateForm);



