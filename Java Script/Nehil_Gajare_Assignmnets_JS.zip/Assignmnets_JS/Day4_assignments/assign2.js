var x=3
function addListItem(){
    var ul = document.getElementById('myList')
    var li = document.createElement("li");
    // var x=3
    li.innerHTML='Item'+x
    li.style.backgroundColor='peachpuff'
    ul.appendChild(li)
    x+=1
}