function changeImage(){
    document.getElementById('myImage').src='OIP2.jfif'
    // img.getAttribute('src')='./OIP2.jfif';
}