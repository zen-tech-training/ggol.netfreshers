

function toggleVisibility(){
   
    var div = document.getElementById('toggleDiv');
    if(div.style.display === 'block'){
        div.style.display = 'none';
    }
    else{
        div.style.display='block';
    }
    
    // bool=false;

}