function removeDups(){
    const arr = [1,2,3,2,1,3,4,2];
    const ans = arr.filter((item,index)=>arr.indexOf(item)==index);
    console.log(ans);

}

removeDups();