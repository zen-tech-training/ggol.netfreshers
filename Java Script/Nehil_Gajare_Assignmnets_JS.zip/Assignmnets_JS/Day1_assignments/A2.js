function largestNumber(){
    var arr=[1,2,3,4,78,56,13];
    var temp=arr[0];
    for(var i=0;i<arr.length;i++){
        if(temp<arr[i]){
            temp=arr[i];
        }
    }
    console.log(temp);
}
largestNumber();