function sumOfArray(){
    const arr = [1,2,3,4,5]
    var temp=0;
    for(var i=0;i<arr.length;i++){
        temp=temp+arr[i]
    }
    console.log(temp);
}
sumOfArray()