function flattenArray(arr){
    
    var result=[]
    for(var i=0;i<arr.length;i++){
        if(arr[i].length>=1){
            result=result.concat(flattenArray(arr[i]));
            console.log(result);
        }
        else{
            result.push(arr[i]);
        }
    }
    return result;
}
var nestedArray = [1, [2, 3], [4, [5, 6]]]
console.log(flattenArray(nestedArray));