function filterArrayOfObjects(){
    const objects = [
        { name: 'Raj', age: 20 },
        { name: 'Eram', age: 24 },
        { name: 'John', age: 18 },
        { name: 'Luke', age: 10 },
        { name: 'Mike', age: 32 }
      ];
    const filteredArray=objects.filter(obj => obj.age>18);
    console.log(filteredArray);
}

filterArrayOfObjects();