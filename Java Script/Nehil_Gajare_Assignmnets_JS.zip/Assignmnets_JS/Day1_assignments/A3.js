function checkPalindrome(str){
    var flag=0;
    for(var i=0;i<str.length/2;i++){
        if(str[i]!=str[str.length-i-1]){
            flag=1;
        }
    }
    if(flag==1){
        console.log("Not a Palindrome");
    }
    else{
        console.log("Yes it is a Palindrome!");
    }
}

checkPalindrome("nehen")