function sortObj(){

    const people = [
        { name: 'Alice', age: 20 },
        { name: 'Bob', age: 40 },
        { name: 'Charlie', age: 35 }
    ];

    people.sort((a,b)=> a.age-b.age);
    // people.sort((a,b)=> b.age-a.age);
    console.log(people);
    
}
sortObj()