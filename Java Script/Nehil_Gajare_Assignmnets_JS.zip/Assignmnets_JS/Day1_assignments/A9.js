function objectToArray(obj){
    return Object.entries(obj)
}

var obj = {name: 'John', age: 30};

var result = objectToArray(obj);
console.log(result);