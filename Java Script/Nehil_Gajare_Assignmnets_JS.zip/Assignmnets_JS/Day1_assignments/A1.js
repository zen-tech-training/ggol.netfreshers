// var str = "nehil"

function reverseString(str){
    var len=str.length;
    // console.log(len);
    var rev="";
    for(var i=len-1;i>=0;i--){
        rev=rev+str[i]
    }
    console.log(rev);
}

reverseString("nehil")
// console.log();

