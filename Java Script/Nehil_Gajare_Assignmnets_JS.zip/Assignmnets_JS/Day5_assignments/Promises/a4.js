function taskA(){
    return new Promise((resolve,reject)=>{
        setTimeout(function(){
            resolve("Task A Completed")
        },1000)
    })
}
function taskB(){
    return new Promise((resolve,reject)=>{
        setTimeout(function(){
            resolve("Task B Completed")
        },3000)
    })
}
function taskC(){
    return new Promise((resolve,reject)=>{
        setTimeout(function(){
            resolve("Task C Completed")
        },500)
    })
}

Promise.all([taskA(),taskB(),taskC()]).then((values)=>{
    console.log(values);
}).catch((err)=>console.error(err))