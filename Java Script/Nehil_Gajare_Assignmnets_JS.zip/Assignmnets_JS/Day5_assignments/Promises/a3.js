var res=parseInt(Math.random()*10);
console.log(res);
function errorProneTask(){
    return new Promise((resolve,reject)=>{
        // console.log("res : "+res);
        if(res%2){
            resolve("Promise resolved successfully !")
        }
        else{
            reject("Promise rejected !")
        }
    })
}

errorProneTask().then((output)=>{
    console.log(output);
}).catch((err)=>console.log(err))
