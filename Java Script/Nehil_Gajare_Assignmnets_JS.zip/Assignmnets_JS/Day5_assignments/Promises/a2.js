function task1(){
    return new Promise((resolve,reject)=>{
        setTimeout(function(){
            resolve("Task 1 Completed")
        },1000)
    })
}
function task2(){
    return new Promise((resolve,reject)=>{
        setTimeout(function(){
            resolve("Task 2 Completed")
        },3000)
    })
}
function task3(){
    return new Promise((resolve,reject)=>{
        setTimeout(function(){
            resolve("Task 3 Completed")
        },500)
    })
}

task1().then(function(result1){
    console.log(result1);
    return task2();
}).then(function(result2){
    console.log(result2);
    return task3();
}).then(function(result3){
    console.log(result3);
})