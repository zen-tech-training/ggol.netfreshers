function wait(ms){
    return new Promise((resolve,reject)=>{
        setTimeout(function(){
            resolve(`Completed after ${ms} milliseconds`)
        },ms)

        // reject("Promise rejected")
    })
}

wait(3000).then((output)=>console.log(output))
wait(7000).then((output)=>console.log(output))