
// console.log(todoInput);

document.getElementById('addTodoButton').onclick = function(){
    var todoInput = document.getElementById('todoInput').value;
    // console.log(todoInput);

    var ul = document.getElementById('todoList')

    const newDiv = document.createElement('div');
    var li = document.createElement('li')
    const removeTodo = document.createElement('button')
    const strike = document.createElement('button')

    newDiv.classList.add("todo-div")
    
    newDiv.appendChild(li);
    newDiv.appendChild(strike)
    newDiv.appendChild(removeTodo)

    strike.textContent = 'Done'
    strike.onclick = function(){
        li.style.textDecoration = 'line-through'
    }

    removeTodo.textContent = 'Remove'
    removeTodo.onclick = function(){
        // ul.removeChild(li)
        // ul.removeChild(removeTodo)
        ul.removeChild(newDiv)
    }

    li.innerText=todoInput;
    ul.appendChild(newDiv)
    // ul.appendChild(removeTodo)
    document.getElementById('todoInput').value=""
    // todoInput.innerText=""
}

