async function fetchData(){
    var url ="https://jsonplaceholder.typicode.com/users/1"

    await setTimeout(function(){
        console.log("Data Fetched!");
    },2000)

    // return output
}
fetchData()