async function fetchPosts(){
    var url="https://jsonplaceholder.typicode.com/posts"
    try {
        const response = await fetch(url)
        const output = await response.json()
        console.log(output);
    } catch (error) {
        console.log("Error while fetching data :"+error);
    }
     
}

async function fetchComments(){
    const response = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1')
    const output = await response.json()
    console.log(output);
}

async function fetchAllData(){
    await fetchPosts();
    await fetchComments();
}

fetchAllData();