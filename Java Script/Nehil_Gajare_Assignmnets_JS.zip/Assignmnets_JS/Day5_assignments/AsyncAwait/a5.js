async function fetchPosts(){
    var url="https://jsonplaceholder.typicode.com/posts"
    try {
        const response = await fetch(url)
        const output = await response.json()
        return output
        // console.log(output);
    } catch (error) {
        console.log("Error while fetching data :"+error);
    }
     
}

async function fetchComments(){
    const response = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1')
    const output = await response.json()
    return output
    // console.log(output);
}

async function fetchAllData(){
    // await fetchPosts();
    // await fetchComments();

    const [posts,comments] = await Promise.all([fetchPosts(),fetchComments()])
    // results.forEach((result)=> console.log(result))
    console.log("Posts :",posts);
    console.log("Comments :",comments);
    // console.log(result);
}

fetchAllData();