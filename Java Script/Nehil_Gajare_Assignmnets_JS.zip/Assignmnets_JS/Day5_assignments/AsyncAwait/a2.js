async function getUserData(){
    var url ="https://jsonplaceholder.typicode.com/users/1"
    const response = await fetch(url)
    const output = await response.json()
    console.log(output);
}

getUserData()