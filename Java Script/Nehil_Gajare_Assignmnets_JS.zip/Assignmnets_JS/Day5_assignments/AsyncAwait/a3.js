async function getUserData() {
    var url = "https://jsonplaceholder.typicde.com/users/1"
    try {
        const response = await fetch(url)
        const output = await response.json()
        console.log(output);
    } catch (error) {
        console.log("Error while fetching data :"+error);
    }

}

getUserData()