/*
function BankAccount(){
    var balance=1000;
    this.deposit = function(amount){
        balance = balance+amount;
        return balance;
    }
    this.withdraw = function(amount){
        if(amount>balance){
            return "No Balance";
        }
        else{
            balance = balance-amount;
        }
        return balance;
    }
    this.getBalance = function(){
        return "Current balance in account is : "+balance;
    }
}

var b1 = new BankAccount();
console.log("Deposit "+b1.deposit(500));

console.log("Withdraw "+b1.withdraw(200));

console.log(b1.getBalance()); */

//---------------------------------------------------------
//Q4

function Shape(){
    
}

Shape.prototype.getArea = function(){
    return 0;
}

Circle.prototype = new Shape();
Circle.prototype.constructor = Circle;

Rectangle.prototype = new Shape();
Rectangle.prototype.constructor = Rectangle;

function Circle(radius){
    this.radius=radius;
}
Circle.prototype.getArea = function(){
    return 3.14 * this.radius * this.radius;
}

function Rectangle(length,breadth){
    this.length=length;
    this.breadth=breadth;
}
Rectangle.prototype.getArea = function(){
    return this.length * this.breadth;
}

var cir = new Circle(2);
var rec = new Rectangle(3,4);
// console.log(cir);

function showArea(obj){
    obj.getArea();
}

console.log(showArea(cir));
console.log(showArea(rec));