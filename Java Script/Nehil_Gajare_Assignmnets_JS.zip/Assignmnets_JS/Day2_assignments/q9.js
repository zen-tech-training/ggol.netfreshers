// function Shape(){
//     this.getArea = function(){
//         return 0;
//     }
// }


// function Square(side){
//     Shape.call(this);
//     this.side=side;
//     this.getArea=function(){
//         return this.side*this.side;
//     }
// }

// function Triangle(base,height){
//     Shape.call(this);
//     this.base=base;
//     this.height=height;
//     this.getArea = function(){
//         return 0.5* this.base * this.height;
//     }
// }

// var sq = new Square(5);
// var tri = new Triangle(3,4);

// console.log("Area of square : ",sq.getArea());
// console.log("Area of triangle : ",tri.getArea());

//-----------------------------------------------------------------------------------
//q10

let flyableMixin = {
    fly : function(){
        return "It flies"
    }
}
let swimmableMixin = {
    swim : function(){
        return "It swims";
    }
}

function Duck(name){
    this.name=name;
}

console.log(Duck);
// console.log(Duck.prototype);
Duck.prototype=Object.assign(Duck.prototype,flyableMixin,swimmableMixin)
// console.log(Duck.prototype);

var duck = new Duck("Donald");
console.log(duck.fly());
console.log(duck.swim());

