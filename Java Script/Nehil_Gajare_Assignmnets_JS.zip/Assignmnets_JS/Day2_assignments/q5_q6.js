// function Vehicle(make,model,year){
//     this.make=make;
//     this.model=model;
//     this.year=year;
// }

// Vehicle.prototype.getDetails = function(){
//     return "This "+this.model+" model of "+this.make+" car launched on "+this.year;
// }

// Car.prototype = new Vehicle()
// Car.prototype.constructor = Car;

// function Car(make,model,year,doors){
//     this.make=make;
//     this.model=model;
//     this.year=year;
//     this.doors=doors;
// }
// Car.prototype.getDetails = function(){
//     return "This "+this.model+" model of "+this.make+" car launched on "+this.year+" has "+this.doors+" doors."
// }

// var vehicle = new Vehicle("BMW","Q3","2024")
// var car = new Car("BMW","Q3","2024",4)

// function details(obj){
//     console.log(obj.getDetails()); 
// }

// details(vehicle);
// details(car);

//--------------------------------------------------------------------------------
//Q6

function MathUtil(){
    
}

MathUtil.add =function(num1,num2){
    return num1+num2;
}
MathUtil.sub =function(num1,num2){
    return num1-num2;
}

MathUtil.mult =function(num1,num2){
    return num1*num2;
}
MathUtil.div =function(num1,num2){
    return num1%num2;
}

document.write("Addition : "+MathUtil.add(3,4));
document.write("<br/>")
document.write(" Subtraction : "+MathUtil.sub(3,4));
document.write("<br/>")
document.write("Multiplication : "+MathUtil.mult(3,4));
document.write("<br/>")
document.write("Division : "+MathUtil.div(3,4));