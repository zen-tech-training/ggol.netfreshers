// function Book(){
//     var title;
//     var author;
//     var year;
//     this.getDetails = function(title,author,year){

//         return "This "+this.title+" has written by "+this.author+" in "+this.year;
//     }
//     this.setYear = function(ye){
//         this.year=ye;
//         return "The year is set to : "+this.year
//     }
// }

// var book = new Book()

// console.log(book.getDetails("Do Epic Shit","Ankur Warikoo","2021"));
// console.log(book.setYear(2023));
// console.log(book.getDetails());

//---------------------------------------------------------------------------------------------------
//Q8


function Address(street,city,country){
    this.street=street;
    this.city=city;
    this.country=country;
}

function User(username,password,street,city,country){
    this.username=username;
    this.password=password;
    this.address = new Address(street,city,country);
}

User.prototype.getAddress = function(){
    return this.address.street+" , "+this.address.city+" , "+this.address.country
}

var user = new User("nehil_82",1234,"KP","Pune","India")
// var address = new Address("KP","Pune","India")
console.log(user.getAddress());