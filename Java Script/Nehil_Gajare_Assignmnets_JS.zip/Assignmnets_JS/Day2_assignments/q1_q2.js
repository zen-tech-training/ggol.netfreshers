// var car = {
//     make:"BMW",
//     model:"Q3",
//     year:"2023",
//     getInfo : function(){
//         return "This "+this.model+" model of "+this.make+" car launched on "+this.year
//     }
// }

// document.write(car.getInfo())


//-------------------------------------------------------------------------
//q2

function Animal(name,sound){
    this.name=name;
    this.sound=sound;
}

Animal.prototype.makeSound = function(){
    return "Sound : "+this.sound;
}

// var ani = new Animal("cat","meow");
// console.log(ani.makeSound());

Dog.prototype = new Animal("Dog","barks");
Dog.prototype.constructor = Dog;


function Dog(){
}

Dog.prototype.fetch = function(){
    return this.name+" "+this.sound+" and then fetches ball";
}

var dog = new Dog();
console.log(dog.makeSound());
console.log(dog.fetch());