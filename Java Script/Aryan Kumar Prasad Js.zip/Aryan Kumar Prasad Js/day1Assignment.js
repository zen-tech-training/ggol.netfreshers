// 1: Reverse a String

// Problem: Write a function to reverse a given string.

function reverseString(str) {
    return str.split("").reverse().join("");
}

console.log(reverseString("hello"));

// 2: Find the Largest Number in an Array

// Problem: Write a function to find the largest number in an array.

function findLargestNumber(arr) {
    let largest = arr[0];
    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > largest) {
            largest = arr[i];
        }
    }
    return largest;
}

let numbers = [3, 5, 7, 2, 8];
const largestNumber = findLargestNumber(numbers);
console.log(largestNumber); // Output: 8


// 3: Check if a String is a Palindrome

// Problem: Write a function to check if a given string is a palindrome.

function isPalindrome(str) {
    const reversedStr = str.split('').reverse().join('');
    return str === reversedStr;
}


const inputString = "malayalam";
let result = isPalindrome(inputString);
console.log(result); 


// 4: Filter Array of Objects

// Problem: Write a function to filter an array of objects based on a specified condition.

// People array with name and age and where age is greater than 18.

function filterAdults(people) {
    return people.filter(person => person.age > 18);
}

let people = [
    { name: 'John', age: 25 },
    { name: 'Jane', age: 17 },
    { name: 'Mike', age: 20 },
    { name: 'Sara', age: 15 }
];

const adults = filterAdults(people);
console.log(adults);
// Output: [{ name: 'John', age: 25 }, { name: 'Mike', age: 20 }]


// 5: Sum of All Numbers in an Array

// Problem: Write a function to calculate the sum of all numbers in an array.

function sumArray(arr) {
    return arr.reduce((total, current) => total + current, 0);
}

// Example usage:
 numbers = [1, 2, 3, 4, 5];
const totalSum = sumArray(numbers);
console.log(totalSum); // Output: 15


// 6: Remove Duplicates from an Array

// Problem: Write a function to remove duplicates from an array.

function removeDuplicates(arr) {
    return [...new Set(arr)];
}

// Example usage:
const names = ["Mike", "Matt", "Nancy", "Adam", "Jenny", "Nancy", "Carl"];
const uniqueNames = removeDuplicates(names);
console.log(uniqueNames);
// Output: ["Mike", "Matt", "Nancy", "Adam", "Jenny", "Carl"]


// 7: Flatten a Nested Array

// Problem: Write a function to flatten a nested array.

// // Example usage:

// var nestedArray = [1, [2, 3], [4, [5, 6]]].

// var result = flattenArray(nestedArray).

// console.log(result); // Output: [1, 2, 3, 4, 5, 6]


function flatten(arr) {
    return arr.reduce((acc, val) => Array.isArray(val) ? acc.concat(flatten(val)) : acc.concat(val), []);
}

let nestedArray = [1, [2, 3], [4, [5, 6]]];
let flattenedResult = flatten(nestedArray);
console.log(flattenedResult); // Output: [1, 2, 3, 4, 5, 6]


// 8: Find Intersection of Two Arrays

// Problem: Write a function to find the intersection of two arrays.

// // Example usage:

// var array1 = [1, 2, 3, 4];

// var array2 = [3, 4, 5, 6];

// var result = findIntersection(array1, array2);

// console.log(result); // Output: [3, 4]


 nestedArray = [1, [2, 3], [4, [5, 6]]];
 flattenedResult = nestedArray.flat(Infinity);
console.log(flattenedResult);


// 9: Convert an Object to an Array of Key-Value Pairs

// Problem: Write a function to convert an object into an array of key-value pairs.

// // Example usage:

// var obj = {name: 'John', age: 30};

// var result = objectToArray(obj);

// console.log(result); // Output: [['name', 'John'], ['age', 30]]

function objectToArray(obj) {
    return Object.entries(obj);
}

// Example usage:
let person = { name: 'John', age: 30 };
 result = objectToArray(person);
console.log(result);

// 10: Sort an Array of Objects by a Property

// Problem: Write a function to sort an array of objects by a specified property.

// Consider People array with object having properties like name and age,

// Consider People array with objects having properties like name and age
 people = [
    { name: 'John', age: 25 },
    { name: 'Jane', age: 30 },
    { name: 'Mike', age: 22 },
    { name: 'Sara', age: 28 }
];

// Sort the array of objects by the 'age' property
const sortedPeople = people.sort((a, b) => a.age - b.age);

// Print the sorted array
for (let person of sortedPeople) {
    console.log(`Name: ${person.name}, Age: ${person.age}`);
}
