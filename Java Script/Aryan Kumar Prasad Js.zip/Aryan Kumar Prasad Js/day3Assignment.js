// 1. Go for Base class Vehicle.

// function Vehicle (make, model) {

// this.make = make;

// this.model = model;

// }

// And 2 derived classes

// function Car (make, model) {

// this.wheels = 4;

// }

// function Bike (make, model) {

// this.wheels = 2;

// }

// Do the inheritance with Vehicle and Car as well as on Vehicle and Bike

// Instantiate Car and Bike

// · Use type of to check the type of the Car and Bike Object

// · Use instance of to check Car Object is of type Vehicle, Car, or Bike

// · Use instance of to check Bike Object is of type Vehicle, Car, or Bike

// Use constructor property to see whether,

// · CarObject.constructor property pointing to also check whether,

// · BikeObject.constructor property pointing to

// Also check,

// · getPrototypeOf(carObj) is equal to Car.Prototype and

// · getPrototypeOf(bikeObj) is equal to Bike.Prototype

function Vehicle(make, model) {
  this.make = make;
  this.model = model;
}

Car.prototype = new Vehicle();
Car.prototype.constructor = Car;

function Car(make, model) {
  Vehicle.call(this, make, model);
  this.wheels = 4;
}

Bike.prototype = new Vehicle();
Bike.prototype.constructor = Bike;

function Bike(make, model) {
  Vehicle.call(this, make, model);
  this.wheels = 2;
}

const car = new Car("KIA", "SELTOS");
const bike = new Bike("TVS", "Apache");

console.log("The Type of Car  is : ", typeof car);
console.log("The Type of Bike  is : ", typeof bike);

if (car instanceof Car) {
  console.log("Instance of Car object : Car");
} else if (car instanceof Bike) {
  console.log("Instance of Car object : Bike");
} else if (car instanceof Vehicle) {
  console.log("Instance of Car object : Vehicle");
}

if (bike instanceof Car) {
  console.log("Instance of bike object : Car");
} else if (bike instanceof Bike) {
  console.log("Instance of bike object : Bike");
} else if (bike instanceof Vehicle) {
  console.log("Instance of bike object : Vehicle");
}

console.log(
  "CarObject.constructor property pointing to :",
  car.constructor.name
);
console.log(
  "BikeObject.constructor property pointing to :",
  bike.constructor.name
);

console.log(Object.getPrototypeOf(car) === Car.prototype);
console.log(Object.getPrototypeOf(bike) === Bike.prototype);

// Create a Shopping Cart Module, which would allow user to deal with cart data,

// Product in Shopping Cart would be with following details.

// productId, name, price, quantity

// Methods provided by Module are,

// addItem – Add Item would add one product item, if again called for the same product

// id, it would increase the quantity.

// removeItem – Remove product (all quantities by product id)

// getAllItems – Get all products details.

// getTotalPrice - Total Price of all items in the cart

let shoppingCart = (function () {
  var products = [];
  return {
    addItem: function (productId, name, price, quantity) {
      if (products.find((product) => product.productId === productId)) {
        console.log("Item exists");
        return;
      }
      const product = {
        productId,
        name,
        price,
        quantity,
      };
      products.push(product);
    },
    id: function (id, quantity) {
      const product = products.find((product) => product.productId === id);
      if (product) {
        product.quantity += quantity;
      } else {
        console.log("Id doesn't exist");
      }
    },
    removeItem: function (id) {
      products = products.filter((product) => product.productId !== id);
      console.log("Item deleted Successfully");
    },
    getAllItems: function () {
      for (let product of products) {
        console.log(
          `Product Id: ${product.productId} Name:${product.name},price:${product.price} quantity:${product.quantity}`
        );
      }
    },

    getTotalPrice: function () {
      let totalPrice = 0;
      for (let product of products) {
        totalPrice += product.price * product.quantity;
      }
      console.log("Price of Product: ", totalPrice);
    },
  };
})();

shoppingCart.addItem(1, "egg", 5, 5);
shoppingCart.addItem(2, "bread", 2, 1);
shoppingCart.getAllItems();
shoppingCart.getTotalPrice();
shoppingCart.removeItem(2);
shoppingCart.getAllItems();

// 1. Create Pseudo classical Inheritance by using Object.create and Object.setPrototypeOf for

// Human – Base / Super Class

// name – string

// Prototype Level Method

// Speak

// Introduction

// Student

// College – string

// Courses – string []

// Prototype Level Method

// Introduction (overridden)

// takeExams

function Human(name) {
  this.name = name;
}
Human.prototype.speak = function () {
  return "Humans speak.";
};
Human.prototype.introduction = function () {
  return "Hi, I'm a human.";
};

function Student(college, course) {
  this.college = college;
  this.course = course;
}
var objHuman = Object.create(Human.prototype);
Object.setPrototypeOf(Student, objHuman);
Student.prototype.constructor = Student;
Student.prototype.introduction = function () {
  return (
    "Hi, I'm a student of" +
    this.college +
    ", and am enrolled in " +
    this.courses +
    "."
  );
};

// 2. Create a Class Hierarchy between

// Person – Base / Super

// Developer - Derived / Sub

// Display Both objects / classes prototype, __proto__ and getPrototypeOf

function Person(name, age) {
  this.name = name;
  this.age = age;
}

function Developer(name, age, language) {
  Person.call(this, name, age);
  this.language = language;
}

Developer.prototype = Object.create(Person.prototype);
Developer.prototype.constructor = Developer;

var personObj = new Person("John", 30);
var developerObj = new Developer("Alice", 25, "JavaScript");

console.log("Person Prototype:", Person.prototype);
console.log("personObj.__proto__:", personObj.__proto__);
console.log(
  "Object.getPrototypeOf(personObj):",
  Object.getPrototypeOf(personObj)
);

console.log("Developer Prototype:", Developer.prototype);
console.log("developerObj.__proto__:", developerObj.__proto__);
console.log(
  "Object.getPrototypeOf(developerObj):",
  Object.getPrototypeOf(developerObj)
);
