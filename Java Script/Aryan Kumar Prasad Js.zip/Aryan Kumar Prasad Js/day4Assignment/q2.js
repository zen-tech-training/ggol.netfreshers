// 2: Promise Chaining

// Create a series of functions that return promises and chain them together to perform a sequence of async operations.

// Instructions:

// 1. Create three functions `task1() `, `task2()`, and `task3()` that return promises.

// 2. Each function should resolve after a certain time with a specific message (e.g., "Task 1 complete").

// 3. Chain these functions together so they execute in sequence.

// 4. Log each task’s completion message

function task1(){
    return new Promise((resolve,reject) =>{
        setTimeout(()=>{
            resolve('Executed in 1000ms');
        },1000);
    })
}

function task2(){
    return new Promise((resolve,reject) =>{
        setTimeout(()=>{
            resolve('Executed in 1000ms');
        },1000);
    })
}

function task3(){
    return new Promise((resolve,reject) =>{
        setTimeout(()=>{
            resolve('Executed in 3000ms');
        },3000);
    })
}

task1().then((res)=>{
    console.log(res);
    return task2();
}).then((res)=>{
    console.log(res);
    return task3();
}).then((res)=>{
    console.log(res);
}).catch((err)=>{
    console.log(err);
})

// async function execute(){
//     console.log(await task1());
//     console.log(await task2());
//     console.log(await task3());
// }
// execute();