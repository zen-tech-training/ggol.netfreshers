// 1 Basic Promise

// Write a function that returns a promise which resolves after a specified time with a success message.

// Instructions:

// 1. Create a function `wait(ms)` that returns a promise.

// 2. The promise should resolve with a message "Completed after X milliseconds" where `X` is the input to the function.

// 3. Test the function by calling it with different time values and logging the result

function wait(ms){
    return new Promise((resolve,reject) => {
        setTimeout(()=>{
            resolve(`Completed after ${ms} milliseconds`)
        },ms)
    })
}

wait(2000).then((res)=>{
    console.log(res);
}).catch((err) =>{
    console.log(err);
})