// Assignment 3: Error Handling
// Handle errors in async functions using try/catch.

// Instructions: 
// 1. Modify the `getUserData` function from Assignment 2.
// 2. Wrap the `fetch` call and the subsequent code in a try/catch block.
// 3. In the catch block, log an error message to the console if the request fails.
// 4. Test the function by modifying the URL to an invalid one and observing the output.

async function getUserData(){
    try{
        const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
        // throw new Error("something went wrong");
        console.log(  await response.json());
    }catch(err){
        console.log("Opps!! Error:",err);
    }

    // const temp = await JSON.parse(response);


}

getUserData();