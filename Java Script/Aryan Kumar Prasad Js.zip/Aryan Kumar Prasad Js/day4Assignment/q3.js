// 3: Handling Errors

// Write a promise that simulates an error condition and handle it using `catch()`.

// Instructions:

// 1. Create a function `errorProneTask()` that returns a promise.

// 2. The promise should randomly either resolve with a success message or reject with an error message.

// 3. Handle both the success and error cases using `then()` and `catch()

function errorProneTask(){

    const random = Math.floor(Math.random() * 6)
    return new Promise((resolve,reject) =>{
        if(random>3){
            reject("Something Went Wrong");
        }else{
            resolve('Success');
        }
    });

}

errorProneTask().then((res)=>{
    console.log(res);
}).catch((err)=>{
    console.log(err);
})