// 1: Creating and Using Objects

// Create a Simple Object:

// - Create an object `car` with properties `make`, `model`, and `year`.

// - Add a method `getCarInfo` that returns a string with the car's information.

var car = {
    'make': 'BMW',
    'model': 'M340i',
    'year': '2023',
    getCarinfo : function () {
        console.log(this.make + "'s car " + this.model + ", year: " + this.year + " is the best.");
    }
};

// 2: Prototypal Inheritance

// Animal and Dog Classes:

// - Create a constructor function `Animal` with properties `name` and `sound`.

// - Add a method `makeSound` to the `Animal` prototype that logs the sound.

// - Create a constructor function `Dog` that inherits from `Animal`.

// - Add a method `fetch` to the `Dog` prototype.


function Animal(name, sound) {
    this.name = name;
    this.sound = sound;
}
Animal.prototype.makeSound = function () {
    console.log(this.name + " makes " + this.sound + " sound.");
}
 
Dog.prototype = new Animal();
Dog.prototype.constructor = Dog;
 
function Dog() {
    Animal.call(this);
}
 
Dog.prototype.fetch = function () {
    console.log("Fetch");
}

// 3: Encapsulation and Private Variables

// Bank Account:

// - Create a constructor function `BankAccount` with a private variable `balance`.

// - Add methods `deposit`, `withdraw`, and `getBalance` to manage the balance.

function BankAccount() {
    var balance = 0;
    this.deposit = function (amount) {
        balance += amount;
        console.log("New Balance: " + balance);
    }
    this.withdraw = function (amount) {
        if (balance - amount < 0) {
            console.log("Low balance");
        } else {
            balance -= amount;
            console.log("New Balance: " + balance);
        }
    }
    this.getBalance = function () {
        console.log("Your Balance: " + balance);
    }
}
// 4: Polymorphism
// Shapes:
// - Create a base constructor function `Shape` with a method `getArea` that returns 0.

// - Create derived constructor functions `Circle` and `Rectangle` that override the `getArea` method to calculate the area of the shape.


function Shape(name){
    this.name = name;
}

Shape.prototype.getArea = function() {
    return 0;
}

Circle.prototype = new Shape();
Circle.prototype.constructor = Circle;



function Circle(radius){
    this.radius = radius;
    Shape.call(this,'Circle');

}


Circle.prototype.getArea = function(){
    return Math.PI * this.radius*this.radius;
}

function Reactangle(length,breadth){
    this.length = length;
    this.breadth = breadth;
    Shape.call(this,'Reactangle');
}

Reactangle.prototype.getArea = function(){
    return this.length*this.breadth;
}


var circle = new Circle(3);
var rect = new Reactangle(3,4);
console.log("The area of the circle : ", circle.getArea());
console.log("The area of the Reactangle : ", rect.getArea());

// 5: Inheritance with Method Overriding

// Vehicle and Car:

// - Create a constructor function `Vehicle` with properties `make`, `model`, and `year`.

// - Add a method `getDetails` to the `Vehicle` prototype that returns a string with the vehicle's details.

// - Create a constructor function `Car` that inherits from `Vehicle` and adds a property `doors`.

// - Override the `getDetails` method in the `Car` prototype to include the number of doors.

function Vehicle(make,model,year){
    this.make = make;
    this.model = model;
    this.year = year; 
    
  
}

Vehicle.sayHello = function(){
    console.log('hello');
}

Vehicle.prototype.getDetails = function(){
    return  `Vehicle :${this.make} model:${this.model}  Year:${year}`
}

Car.prototype = new Vehicle();
Car.prototype.constructor = Car;


function Car(make,model,year,door){
    this.door = door;
    Vehicle.call(this,make,model,year);
}

Car.prototype.getDetails = function(){
     return  `Vehicle :${this.make} model:${this.model}  Year:${this.year} Door:${this.door}`
}

var car = new Car('TVS','Apache RTR',2022,0);
console.log(car.getDetails());



// 6: Creating and Using Static Methods

// Math Utilities:

// - Create a constructor function `MathUtil`.

// - Add a static method `add` that takes two numbers and returns their sum.

// - Add a static method `subtract` that takes two numbers and returns their difference.

// - Add a static method `multiply` that takes two numbers and returns their product.

// - Add a static method `divide` that takes two numbers and returns their quotient.

function MathUtilities (){
    
}

MathUtilities.add = function(x,y){
    return x+y;
}

MathUtilities.subtract = function(x,y){
    return x-y;
}

MathUtilities.multiply = function(x,y){
    return x*y;
}

MathUtilities.divide = function(x,y){
    if(y == 0){
        return "Not divisible by 0"
    }
    return x/y;
}

// 7: Using Getters and Setters

// Book:

// - Create a constructor function `Book` with properties `title`, `author`, and `year`.

// - Add a getter method `getSummary` that returns a summary string of the book.

// - Add a setter method `setYear` that updates the year and logs a message when the year is set.

function Book(title,author,year){
    this.title = title;
    this.author = author;
    this.year = year;
    this.getSummary = function(){
        return `It Ends with Us is a 2016 romance novel by Colleen Hoover. The novel tells the story of Lily Bloom and her doomed romance with Ryle Kincaid and traces her past history growing up in an abusive home, her fall into an abusive relationship, and her escape from that relationship.`
    }
    this.setYear = function(year){
        this.year = year
        console.log("The year is set to ",year);
    }
}


var book = new Book('It ends with us','Colleen Hoover',2016)
console.log(book.getSummary());
book.setYear(2019);


// 8: Composition Over Inheritance

// User with Address:

// - Create a constructor function `User` with properties `username` and `password`.

// - Create a constructor function `Address` with properties `street`, `city`, and `country`.

// - Add an `address` property to the `User` constructor that holds an `Address` instance.

// - Add a method `getAddress` to the `User` prototype that returns the user's address as a formatted string.


function User(username , password, address){
    this.username = username;
    this.password = password;
    this.address = address;
}

User.prototype.getAddress = function(){
    return `The user ${this.username} is located at ${this.address.street},${this.address.city} , ${this.address.country}`;
}

function Address(street,city,country){
    this.street = street;
    this.city = city;
    this.country = country;
}

var address = new Address('I dont know','NoWhere','NoneOfYourBusiness');
var user = new User('sdhkjfh','fjdsfks',address);

console.log(user.getAddress());



// 9: Implementing Polymorphism

// Shape and Specific Shapes:

// - Create a constructor function `Shape` with a method `getArea` that returns 0.

// - Create a constructor function `Square` that inherits from `Shape` and has a property `sideLength`.

// - Override the `getArea` method in `Square` to return the area of the square.

// - Create a constructor function `Triangle` that inherits from `Shape` and has properties `base` and `height`.

// - Override the `getArea` method in `Triangle` to return the area of the triangle.

function Shape(name){
    this.name = name;
}

Shape.prototype.getArea = function() {
    return 0;
}

Square.prototype = new Shape();
Square.prototype.constructor = Square;



function Square(sideLength){
    this.sideLength = sideLength;
    Shape.call(this,'Square');

}


Square.prototype.getArea = function(){
    return this.sideLength*this.sideLength;
}

function Triangle(base,height){
    this.base = base;
    this.height = height;
    Shape.call(this,'Triangle');
}

Triangle.prototype.getArea = function(){
    return 0.5 * this.base*this.height;
}


var square = new Square(3);
var triangle = new Triangle(3,4);
console.log("The area of the circle : ", square.getArea());
console.log("The area of the Reactangle : ", triangle.getArea());


// 10: Using Mixins

// Flyable and Swimmable Mixins :

// - Create a mixin `Flyable` that adds a method `fly` to an object.

// - Create a mixin `Swimmable` that adds a method `swim` to an object.

// - Create a constructor function `Duck` that uses both mixin

const Flyable = {
    fly() {
        console.log(`${this.name} is flying!`);
    }
};


const Swimmable = {
    swim() {
        console.log(`${this.name} is swimming!`);
    }
};

// Duck constructor function using mixins
function Duck(name) {
    this.name = name;
}

// Apply mixins to Duck prototype
Object.assign(Duck.prototype, Flyable, Swimmable);

// Example usage
const donaldDuck = new Duck("Donald");
donaldDuck.fly();
donaldDuck.swim();
