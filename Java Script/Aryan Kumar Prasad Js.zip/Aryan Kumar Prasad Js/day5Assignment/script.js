function $(id){
    return document.getElementById(id);
}

$('addTodoButton').addEventListener('click',(event)=>{
    const currentValue = $('todokInput').value;
    const li = document.createElement('li');
    li.innerText = currentValue;
    $('todoList').appendChild(li);
    $('todokInput').value = '';
    const span = document.createElement('button');
    span.classList.add('.btn-delete');
    span.innerText = 'Delete';
    li.appendChild(span);
    span.addEventListener("click", (event) => {
        $('todoList').removeChild(event.target.parentElement)
      });
   
})


