// 1: Reverse a String
function reverseString(str) {
    return str.split('').reverse().join('');
}
console.log(reverseString('hello'));

// 2: Find the Largest Number in an Array
function findLargest(arr) {
    if (arr.length === 0) return -1;
    return Math.max(...arr);
}
console.log(findLargest([3, 4, 8, 2, 9]));

// 3: Check if a String is a Palindrome
function isPalindrome(str) {
    const reversed = str.split('').reverse().join('');
    return reversed === str ? 'Given string is Palindrome' : 'Given string is not Palindrome';
}
console.log(isPalindrome('abcdcba'));

// 4: Filter Array of Objects
function filterAdults(people) {
    return people.filter(person => person.age > 18);
}
const peopleArray = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 17 },
    { name: 'Charlie', age: 30 },
];
console.log(filterAdults(peopleArray));

// 5: Sum of All Numbers in an Array
function sumArray(arr) {
    return arr.reduce((acc, num) => acc + num, 0);
}
console.log(sumArray([4, 5, 3, 8, 9, 0, -2, -5]));

// 6: Remove Duplicates from an Array
function removeDuplicates(arr) {
    return [...new Set(arr)];
}
console.log(removeDuplicates([3, 5, 8, 4, 3, 8, 1, 0, 0]));

// 7: Find Intersection of Two Arrays
function findIntersection(arr1, arr2) {
    const set1 = new Set(arr1);
    return arr2.filter(item => set1.has(item));
}
console.log(findIntersection([1, 2, 3, 4], [3, 4, 5, 6]));

// 8: Convert an Object to an Array of Key-Value Pairs
function objectToArray(obj) {
    return Object.entries(obj);
}
const obj = { name: 'John', age: 30 };
console.log(objectToArray(obj));

// 9: Sort an Array of Objects by a Property
function sortByAge(people) {
    return people.sort((a, b) => a.age - b.age);
}
const peoples = [
    { name: 'Modi', age: 70 },
    { name: 'Rahul', age: 50 },
    { name: 'Kejriwal', age: 55 },
];
console.log(sortByAge(peoples));