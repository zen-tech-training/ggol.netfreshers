function task1() {
    return new Promise((res) => {
        setTimeout(() => {
            res('Task 1 completed');
        }, 3000);
    });
}

function task2() {
    return new Promise((res) => {
        setTimeout(() => {
            res('Task 2 completed');
        }, 1000);
    });
}

function task3() {
    return new Promise((res) => {
        setTimeout(() => {
            res('Task 3 completed');
        }, 4000);
    });
}

async function executeTasks() {
    try {
        const result1 = await task1();
        console.log(result1);

        const result2 = await task2();
        console.log(result2);

        const result3 = await task3();
        console.log(result3);
    } catch (error) {
        console.error('Error:', error);
    }
}

executeTasks();