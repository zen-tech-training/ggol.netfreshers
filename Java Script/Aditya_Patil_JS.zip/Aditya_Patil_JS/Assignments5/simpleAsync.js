function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchData() {
    await delay(3000); // Wait for 3 seconds
    console.log('Data fetched');
}

fetchData();