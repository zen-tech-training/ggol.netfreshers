import fetch from "node-fetch";

async function getUserData() {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching user data:', error);
    throw error;
  }
}

async function main() {
  try {
    const userData = await getUserData();
    console.log(userData);
  } catch (error) {
    console.error('Error in main function:', error);
  }
}

main();