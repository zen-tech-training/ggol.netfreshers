async function errorProneTask() {
    return new Promise((res, rej) => {
      if (true) {
        res("Resolved");
      } else {
        rej('Rejected');
      }
    });
  }
  
  async function main() {
    try {
      const result = await errorProneTask();
      console.log(result);
    } catch (error) {
      console.error('Error:', error);
    }
  }
  
  main();