function task1() {
    return new Promise((res) => {
        setTimeout(() => {
            res('Task 1 completed');
        }, 3000);
    });
}

function task2() {
    return new Promise((res) => {
        setTimeout(() => {
            res('Task 2 completed');
        }, 1000);
    });
}

function task3() {
    return new Promise((res) => {
        setTimeout(() => {
            res('Task 3 completed');
        }, 4000);
    });
}

async function executeTasks() {
    try {
        const results = await Promise.all([task1(), task2(), task3()]);
        console.log(results);
    } catch (error) {
        console.error('Error:', error);
    }
}

executeTasks();