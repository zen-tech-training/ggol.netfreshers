// 1. Overloaded function for addition
function overloadedAdd(...args) {
  const sum = args.reduce((acc, curr) => acc + curr, 0);
  return sum;
}

// Example usage
console.log(overloadedAdd(1, 2));          // Addition of 2 numbers
console.log(overloadedAdd(1, 2, 3));       // Addition of 3 numbers
console.log(overloadedAdd(1, 2, 3, 4));    // Addition of 4 numbers


// 2. Overloaded function for different types
function overloadedFunction(...args) {
  const [firstArg, secondArg] = args;

  if (args.length === 2) {
      if (typeof firstArg === 'string' && typeof secondArg === 'string') {
          console.log('Function with two strings');
          // Your implementation for two strings
      } else if (typeof firstArg === 'number' && typeof secondArg === 'number') {
          console.log('Function with two numbers');
          // Your implementation for two numbers
      } else if ((typeof firstArg === 'string' && typeof secondArg === 'number') ||
                 (typeof firstArg === 'number' && typeof secondArg === 'string')) {
          console.log('Function with one string and one number');
          // Your implementation for one string and one number
      } else {
          console.log('Common implementation for other combinations');
          // Your implementation for other combinations
      }
  } else if (args.length === 3 && args.every(arg => typeof arg === 'number')) {
      console.log('Function with three numbers');
      // Your implementation for three numbers
  } else {
      console.log('Common implementation for other combinations');
      // Your implementation for other combinations
  }
}

// Example usage
overloadedFunction('hello', 'world');    // Two strings
overloadedFunction(1, 2);                 // Two numbers
overloadedFunction(1, 'two');             // One string and one number
overloadedFunction(1, 2, 3);               // Three numbers


// 3. Runtime Type Information
class Vehicle {
  constructor(make, model) {
      this.make = make;
      this.model = model;
  }
}

class Car extends Vehicle {
  constructor(make, model) {
      super(make, model);
      this.wheels = 4;
  }
}

class Bike extends Vehicle {
  constructor(make, model) {
      super(make, model);
      this.wheels = 2;
  }
}

const car = new Car('Tata', 'Nexon');
const bike = new Bike('TVS', 'Apache');

// Example usage
console.log(typeof car);                     // "object"
console.log(typeof bike);                    // "object"

console.log(car instanceof Vehicle);         // true
console.log(car instanceof Car);             // true
console.log(car instanceof Bike);            // false

console.log(bike instanceof Vehicle);        // true
console.log(bike instanceof Car);            // false
console.log(bike instanceof Bike);           // true

console.log(car.constructor);                 // Car
console.log(bike.constructor);                // Bike

console.log(Object.getPrototypeOf(car) === Car.prototype); // true
console.log(Object.getPrototypeOf(bike) === Bike.prototype); // true