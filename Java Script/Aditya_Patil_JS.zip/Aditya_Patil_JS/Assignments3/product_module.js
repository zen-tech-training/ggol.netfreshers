class Product {
    constructor(productId, name, price) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.quantity = 0; // Default quantity
    }
}

const products = [];

// Add item to the inventory
function addItem(name, price) {
    const existingProduct = products.find(product => product.name === name);

    if (existingProduct) {
        existingProduct.quantity += 1; // Increment quantity if product exists
    } else {
        const id = Math.random() * 100; // Generate a random product ID
        const newProduct = new Product(id, name, price);
        newProduct.quantity = 1; // Set initial quantity to 1
        products.push(newProduct); // Add new product to the array
    }
}

// Remove item from the inventory
function removeItem(productId) {
    const productIndex = products.findIndex(product => product.productId === productId);
    
    if (productIndex !== -1) {
        products.splice(productIndex, 1); // Remove product by index
    } else {
        console.log(`Product with ID ${productId} not found.`);
    }
}

// Get all items in the inventory
function getAllItems() {
    products.forEach(product => {
        console.log(`\nName: ${product.name}, Price: ${product.price}, Quantity: ${product.quantity}`);
    });
}

// Calculate total price of all items in the inventory
function getTotalPrice() {
    return products.reduce((total, product) => total + (product.price * product.quantity), 0);
}

// Example usage
addItem('Apple', 0.5);
addItem('Banana', 0.3);
addItem('Apple', 0.5); // Increment quantity of Apple
getAllItems();
console.log(`Total Price: $${getTotalPrice()}`);
removeItem(products[0].productId); // Remove the first product
getAllItems();