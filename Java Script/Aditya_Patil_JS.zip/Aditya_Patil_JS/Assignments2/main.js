// 1: Car Object
class Car {
    constructor(make, model, year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    getCarInfo() {
        return `${this.make} ${this.model}, ${this.year}`;
    }
}

// Example usage
const myCar = new Car('Toyota', 'Corolla', 2005);
console.log(myCar.getCarInfo());

// 2: Animal and Dog Classes
class Animal {
    constructor(name, sound) {
        this.name = name;
        this.sound = sound;
    }

    makeSound() {
        console.log(this.sound);
    }
}

class Dog extends Animal {
    constructor(name, sound) {
        super(name, sound);
    }

    fetch() {
        console.log(`${this.name} is fetching!`);
    }
}

// Example usage
const myDog = new Dog('Buddy', 'Woof');
myDog.makeSound();
myDog.fetch();

// 3: Bank Account Class
class BankAccount {
    #balance; // Private field

    constructor(initialBalance) {
        this.#balance = initialBalance;
    }

    deposit(amount) {
        this.#balance += amount;
    }

    withdraw(amount) {
        if (amount <= this.#balance) {
            this.#balance -= amount;
        } else {
            console.log('Insufficient balance');
        }
    }

    getBalance() {
        return this.#balance;
    }
}

// Example usage
const myAccount = new BankAccount(100);
myAccount.deposit(50);
myAccount.withdraw(30);
console.log(myAccount.getBalance());

// 4: Shape and Area Classes
class Shape {
    getArea() {
        return 0;
    }
}

class Circle extends Shape {
    constructor(radius) {
        super();
        this.radius = radius;
    }

    getArea() {
        return Math.PI * this.radius ** 2;
    }
}

class Rectangle extends Shape {
    constructor(width, height) {
        super();
        this.width = width;
        this.height = height;
    }

    getArea() {
        return this.width * this.height;
    }
}

// Example usage
const myCircle = new Circle(5);
const myRectangle = new Rectangle(4, 6);
console.log(myCircle.getArea());
console.log(myRectangle.getArea());

// 5: Vehicle and Car Classes
class Vehicle {
    constructor(make, model, year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    getDetails() {
        return `${this.make} ${this.model}, ${this.year}`;
    }
}

class CarWithDoors extends Vehicle {
    constructor(make, model, year, doors) {
        super(make, model, year);
        this.doors = doors;
    }

    getDetails() {
        return `${super.getDetails()}, ${this.doors} doors`;
    }
}

// Example usage
const myCarWithDoors = new CarWithDoors('Honda', 'Civic', 2020, 4);
console.log(myCarWithDoors.getDetails());

// 6: Math Utility Class
class MathUtil {
    static add(a, b) {
        return a + b;
    }

    static subtract(a, b) {
        return a - b;
    }

    static multiply(a, b) {
        return a * b;
    }

    static divide(a, b) {
        if (b !== 0) {
            return a / b;
        } else {
            console.log('Cannot divide by zero');
        }
    }
}

// Example usage
console.log(MathUtil.add(5, 3));
console.log(MathUtil.divide(10, 2));

// 7: Book Class
class Book {
    constructor(title, author, year) {
        this.title = title;
        this.author = author;
        this.year = year;
    }

    get summary() {
        return `${this.title} by ${this.author}, published in ${this.year}`;
    }

    set yearPublished(newYear) {
        this.year = newYear;
        console.log(`Year set to ${newYear}`);
    }
}

// Example usage
const myBook = new Book('1984', 'George Orwell', 1949);
console.log(myBook.summary);
myBook.yearPublished = 1950;

// 8: User and Address Classes
class Address {
    constructor(street, city, country) {
        this.street = street;
        this.city = city;
        this.country = country;
    }
}

class User {
    constructor(username, password) {
        this.username = username;
        this.password = password;
        this.address = new Address('123 Main St', 'Anytown', 'USA');
    }

    getAddress() {
        return `${this.address.street}, ${this.address.city}, ${this.address.country}`;
    }
}

// Example usage
const myUser = new User('john_doe', 'password123');
console.log(myUser.getAddress());

// 9: Shape, Square, and Triangle Classes
class Square extends Shape {
    constructor(sideLength) {
        super();
        this.sideLength = sideLength;
    }

    getArea() {
        return this.sideLength ** 2;
    }
}

class Triangle extends Shape {
    constructor(base, height) {
        super();
        this.base = base;
        this.height = height;
    }

    getArea() {
        return 0.5 * this.base * this.height;
    }
}

// Example usage
const mySquare = new Square(4);
const myTriangle = new Triangle(3, 6);
console.log(mySquare.getArea());
console.log(myTriangle.getArea());