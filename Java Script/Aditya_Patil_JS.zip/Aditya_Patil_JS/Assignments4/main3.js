function removeListItem() {
    const list = document.getElementById('myList');

    // Check if the list has any child elements
    if (list.children.length > 0) {
        // Remove the last child element
        list.removeChild(list.lastElementChild);
    } else {
        console.log('No items to remove.');
    }
}