document.getElementById('addItemButton').addEventListener('click', addListItem);

function addListItem() {
    const list = document.getElementById('myList');
    const newItem = document.createElement('li');
    newItem.textContent = `Item ${list.children.length + 1}`; 
    list.appendChild(newItem);
}