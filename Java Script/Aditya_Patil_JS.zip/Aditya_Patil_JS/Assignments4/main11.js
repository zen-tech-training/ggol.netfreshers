document.getElementById('changeColorButton').addEventListener('click', changeColor);

function changeColor() {
    const colors = ['red', 'green', 'blue', 'yellow', 'orange', 'purple'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    document.body.style.backgroundColor = randomColor;
}