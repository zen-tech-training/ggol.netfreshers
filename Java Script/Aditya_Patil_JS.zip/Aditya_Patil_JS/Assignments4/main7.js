const form = document.getElementById('myForm');
const emailInput = document.getElementById('email');
const messageElement = document.getElementById('message');

form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    if (emailInput.value.trim() === '') {
        messageElement.textContent = 'Please enter an email address.';
    } else if (!isValidEmail(emailInput.value)) {
        messageElement.textContent = 'Please enter a valid email address.';
    } else {
        messageElement.textContent = 'Form submitted successfully!';
        form.reset(); // Reset the form after successful submission
    }
});

function isValidEmail(email) {
    // Basic email validation using a regular expression
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}