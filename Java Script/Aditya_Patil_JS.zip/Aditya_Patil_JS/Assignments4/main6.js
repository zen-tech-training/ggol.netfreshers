document.getElementById('changeImageButton').addEventListener('click', changeImage);

function changeImage() {
    const image = document.getElementById('myImage');
    const newSrc = image.src.endsWith('image1.jpg') ? 'image2.jpg' : 'image1.jpg'; // Toggle between two images
    image.src = newSrc;
}