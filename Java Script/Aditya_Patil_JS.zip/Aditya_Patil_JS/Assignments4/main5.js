document.getElementById('toggleButton').addEventListener('click', toggleVisibility);

function toggleVisibility() {
    const toggleDiv = document.getElementById('toggleDiv');
    toggleDiv.style.display = toggleDiv.style.display === 'none' ? 'block' : 'none';
}