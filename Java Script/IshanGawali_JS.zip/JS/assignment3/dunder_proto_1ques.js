/*
1. Create Pseudo classical Inheritance by using Object.create and Object.setPrototypeOf for
Human – Base / Super Class
    name – string
Prototype Level Method 
    Speak	
    Introduction
*/
function Human(name) {
    this.name = name
}

Human.prototype.speak = function () {
    console.log(this.name + " can speak")
}

Human.prototype.introduction = function () {
    console.log(this.name + " can introduce his/her")
}

Student.prototype = Object.create(Human.prototype)
// Object.setPrototypeOf(Student, Human)
Student.prototype.constructor = Student
function Student(name, school, courses) {
    Human.call(this, name)
    this.school = school
    this.courses = courses
}

Student.prototype.introduction = function () {
    console.log(this.name + " is introducing by saying he/she studies in " + this.school + ' and enrolled for ' + this.courses)
}

Student.prototype.takeExams = function () {
    console.log("Take Exams!")
}

var student = new Student("Ishan", "VIT", ["DSA", "JS"])
console.log(student.__proto__)
student.introduction()