/* 
2. Create a Class Hierarchy between
Person – Base / Super
Developer - Derived / Sub

Display Both objects / classes prototype, __proto__ and getPrototypeOf
*/
function Person(name) {
    this.name = name
}

Person.prototype.getName = function(){
    return this.name
}

Developer.prototype = Object.create(Person.prototype)
Developer.prototype.constructor = Developer
function Developer(name) {
    Person.call(this, name)
}

var developer = new Developer("Ishan")
developer.getName()

console.log(Developer.prototype)
console.log(developer.__proto__)
console.log(Object.getPrototypeOf(developer))
console.log(Person.prototype)
console.log(developer.__proto__.__proto__)
console.log(Object.getPrototypeOf(developer.__proto__))