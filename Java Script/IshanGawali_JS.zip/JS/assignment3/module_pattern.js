/*
1. Create a Shopping Cart Module, which would allow user to deal with cart data,
Product in Shopping Cart would be with following details.
    productId, name, price, quantity
Methods provided by Module are,
addItem – Add Item would add one product item, if again called for the same product 
id, it would increase the quantity.
    removeItem – Remove product (all quantities by product id)
    getAllItems – Get all products details.
    getTotalPrice - Total Price of all items in the cart
*/
function Product(id, nm, price, qty) {
    this.productId = id
    this.name = nm
    this.price = price
    this.quantity = qty
}

var cart = (function () {
    var shopping_cart = []

    return {
        addItem: function (item) {
            shopping_cart.push(item)
        },
        removeItem: function (id) {
            for (var item in shopping_cart) {
                if (id == shopping_cart[item].productId) {
                    delete shopping_cart[item]
                }
            }
        },
        getAllItems: function () {
            return shopping_cart
        },
        getTotalPrice: function () {
            const total = shopping_cart.reduce((acc, curr) => { 
                return acc + (curr.price * curr.quantity)
            }, 0)
            return total
        }
    }
})()

var prod1 = new Product(1, "Nike Shoes", 4000, 2);
var prod2 = new Product(2, "Adidias Shoes", 4000, 2);
var prod3 = new Product(3, "NewBalance Shoes", 4000, 2);

cart.addItem(prod1)
cart.addItem(prod2)
cart.addItem(prod3)
console.log(cart.getAllItems())
cart.removeItem(1)
console.log(cart.getAllItems())
console.log(cart.getTotalPrice())