/* 
Do the inheritance with Vehicle and Car as well as on Vehicle and Bike
Instantiate Car and Bike

Use type of to check the type of the Car and Bike Object

Use instance of to check Car Object is of type Vehicle, Car, or Bike
Use instance of to check Bike Object is of type Vehicle, Car, or Bike

Use constructor property to see whether,
CarObject.constructor property pointing to also check whether,
BikeObject.constructor property pointing to

Also check,
getPrototypeOf(carObj) is equal to Car.Prototype and 
getPrototypeOf(bikeObj) is equal to Bike.Prototype
*/
function Vehicle (make, model) {
    this.make = make;
    this.model = model;
}

Car.prototype = new Vehicle("BMW", "Q4");
Car.prototype.constructor = Car
function Car (make, model) {
    Vehicle.call(this, make, model)
    this.wheels = 4;
}

Bike.prototype = new Vehicle("RE", "GT650") 
Bike.prototype.constructor = Bike
function Bike (make, model) {
    Vehicle.call(this, make, model)
    this.wheels = 2;
}

var car = new Car("Mercedes", "Maybach")
var bike = new Bike("RE", "Himalayan")

console.log("Type of car:", typeof car)
console.log("Type of bike:", typeof bike)

console.log("car is instance of Car:", car instanceof Car)
console.log("car is instance of Bike:", car instanceof Bike)
console.log("car is instance of Vehicle:", car instanceof Vehicle)

console.log("bike is instance of Car:", bike instanceof Car)
console.log("bike is instance of Bike:", bike instanceof Bike)
console.log("bike is instance of Vehicle:", bike instanceof Vehicle)

console.log("Car Constructor pointing to", Car.prototype.constructor)
console.log("Bike Constructor pointing to", Bike.prototype.constructor)

console.log("Is getPropertyOf car equal to Car.prototype", Object.getPrototypeOf(car) === Car.prototype)
console.log("Is getPropertyOf bike equal to Bike.prototype", Object.getPrototypeOf(bike) === Bike.prototype)