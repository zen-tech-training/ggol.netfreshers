/* 
2. Write an overloaded function in javascript that would take care of
Function with two strings
Function with two numbers
Function with three numbers
Function with one String and one number
And common implementation for the rest of all combinations.
*/
function overload() {
    const functions = [];

    function getType(obj) {
        if(Array.isArray(obj)){
            obj = "array" 
            return obj
        }
        return typeof obj
    }

    function registerFunction(fn, types){
        functions.push({fn, types})
    }

    function matchFunctions(args, fnObj) {
        const {types, fn} = fnObj
        if (fn.length !== args.length) {
            return false
        }

        for (let i = 0; i < args.length; i++) {
            if (getType(args[i]) !== types[i]) {
                return false
            }
        }

        return true
    }

    function overloadedFunc(...args) {
        for (const fnObj of functions) {
            if (matchFunctions(args, fnObj)) {
                return fnObj.fn(...args)
            }
        }
        throw new Error('No matching function with arguments found')
    }
    overloadedFunc.add = function (fn, types) {
        registerFunction(fn, types)
    }
    return overloadedFunc
}

const func = overload()
func.add(function (a, b) {
    return a + ' ' + b
}, ['string', 'string'])

func.add(function (a, b) {
    return a + b
}, ['number', 'number'])

func.add(function (a, b) {
    return a + ' ' + b
}, ['string', 'number'])

func.add(function (a, b, c) {
    return a + b + c
}, ['number', 'number', 'number'])

func.add(function ([a, b, c]) {
    return "This is an array"
}, ['array'])


console.log(func("One", "Two"))
console.log(func(1, 2))
console.log(func("One", 2))
console.log(func(1, 2, 3))
console.log(func([1, 2, 3]))


