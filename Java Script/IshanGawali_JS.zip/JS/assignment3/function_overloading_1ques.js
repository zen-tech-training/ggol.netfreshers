/* 
1. Write an overloaded function in javascript that would take care of 
	Addition of 2 numbers
	Addition of 3 numbers and 
	Addition of 4 numbers.
*/
function overload(){
    var functions = [];

    function overloadedFunc(...args){
        for(var fn of functions){
            if(fn.length === args.length){
                return fn(...args)
            }
        }
        throw new Error('No matching function with arguments found')
    }
    overloadedFunc.add = function(fn){
        functions.push(fn)
    }
    // console.log(overloadedFunc)
    return overloadedFunc
}

var func = overload()
// console.log(func)
func.add(function (a,b){
    return a+b
})

func.add(function (a,b,c){
    return a+b+c
})

func.add(function (a,b,c,d){
    return a+b+c+d
})

console.log(func(1,2))
console.log(func(1,2,3))
console.log(func(1,2,3,4))


