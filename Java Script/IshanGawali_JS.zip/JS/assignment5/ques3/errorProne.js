function errorProneTask(){
    var success = false
    return new Promise((resolve, reject) => {
        if(success){
            resolve("Request Succeeded!")
        }else{
            reject("Request Failed!")
        }
    })
}

errorProneTask().then(res => {
    console.log(res)
}).catch(err => {
    console.error("Error: "+err)
})