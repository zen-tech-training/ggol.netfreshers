function task1() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve("Task 1 complete")
        }, 1000)
    })
}

function task2() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve("Task 2 complete")
        }, 2000)
    })
}

function task3() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve("Task 3 complete")
        }, 3000)
    })
}

task1().then(res => {
    console.log(res)
    task2().then(res1 => {
        console.log(res1)
        task3().then(res => {
            console.log(res)
        }).catch((err) => {
            console.error(err)
        })
    }).catch((err) => {
        console.error(err)
    })
}).catch((err) => {
    console.error(err)
})