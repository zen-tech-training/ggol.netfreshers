function wait(ms){
    return new Promise((resolve, reject) => {
        
        setTimeout(() => {
            resolve(`Completed after ${ms} milliseconds`)
        }, ms)
    })
}

wait(4000).then(res => console.log(res)).catch((err) => console.error(err)) 
wait(6000).then(res => console.log(res)).catch((err) => console.error(err)) 