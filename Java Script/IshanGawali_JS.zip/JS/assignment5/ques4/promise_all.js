const prom1 = Promise.resolve("Success")
const prom2 = new Promise((resolve, reject)=>{
    setTimeout(() => {
        resolve("Success from timeout")
    }, 2000)
})

Promise.all([prom1, prom2]).then((res) => {
    console.log(...res)
}).catch((err) => {
    console.error(err)
})