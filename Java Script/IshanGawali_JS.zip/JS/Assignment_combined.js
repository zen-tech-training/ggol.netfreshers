// // Singleton Pattern
// var SingletonEg = (function(){
//     var instance = null

//     function Singleton(){
//         if(instance){
//             return instance
//         }

//         instance = this

//         var a = 10;

//         this.publicVar = 10;
//         this.publicFunc = function(){
//             console.log(a)
//         }

//         return instance
//     }

//     return Singleton
// })()

// const singletonA = new SingletonEg()
// const singletonB = new SingletonEg();

// console.log(singletonA === singletonB)



// // Module Pattern
// function Product(name, price, category) {
//     this.p_name = name
//     this.p_price = price
//     this.p_category = category
// }
// var shopping_cart = (function(){
//     var cart = []

//     return {
//         getAllProducts: function(){
//             return cart
//         },
//         getProduct: function(name){
//             cart.filter(c => c.p_name === name)
//         },
//         addProduct: function(item){
//             cart.push(item)
//         },
//         removeProduct: function(name){
//             for(var c in cart){
//                 if(cart[c].p_name === name){
//                     delete cart[c]
//                 }
//             }
//         }   
//     }
// })()

// var product1 = new Product("Watch", 2000, 2)
// var product2 = new Product("Fan", 2000, 2)

// shopping_cart.addProduct(product1)
// shopping_cart.addProduct(product2)

// console.log(shopping_cart.getAllProducts())

// shopping_cart.removeProduct("Watch")


// console.log(shopping_cart.getAllProducts())



function Person(fName, lName, age){
    this.fName = fName,
    this.lName = lName,
    this.age = age
}

Person.prototype.getDetails = function(){
    console.log(this.fName, this.lName, this.age)
}

Employee.prototype = new Person("Ishan", "Gawali", 22);
Employee.prototype.constructor = Employee

function Employee(fName, lName, age, company_name, designation){
    Person.call(this, fName, lName, age)
    this.company_name = company_name,
    this.designation = designation
}

Employee.prototype.getDetails = function(){
    console.log(this.fName, this.lName, this.age, this.company_name, this.designation)
}

const employee = new Employee("John", "Doe", 22, "XYZ", "SDE")
employee.getDetails()
