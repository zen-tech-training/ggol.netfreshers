var div = document.getElementById('hoverDiv')
var para = document.getElementById('hoverText')
div.addEventListener('mouseover', function(){
    para.textContent = "Modified Text"
})