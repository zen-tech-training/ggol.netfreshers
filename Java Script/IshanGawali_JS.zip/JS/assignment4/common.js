function $(id){
    document.getElementById(id)
}

module.exports = $