/* 
Assignment 14: Create a Table
Create a table with 3 rows and 3 columns and fill it with numbers 1 through 9.
Hint: Use nested loops and `document.createElement`.
*/
var count = 1
for(let i = 0; i < 3; i++){
    var tr = document.createElement('tr')
    document.getElementById('table').appendChild(tr)
    for(let j = 0; j < 3; j++){
        var td = document.createElement('td')
        td.textContent = count++
        tr.appendChild(td)
    }
}