function toggleVisibility(){
    const bgColor = document.getElementById('toggleDiv')
    if(bgColor.style.backgroundColor === 'lightblue' || bgColor.style.backgroundColor === ''){
        document.getElementById('toggleDiv').style.backgroundColor = 'blue'
    }else{
         document.getElementById('toggleDiv').style.backgroundColor = 'lightblue'
    }
}