var parentUl = document.getElementById('myList')
let count = parentUl.childElementCount
function addListItem(){
    var li = document.createElement('li')
    li.textContent = "Item 3"
    parentUl.appendChild(li)
    count++
}

function removeListItem(){
    if(count > 0){
        parentUl.removeChild(parentUl.lastElementChild)
        count--
    }
}
