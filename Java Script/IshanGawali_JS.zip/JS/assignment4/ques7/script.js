function changeImage(){
    document.getElementById('myImage').setAttribute('src', 'bruce.jpg')
}