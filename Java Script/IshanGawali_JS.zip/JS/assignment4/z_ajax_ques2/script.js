function fetchJsonData(){
    var id = document.getElementById('id')
    var title = document.getElementById('title')
    var body = document.getElementById('body')
    const xHttp = new XMLHttpRequest()
    xHttp.onreadystatechange = function(){
        if(xHttp.readyState === 4){
            const data = JSON.parse(xHttp.responseText)
                id.innerHTML = 'Id is ' + data.id 
                title.innerHTML = "<br/>" + 'Title is ' + data.title 
                body.innerHTML =  "<br/>"+ 'Body is ' + data.body + "<br/><br/>"
        }
    }

    const url = 'https://jsonplaceholder.typicode.com/posts/1'
    xHttp.open('GET', url, true)
    xHttp.send()
}