function makePostRequest(){
    var postResponse = document.getElementById('postResponse')

    const xHttp = new XMLHttpRequest()
    xHttp.onreadystatechange = function(){
        if(xHttp.readyState === 4){
            if(xHttp.status === 201){
                const data = xHttp.responseText
                postResponse.innerHTML = data
            }
        }
    }

    const url = 'https://jsonplaceholder.typicode.com/posts'
    xHttp.open('POST', url, true)
    xHttp.setRequestHeader('Content-Type', 'application/json')
    xHttp.send(JSON.stringify({
        userId: 1,
        title: "Hello World",
        body: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Optio aspernatur iusto ipsa quo sapiente consequatur a, minus vero reiciendis eos odit ipsum obcaecati dignissimos inventore impedit sunt architecto consequuntur veritatis?"
    }))
}