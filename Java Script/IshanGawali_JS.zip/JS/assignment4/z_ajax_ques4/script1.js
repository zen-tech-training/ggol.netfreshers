function makePostRequest() {
    const xHttp = new XMLHttpRequest()

    const url = 'https://jsonplaceholder.typicode.com/posts'
    xHttp.open('GET', url, true)
}