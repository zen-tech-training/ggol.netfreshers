/* 
Assignment 13: Create a List and Add Items
Create an unordered list and a button. When the button is clicked, add a new list item with text "Item X" (where X is the number of the item).
Hint: Use `document.createElement`, `textContent`, and `appendChild`.
*/
var ul = document.getElementById('unorderedList')
document.getElementById('addList').addEventListener('click', function(){
    var li = document.createElement('li')
    li.textContent = 'Item ' + ul.childElementCount
    ul.appendChild(li)
})