function makeGetRequest(){
    var response = document.getElementById('response')
    const xHttp = new XMLHttpRequest()
    xHttp.onreadystatechange = function(){
        if(xHttp.readyState === 4){
            const data = JSON.parse(xHttp.responseText)
            for(var d in data){
                response.innerHTML += 'Id is ' + data[d].id + "<br/>" + 'Title is ' + data[d].title + "<br/>"+ 'Body is ' + data[d].body + "<br/><br/>"
            }
        }
    }

    const url = 'https://jsonplaceholder.typicode.com/posts'
    xHttp.open('GET', url, true)
    xHttp.send()
}