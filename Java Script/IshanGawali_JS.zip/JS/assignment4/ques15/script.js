/*
Assignment 15: Clone and Modify an Element
Create a button and a paragraph. When the button is clicked, clone the paragraph, change its text, and append the clone to the body.
Hint: Use `cloneNode`.
*/
var originalPara = document.getElementById('originalPara')
var clonedPara = originalPara.cloneNode(true)
clonedPara.id = 'clonedPara'
document.body.appendChild(clonedPara)