var prevText = document.getElementById('text').textContent
function changeText(){
    document.getElementById('text').innerHTML = 'Modified text, after button click'
}

function restoreText(){
    document.getElementById('text').innerHTML = prevText
}