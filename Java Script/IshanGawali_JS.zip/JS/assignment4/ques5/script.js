function validateForm(){
    var email = document.getElementById('email').value
    var message = document.getElementById('message')
    if(!/^[^@]+@\w+(\.\w+)+\w$/.test(email)){
        message.textContent = "Please Enter valid email"
        message.style.color = 'red'
        return false
    }
    message.textContent = 'Email is correct'
    message.style.color = 'green'
    return true
}