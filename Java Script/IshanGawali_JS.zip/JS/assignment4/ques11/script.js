/*
Assignment 11: Change an Element's Style
Create a button that, when clicked, changes the background color of the page to a random color.
Hint: Use `document.body.style.backgroundColor` and `Math.random`.
*/

var changeColorBtn = document.getElementById('colorBtn')
changeColorBtn.addEventListener('click', function () {
    var colors = ['blue', 'green', 'purple', 'cyan', 'lightblue', 'red', 'orange', 'yellow', 'black']
    document.body.style.backgroundColor = colors[Math.floor(Math.random() * 10)]
}) 
