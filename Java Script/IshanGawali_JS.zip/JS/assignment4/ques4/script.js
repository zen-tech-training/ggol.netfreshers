function changeColor(){
    document.getElementById('colorBox').style.backgroundColor = 'blue'
}