/*
Assignment 3: Error Handling
Write a JavaScript function to make a GET request and handle potential errors by displaying an error message.
*/
function fetchWithErrorHandling() {
    var message = document.getElementById('message')
    const xHttp = new XMLHttpRequest()
    xHttp.onreadystatechange = function () {
        if (xHttp.readyState === 4) {
            if (xHttp.status === 200) {
                console.log(JSON.parse(xHttp.responseText))
                message.innerHTML = "Data fetched Successfully"
            }else{
                message = "Error"+ xHttp.status + " " + xHttp.statusText
            }
        }
    }

    const url = 'https://jsonplaceholder.typicode.com/invalid-url'
    xHttp.open('GET', url, true)

    xHttp.onerror = function(){
        console.log("Request Failed")
    }
    xHttp.send()
}
