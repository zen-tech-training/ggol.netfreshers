/*
Assignment 12: Add and Remove Classes
Create an input field and a button. When the button is clicked, add a class to the input field that changes its border color. Clicking the button again should remove the class.
Hint: Use `classList.add` and `classList.remove`.
*/
var inputText = document.getElementById('inputText')
document.getElementById('addClass').addEventListener('click', function(){
    inputText.classList.add('inputText')
})

document.getElementById('removeClass').addEventListener('click', function(){
    inputText.classList.remove('inputText')
})
