/* 
Assignment 10: Create a New Element
Create a new `div` element, set its text content to "Hello, World!", and append it to the body.
Hint: Use `document.createElement`, `textContent`, and `appendChild`.
*/
var div = document.createElement('div')
div.textContent = "Hello, World!"
document.body.appendChild(div)