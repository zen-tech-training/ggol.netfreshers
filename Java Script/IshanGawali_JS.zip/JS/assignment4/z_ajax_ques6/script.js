function fetchListOfItems() {
    var ul = document.getElementById('itemList')
    const xHttp = new XMLHttpRequest()
    xHttp.onreadystatechange = function () {
        if (xHttp.readyState === 4) {
            const data = xHttp.responseText
            var li = document.createElement('li')
            li.textContent += data
            ul.appendChild(li)
        }
    }

    const url = 'https://jsonplaceholder.typicode.com/posts'
    xHttp.open('GET', url, true)
    xHttp.send()
}

