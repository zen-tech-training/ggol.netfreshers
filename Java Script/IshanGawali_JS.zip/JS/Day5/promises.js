// function fetchData(url){
//     return new Promise((resolve, reject) => {

//     })
// }
// console.log(0+NaN)
// console.log(Math.pow)

var a = [1,2,3,4]
var mainobj = {
    // name: {
    //     f_name: "Ishan",
    //     l_name: "Gawali",
    //     hobbies: ["cricket", "code"]
    // },
    // address: {
    //     city: 'Pune',
    //     state: 'Maharashtra',
    //     country: 'India'
    // }
    0: "Gawali",
    '4': "Ishan",
    f_name: "Gawali"
}

console.log({...a,...mainobj})

console.log(Math.pow)
