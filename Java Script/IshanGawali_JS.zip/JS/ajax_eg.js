// 
var xHttp = new XMLHttpRequest()
xHttp.onreadystatechange = function () {
    if (xHttp.readyState === 4) {
        console.log(xHttp.response)
    }
}
function Box() {
    const url = 'https://jsonplaceholder.typicode.com/todos/'
    xHttp.open('GET', url, true)
    console.log("after the first request")
    const url1 = 'https://jsonplaceholder.typicode.com/posts/'
    xHttp.open('GET', url1, true)
    xHttp.send()
}
Box()