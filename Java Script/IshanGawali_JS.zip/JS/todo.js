const list = document.getElementById("list")
const ul = document.createElement('ul')
list.appendChild(ul)
var add = document.getElementById("add")
var counter = 0;
var tasks = []
add.addEventListener('click', function(){
    const taskName = document.getElementById('taskName').value
    tasks.push(taskName)
    localStorage.setItem('Item', tasks)
    var li = document.createElement('li')
    var span = document.createElement('span')
    span.textContent = taskName
    li.appendChild(span)
    const remove = document.createElement('button')
    remove.textContent = "Remove"
    li.appendChild(remove)
    ul.appendChild(li)
 
    remove.addEventListener('click', function(){
        console.log(localStorage.getItem(li.firstChild.innerHTML))
        if(li.innerHTML === localStorage.getItem(li.firstChild.innerHTML)){
            localStorage.removeItem(li)
        }
        li.remove()
    })


    
})