function overload() {
    const functions = [];
    const types = []

    function getType(obj) {
        return typeof obj
    }

    function registerFunction(fn){
        functions.push(fn)
    }

    function matchFunctions(args, fn) {
        if (fn.length !== args.length) {
            return false
        }

        for (let i = 0; i < args.length; i++) {
            if (getType(args[i]) !== types[i]) {
                return false
            }
        }

        return true
    }

    function overloadedFunc(...args) {
        for (const fnObj of functions) {
            if (matchFunctions(args, fnObj)) {
                return fnObj.fn(...args)
            }
        }
        throw new Error('No matching function with arguments found')
    }
    overloadedFunc.add = function (fn, types) {
        registerFunction(fn, types)
    }
    return overloadedFunc
}

const func = overload()
func.add(function (a, b) {
    return a + b
}, ['number', 'number'])

func.add(function (a, b) {
    return a + ' ' + b
}, ['string', 'number'])

func.add(function (a, b) {
    return a + ' ' + b
}, ['string', 'string'])

func.add(function (a, b, c) {
    return a + b + c
}, ['number', 'number', 'number'])



console.log(func(1, 2))
console.log(func("One", 2))
console.log(func(1, 2, 3))
console.log(func("One", "Two"))