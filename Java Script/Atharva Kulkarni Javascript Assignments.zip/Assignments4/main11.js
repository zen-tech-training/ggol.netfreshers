function changeColor(){
    document.body.style.backgroundColor = 'red';
}