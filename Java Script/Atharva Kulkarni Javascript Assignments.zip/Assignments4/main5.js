function toggleVisibility(){
    document.getElementById('toggleDiv').style.display = 'none';
};