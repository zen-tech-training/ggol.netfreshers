// 1. Write an overloaded function in javascript that would take care of 
// 	Addition of 2 numbers
// 	Addition of 3 numbers and 
// 	Addition of 4 numbers.

function Overloaded() {
  this.methods = {};

  this.registerMethod = function(name, fn) {
      this.methods[name] = fn;
  };

  this.add = function(...args) {
      const methodName = 'add_' + args.length;
      const method = this.methods[methodName];
      if (method) {
          return method(...args);
      } else {
          throw new Error('Method not found for given number of arguments');
      }
  };

  this.registerMethod('add_2', function(a, b) {
      return a + b;
  });

  this.registerMethod('add_3', function(a, b, c) {
      console.log("overloaded 1");
      return a + b + c;
  });

  this.registerMethod('add_4', function(a, b, c, d) {
      console.log("overloaded 2");
      return a + b + c + d;
  });
}

var o1 = new Overloaded();
console.log(o1.add(2, 3)); 
console.log(o1.add(2, 3, 4)); 
console.log(o1.add(2, 3, 4, 5)); 

// Runtime Type Information

function Vehicle(make, model) {
  this.make = make;
  this.model = model;
}

function Car(make, model) {
  Vehicle.call(this,make,model);
  this.wheels = 4;
}

Car.prototype = new Vehicle();
Car.prototype.constructor = Car;

function Bike(make, model) {
  Vehicle.call(this,make,model);
  this.wheels = 2;
}

Bike.prototype = new Vehicle();
Bike.prototype.constructor = Bike;


const car = new Car('Tata','Nexon');
const bike = new Bike('TVS','Apache');

// console.log(typeof car);
// console.log(typeof bike);

// console.log(car instanceof Vehicle);
// console.log(car instanceof Car);
// console.log(car instanceof Bike);

// console.log(bike instanceof Vehicle);
// console.log(bike instanceof Car);
// console.log(bike instanceof Bike);

// console.log(car.constructor);
// console.log(bike.constructor);

// console.log(Object.getPrototypeOf(car)===Car.prototype);
// console.log(Object.getPrototypeOf(bike)===Bike.prototype);

