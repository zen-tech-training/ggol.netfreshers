function Human(name){
    this.name = name;
}

Human.prototype.introduction = function(){
    console.log("Hi, I am human w name " + this.name);
}

Human.prototype.speak = function(){
    console.log("Hi, I speak");
}

function Student(college, courses, name){
    this.college = college;
    this.courses = courses;

    Human.call(this, name);
}



var human1 = new Human('abc');
var stud1 = new Student('vit', ['os', 'se'], 'shikha');

Object.setPrototypeOf(stud1, human1);
Student.prototype.constructor = Student;

Student.prototype.takeExams = function(){
    console.log("i take exams");
}



// Student.prototype = Object.create(Human.prototype);


Student.prototype.introduction = function(){
    console.log("Imma introduce myself as " + this.name);
}





stud1.introduction();
stud1.takeExams();





// qs 2

function Person(name){
  this.name = name;
}

function Developer(position){
    this.position =position;
}

Developer.prototype = Object.create(Person.prototype);
Developer.prototype.constructor = Developer;

Developer.prototype.code = function(){
    console.log("I code");
}

console.log(Person.prototype);
console.log(Developer.prototype);

var myp = new Person('phil');
var myd = new Developer("associate");

console.log(myp.__proto__);
console.log(myd.__proto__);

console.log(Object.getPrototypeOf(myp));
console.log(Object.getPrototypeOf(myd));

