var ShoppingCart = (function () {
  
    var cart = [];
  
    function findProductIndex(productId) {
      return cart.findIndex((item) => item.productId === productId);
    }
    return {
        addItem: function (productId, name, price, quantity) {
          var index = findProductIndex(productId);
          if (index > -1) {
            
            cart[index].quantity += quantity;
          } else {
           
            cart.push({ productId, name, price, quantity });
          }
        },
        removeItem: function (productId) {
          var index = findProductIndex(productId);
          if (index > -1) {
            cart.splice(index, 1); 
          }
        },
        getAllItems: function () {
          return cart;
        },
        getTotalPrice: function () {
          return cart.reduce(
            (total, item) => total + item.price * item.quantity,
            0
          );
        },
      };
    })();
    
    
    ShoppingCart.addItem(1, "Apple", 1.0, 3);
    ShoppingCart.addItem(2, "Banana", 0.5, 5);
    console.log(ShoppingCart.getAllItems()); 
    console.log(ShoppingCart.getTotalPrice()); 
    ShoppingCart.removeItem(1); 
    console.log(ShoppingCart.getAllItems());