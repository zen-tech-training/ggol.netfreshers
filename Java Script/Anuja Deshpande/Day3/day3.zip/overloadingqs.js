// QS 1

const overloadedObj = {
    sum2: function(a,b){
        return a + b;
    },
    sum3: function(a,b,c){
        return a + b + c;
    },
    sum4: function(a,b,c,d){
        return a + b + c + d;
    },
    overloadingSum: function(){
        if(arguments.length === 2){
            return this.sum2(arguments[0], arguments[1]);
        }
        else if(arguments.length === 3){
            return this.sum3(arguments[0], arguments[1], arguments[2]);
        }
        else if(arguments.length === 4){
            return this.sum4(arguments[0], arguments[1], arguments[2], arguments[3]);
        }
        else{
            return "Ain't gonna sum!";
        }
    }
}


console.log(overloadedObj.overloadingSum(10,20));
console.log(overloadedObj.overloadingSum(10,20,30));
console.log(overloadedObj.overloadingSum(10,20,30,40));


// QS 2

var myObj = {

    twoStrings: function(str1, str2){
        return 'Two strings obtained ' + str1 + " " + str2;
    },
    StringNumber: function(str1, num1){
        return 'A string ' + str1 + " and a number obtained " + num1;
    },
    twoNumbers: function(num1, num2){
        return 'Two numbers obtained ' + num1 + " " + num2;
    },
    threeNumbers: function(num1, num2, num3){
        return 'Three numbers obtained ' + num1 + " " + num2+ " " + num3;
    },
    overload: function(){
        if(typeof(arguments[0]) === 'string' && typeof(arguments[1]) === 'string'){
            return this.twoStrings(arguments[0], arguments[1]);
        }
        else if(typeof(arguments[0]) === 'string' && typeof(arguments[1]) === 'number'){
            return this.StringNumber(arguments[0], arguments[1]);
        }
        else if(typeof(arguments[0]) === 'number' && typeof(arguments[1]) === 'number' && arguments.length === 2){
            return this.twoNumbers(arguments[0], arguments[1]);
        }
        else if(typeof(arguments[0]) === 'number' && typeof(arguments[1]) === 'number' && typeof(arguments[2]) === 'number' && arguments.length === 3){
            return this.threeNumbers(arguments[0], arguments[1], arguments[2]);
        }
        else{
            return "Karlo yaar khudse handle";
        }
    }
}

console.log(myObj.overload(1,2));
console.log(myObj.overload(1,2,3));
console.log(myObj.overload("hi", "hello"));
console.log(myObj.overload("hi",2));  //won't work if order changed, need to write the condition like that.
