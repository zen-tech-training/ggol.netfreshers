function Vehicle (make, model) {
    this.make = make;
    this.model = model;
}

function Car (make, model) {
    this.wheels = 4;
}

function Bike (make, model) {
    this.wheels = 2;
}

Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car;

Bike.prototype = Object.create(Vehicle.prototype);
Bike.prototype.constructor = Bike;


var mycar = new Car('Ford', '4');
var mybike = new Bike('BMW', '9');

console.log(typeof(mycar));
console.log(typeof(mybike));

console.log(Object.getPrototypeOf(mycar) === Car.prototype);
console.log(Object.getPrototypeOf(mybike) === Bike.prototype);

console.log("Abt cars");
console.log(mycar instanceof Car);
console.log(mycar instanceof Vehicle);
console.log(mycar instanceof Bike);


console.log("Abt bikes");
console.log(mybike instanceof Car);
console.log(mybike instanceof Vehicle);
console.log(mybike instanceof Bike);

console.log("Constructor points to");
console.log(mycar.constructor === Car);
console.log(mybike.constructor === Bike);

