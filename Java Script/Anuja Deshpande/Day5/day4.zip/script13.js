document.getElementById('btnChange').onclick = function(){
    // var ulArr = document.getElementsByTagName('li');
    var ul =  document.getElementById('mylist');
    var ulArr = ul.getElementsByTagName('li');
    console.log(ulArr.length);
    console.log(ulArr);

    var newListItem = document.createElement('li');
    newListItem.textContent = `Item ${ulArr.length + 1}`;
    document.getElementById('mylist').appendChild(newListItem);
}