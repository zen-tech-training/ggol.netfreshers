document.getElementById('btnChange').onclick = function(){
    const classes = document.getElementById('myinp').classList;
    console.log(classes);
    if(classes.contains('borderColorChange')){
        classes.remove('borderColorChange');
    }
    else{
        classes.add('borderColorChange');
    }
    
}