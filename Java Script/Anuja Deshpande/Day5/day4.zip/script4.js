changeColor = function(){
    var divToChange = document.getElementById('colorBox');
    divToChange.style.backgroundColor = 'peachpuff';
}