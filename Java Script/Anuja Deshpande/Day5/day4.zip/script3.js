removeListItem = function(){
    var elementlen = document.getElementsByTagName('li').length;
    console.log(elementlen);
    var delelement = document.getElementsByTagName('li')[elementlen-1];
    document.getElementById('myList').removeChild(delelement);
}