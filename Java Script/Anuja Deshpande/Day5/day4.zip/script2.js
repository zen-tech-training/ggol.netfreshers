addListItem = function(){
    var listitem = document.createElement('li');

    var allitems = document.getElementById('myList').childNodes;

    // var mylength = 0;
    // for(var i in allitems){
    //     console.log(allitems[i])
    //     if('<li>' in allitems[i]){
    //         mylength++;
    //     }
    // }

    // listitem.innerHTML = "Item" + (mylength + 1);

    listitem.innerHTML = "New itemmm";

    document.getElementById('myList').appendChild(listitem);
}