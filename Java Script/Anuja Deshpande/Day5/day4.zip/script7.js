changeImage = function(){
    var imgtomodify = document.getElementById('myImage');
    imgtomodify.src = "./hp.jfif";
}