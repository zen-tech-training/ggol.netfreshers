toggleVisibility = function () {
    var divtobetoggled = document.getElementById('toggleDiv');

    if (divtobetoggled.style.display === 'none') {
        divtobetoggled.style.display = 'block';
    }
    else {
        divtobetoggled.style.display = 'none';
    }
}