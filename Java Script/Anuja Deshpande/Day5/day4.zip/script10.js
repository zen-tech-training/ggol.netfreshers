// document.getElementById('btnChange').onclick = function(){
//     console.log("here");
//     var newDiv = document.createElement('div');

//     newDiv.textContent = "Hello, World!";
    
//     document.body.appendChild(newDiv);
// }


document.getElementById('pp').onclick = function(){
    console.log("here");
    var newDiv = document.createElement('div');

    newDiv.textContent = "Hello, World!";
    
    document.body.appendChild(newDiv);
}
