openModal = function(){
    $('myModal').style.display = 'block';
}

closeModal = function(){
    $('myModal').style.display = 'none';
}

function $(id){
    return document.getElementById(id);
}