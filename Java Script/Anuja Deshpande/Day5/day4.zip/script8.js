$('hoverDiv').onmouseover = changeText;

function changeText() {
    $('hoverText').innerHTML = "<h3>Changed Text now!!!</h3>"
}

function $(id){
    return document.getElementById(id);
}