changeText = function(){
    document.getElementById("text").innerText = "This is now the changed text okay?";
}