validateForm = function(){
    var email = document.getElementById('myForm')['email'].value;
    // alert(email);
    var re = /^\S+@\S+\.\S+$/;
    console.log(re.test(email));

    var msg = '';
    if(re.test(email)){
        msg = 'Successfully validated';
    }
    else{
        msg = 'Invalid email address';
    }

    document.getElementById('message').innerHTML = msg;
    return re.test(email);
}