document.getElementById('btnChange').onclick = function(){
    var para1 = document.getElementById('para1');
    var para2 = para1.cloneNode(true);
    para2.innerHTML = "Here's some changed text!";
    document.body.appendChild(para2);
}