// JavaScript function to validate an email address
function validateForm() {
    // Get the input value from the email field
    const emailInput = document.getElementById('email').value;

    // Regular expression pattern for a valid email address
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    // Check if the input matches the pattern
    if (emailPattern.test(emailInput)) {
        document.getElementById('message').textContent = 'Valid email address.';
        return true;
    } else {
        document.getElementById('message').textContent = 'Invalid email address. Please enter a valid email.';
        return false;
    }
}
