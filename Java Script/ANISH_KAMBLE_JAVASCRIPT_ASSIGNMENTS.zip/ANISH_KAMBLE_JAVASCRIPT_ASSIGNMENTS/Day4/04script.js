function changeColor(){
    var myDiv = document.getElementById('colorBox');
    myDiv.style.backgroundColor = 'green'
}