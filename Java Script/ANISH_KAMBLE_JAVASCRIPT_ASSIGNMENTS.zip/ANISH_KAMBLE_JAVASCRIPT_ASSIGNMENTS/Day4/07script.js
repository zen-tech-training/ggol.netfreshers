

function changeImage() {
  const myImage = document.getElementById('myImage');
  
  myImage.src = `download_2.webp`;
}