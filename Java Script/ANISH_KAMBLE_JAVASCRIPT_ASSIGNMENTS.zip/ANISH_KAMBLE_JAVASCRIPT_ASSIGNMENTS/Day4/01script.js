function changeText(){
    document.getElementById("text").innerHTML='New Text';
}