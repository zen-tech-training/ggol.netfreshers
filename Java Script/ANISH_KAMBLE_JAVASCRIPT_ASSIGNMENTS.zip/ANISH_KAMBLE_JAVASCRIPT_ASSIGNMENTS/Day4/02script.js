function addListItem(){
    var size = document.getElementById('myList').childNodes.length;

    console.log(size);
    
    var inp = 'Item '+ (size+1);
    var t = document.createTextNode(inp);
    var li = document.createElement('li');
    li.appendChild(t);
    document.getElementById('myList').appendChild(li);
}