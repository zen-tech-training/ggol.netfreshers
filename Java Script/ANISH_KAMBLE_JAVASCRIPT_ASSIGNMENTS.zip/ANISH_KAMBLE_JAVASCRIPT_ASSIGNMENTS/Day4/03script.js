// function removeListItem(){
//     // var size = document.getElementById('myList').childNodes.length;

//     // console.log(size);
//     var ul = document.getElementById('myList')

//     console.log(ul.lastChild);
//     ul.removeChild(ul.lastChild);
//     ul.lastChild

// }

function removeListItem(){
    // var size = document.getElementById('myList').childNodes.length;

    // console.log(size);
    var ul = document.getElementById('myList')

    var items = ul.getElementsByTagName('li')
    if (items.length>0){
        var lastItem = items[items.length-1];
        console.log(typeof lastItem)
        ul.removeChild(lastItem);
    }

}


