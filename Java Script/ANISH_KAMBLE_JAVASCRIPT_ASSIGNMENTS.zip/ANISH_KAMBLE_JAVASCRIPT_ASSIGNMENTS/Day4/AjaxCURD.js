// Get Posts
function getPosts() {
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts';
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        console.log('Get Posts Response:');
        console.log(data);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
  
  // Create Post
  function createPost() {
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts';
    const data = {
      title: 'New Post',
      body: 'This is a new post',
      userId: 1
    };
  
    fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
      .then(response => response.json())
      .then(data => {
        console.log('Create Post Response:');
        console.log(data);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
  
  // Delete Post
  function deletePost() {
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts/1';
    fetch(apiUrl, {
      method: 'DELETE'
    })
      .then(response => response.json())
      .then(data => {
        console.log('Delete Post Response:');
        console.log(data);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
  
  // Update Post
  function updatePost() {
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts/1';
    const data = {
      id: 1,
      title: 'Updated Post',
      body: 'This is an updated post',
      userId: 1
    };
  
    fetch(apiUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
      .then(response => response.json())
      .then(data => {
        console.log('Update Post Response:');
        console.log(data);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
  
  