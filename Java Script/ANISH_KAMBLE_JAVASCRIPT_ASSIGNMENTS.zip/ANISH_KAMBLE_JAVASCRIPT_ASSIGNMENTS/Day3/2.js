/*2. Write an overloaded function in javascript that would take care of
Function with two strings
Function with two numbers
Function with three numbers
Function with one String and one number
And common implementation for the rest of all combinations.*/ 

const someObj = {
    twoStrings:function(arg1,arg2){
        console.log('two strings')
        return arg1+arg2;
    },
    twoNumbers:function(arg1,arg2){
        console.log('two numbers')
        return arg1+arg2;
    },
    threeNumbers:function(arg1,arg2,arg3){
        console.log('three numbers')
        return arg1+arg2+arg3;
    },
    oneStringNumber:function(arg1,arg2){
        console.log('one string one number')
        return arg1+arg2;
    },
    
    // threeArguments

    overloadedFun:function(){
        if(arguments.length === 2 && typeof arguments[0]==String && typeof arguments[1]== String){
            return this.twoStrings(arguments[0],arguments[1]);
        }else if(arguments.length === 2 && typeof arguments[0]==Number && typeof arguments[1]== Number){
            return this.twoNumbers(arguments[0],arguments[1]);
        }else if(arguments.length === 3 && typeof arguments[0]==Number && typeof arguments[1]== Number && typeof arguments[2]== Number){
            return this.threeNumbers(arguments[0],arguments[1],arguments[2]);
        }else if(arguments.length === 2){
            return this.oneStringNumber(arguments[0],arguments[1]);
        }
    }
}

// console.log(someObj.overloadedFun(1));
console.log(someObj.overloadedFun(1,2));
console.log(someObj.overloadedFun(1,2,3));
console.log(someObj.overloadedFun(1,'Anish'));
console.log(someObj.overloadedFun('Anish','Kamble'));