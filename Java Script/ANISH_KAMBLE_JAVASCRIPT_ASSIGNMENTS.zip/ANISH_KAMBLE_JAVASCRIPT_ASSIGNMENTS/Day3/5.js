const products = [];

function Product(productId, name, price){
    this.productId  = productId;
    this.name = name;
    this.price = price;
    this.quantity = 0;

}

function addItem(name,price,quantity){
    var b = false;
    for (var i of products){
        if (i[name]===name){
            i[quantity]+=1;
            b = true;
            break;
        }
    }
    if (!b){
        var id = Math.random()*100;
        var prd = new Product(id,name,price,quantity);
        products.push(prd);
    }
}

function removeItem(productId){
    for (var i of products){
        if (i[productId]===productId){
            delete i;
            break;
        }
    }
}

function getAllItems(){
    for (var i of products){
        console.log('\n'+'Name: '+i.name+'Price: '+i.price+'Quantity: '+i.quantity);
    } 
}

function getTotalPrice(){
    var total = 0;
    for (var i of products){
        total+=(i.price*i.quantity);
    } 
    return total;
}