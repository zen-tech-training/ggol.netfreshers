function Vehicle(make, model) {
    this.make = make;
    this.model = model;
  }

  function Car(make, model) {
    Vehicle.call(this,make,model);
    this.wheels = 4;
  }
  
  Car.prototype = new Vehicle();
  Car.prototype.constructor = Car;
  
  function Bike(make, model) {
    Vehicle.call(this,make,model);
    this.wheels = 2;
  }
  
  Bike.prototype = new Vehicle();
  Bike.prototype.constructor = Bike;
  
  
  const car = new Car('Tata','Nexon');
  const bike = new Bike('TVS','Apache');
  
  // console.log(typeof car);
  // console.log(typeof bike);
  
  // console.log(car instanceof Vehicle);
  // console.log(car instanceof Car);
  // console.log(car instanceof Bike);
  
  // console.log(bike instanceof Vehicle);
  // console.log(bike instanceof Car);
  // console.log(bike instanceof Bike);
  
  // console.log(car.constructor);
  // console.log(bike.constructor);
  
  // console.log(Object.getPrototypeOf(car)===Car.prototype);
  // console.log(Object.getPrototypeOf(bike)===Bike.prototype);