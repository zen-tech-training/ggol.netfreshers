//  1. Write an overloaded function in javascript that would take care of 
// 	Addition of 2 numbers
// 	Addition of 3 numbers and 
// 	Addition of 4 numbers.



    const someObj = {
        twoArgument:function(arg1,arg2){
            return arg1+arg2;
        },
        threeArgument:function(arg1,arg2,arg3){
            return arg1+arg2+arg3;
        },
        fourArgument:function(arg1,arg2,arg3,arg4){
            return arg1+arg2+arg3+arg4;
        },

        
        // threeArguments

        overloadedFun:function(){
            if(arguments.length === 2){
                return this.twoArgument(arguments[0],arguments[1]);
            }else if(arguments.length === 3){
                return this.threeArgument(arguments[0],arguments[1],arguments[2]);
            }else if(arguments.length === 4){
                return this.fourArgument(arguments[0],arguments[1],arguments[2],arguments[3]);
            }
        }
}

// console.log(someObj.overloadedFun(1));
console.log(someObj.overloadedFun(1,2));
console.log(someObj.overloadedFun(1,2,3));
console.log(someObj.overloadedFun(1,2,3,4));