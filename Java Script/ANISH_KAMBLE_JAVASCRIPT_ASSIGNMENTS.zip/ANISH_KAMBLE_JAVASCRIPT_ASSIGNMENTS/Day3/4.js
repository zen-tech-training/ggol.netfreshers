class Person {
    constructor(name) {
      this.name = name;
    }
  
    introduction() {
      console.log(`Hey I am ${this.name}`);
    }
  }
  
  class Developer extends Person {
    constructor(name, language) {
      super(name);
      this.language = language;
    }
  
    introduction() {
      console.log(`Hey I'm ${this.name} and I am proficient in this coding language ${this.language}`);
    }
  
    develop() {
      console.log(`${this.name} is developing in ${this.language}`);
    }
  }
  
  let alice = new Developer("Alice", "JavaScript");
  
  console.log("Prototype of Developer:");
  console.log(Developer.prototype);
  console.log("__proto__ of alice:");
  console.log(alice.__proto__);
  console.log("getPrototypeOf of alice:");
  console.log(Object.getPrototypeOf(alice));
  