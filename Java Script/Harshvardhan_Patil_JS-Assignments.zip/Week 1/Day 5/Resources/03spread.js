
/*
Spread Operator - spreading of an element of an iterable collection
like an array or even a string into literal elements and individual
function parameters.

 */
function xyz(x,y,z){
    console.log('x '+x+' y '+y+' z '+z);
}

// xyz(11,22,33);
// const arr = [1,2,3];
// xyz(...arr); // Spread Operator

let arr1 = [11,22,33];
let arr2 = [44,55,66];

let arr3 = [...arr1,...arr2];

console.log(arr3);

const str = 'abcd';
console.log(str);
console.log(...str);


// If ... (ellipsis) is on the right hand side of an assignment operator
// i.e. spread operator

// If ... (ellipsis) is on the left hand side of an assignment operator
// i.e. Rest parameter