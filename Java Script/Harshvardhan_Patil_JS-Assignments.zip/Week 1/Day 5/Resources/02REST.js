// ... (ellipsis) REST parameter - Aggregation of
// remaining arguments into a single parameter of a function

function xyz(x,y,...z){
    console.log('x '+x+' y '+y+' z '+z);
}

xyz(1,2);
xyz(1,2,3);
xyz(1,2,3,4);
xyz(1,2,3,4,5);