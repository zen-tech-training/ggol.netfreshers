
const myPromise = new Promise((resolve,reject) =>{
    // Resolve the promise after 1 second
    setTimeout(() => resolve(10),1000);
});

myPromise
.then((response) =>{
    console.log(response);// 10
    return response * 2;
})
.then((response) =>{
    console.log(response); // 20
    return response * 3;
})
.then((response) =>{
    console.log(response); // 60
}).catch((err) =>{
    console.error('Error '+err);
});
