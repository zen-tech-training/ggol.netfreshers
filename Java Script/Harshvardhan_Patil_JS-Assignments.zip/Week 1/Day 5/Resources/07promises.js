function fetchData(url){
    return new Promise((resolve,reject) =>{
        setTimeout(() =>{
            resolve(`Fetched data from  ${url}`);
        }, 2000);
    })
}

// // Sequential Execution
// fetchData('https://api.myapi.com/mydata')
// .then((data) =>{
//     console.log(data);
//     return fetchData('https://api.myapi.com/moredata');
// })
// .then((moredata) =>{
//     console.log(moredata);
// })
// .catch(err => console.error(err));

// Sugar coated syntax - keywords like async and await
// async await - ES2017 - gonna look your asynchronus code synchronous
// improving readability and makes it easier to understand the flow of the code.

/*
 Readability and Synchronous style
 Error Handling - In promise using .catch()
                  - In try/catch blocks - more consistent with 
                    - synchronous code error handling
 Control Flow
*/

// Sequential Execution
async function fetchSequentialData(){

    try{
    const data = await fetchData('https://api.myapi.com/mydata');
    console.log(data);
    const moredata = await fetchData('https://api.myapi.com/moredata');
    console.log(moredata);
    }
    catch(err){
        console.error(err);
    }
}
fetchSequentialData();

// // Parallel Execution
// Promise.all([
//     fetchData('https://api.myapi.com/dataX'),
//     fetchData('https://api.myapi.com/dataY'),
//     fetchData('https://api.myapi.com/dataZ'),
// ])
// .then((moredata) =>{
//     console.log(moredata);
// })
// .catch(err => console.error(err));

// // Parallel Execution
// async function fetchParallelData(){
//     const results = await Promise.all([
//         fetchData('https://api.myapi.com/dataX'),
//         fetchData('https://api.myapi.com/dataY'),
//         fetchData('https://api.myapi.com/dataZ'),
//     ]);

//     //console.log(results);
//     results.forEach((result)=> console.log(result));
    
// }
// fetchParallelData();

// fetchData('https://api.myapi.com/mydata')
// .then((data) =>{
//     console.log(data); 
// })
// .catch(err => console.error(err))


// fetch('https://jsonplaceholder.typicode.com/todos')
//       .then(json => console.log(json))
//       .catch(err => console.error(err));

// fetch('https://jsonplaceholder.typicode.com/todos')
//       .then(response => {
//         console.log(response)
//         return response.json()
//     })
//       .then(json => console.log(json))
//       .catch(err => console.error(err));