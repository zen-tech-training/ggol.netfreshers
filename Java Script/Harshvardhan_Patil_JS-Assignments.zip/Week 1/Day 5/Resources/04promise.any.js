// Promise.any waits for any of the promises to get resolved and then 
// this one get resolved.

let promise1 = Promise.reject(10);
let promise2 = new Promise((resolve,reject) =>{
    setTimeout(resolve,1000,'promise 2');
});
let promise3 = new Promise((resolve,reject) =>{
    setTimeout(resolve,500,'promise 3');
});

let promises = [promise1,promise2,promise3];

Promise.any(promises)
.then((value) => console.log(value))
.catch(err => console.error(err));