//es5
// // default parameters
// function foo(x,y,z){
//     if(x === undefined){
//         x = 0;
//     }
//     if(y === undefined){
//         y = 0;
//     }
//     if(z === undefined){
//         z = 0;
//     }
//     return x+y+z;
// }

//ES 2015
// default parameters
function foo(x=0,y=0,z=0){
    return x+y+z;
}

// console.log(foo());
// console.log(foo(4));
// console.log(foo(4,5));
// console.log(foo(4,5,6));

const str = 'simple string';
const strI = `
    String declared with
    template literal
    ${str}
`
console.log(str)
console.log(strI)