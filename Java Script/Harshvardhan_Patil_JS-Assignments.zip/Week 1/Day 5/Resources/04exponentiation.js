// ** exponentiation operator
// to calculate the power of numbers

let square = 5 ** 2;
let cube = 5 ** 3;

console.log(square+' '+cube);

let num = 5;
num **= 2;

console.log(num);
const base = 2;
const exponent = 5;

let power = base ** exponent;

console.log(power);

let root = 9 ** (1/2);

console.log(root);