// Promise.allSetteled and Promise.all works on multiple promises
// but the outcomes of those promises are different

// Promise.allSetteled - when you need to know the outcome of each promise
// regardless of whether they fulfill or reject.

const promise1 = Promise.resolve(3);
//const promise2 = Promise.resolve(33);
const promise2 = Promise.reject('Error Message');
const promise3 = new Promise((resolve,reject) =>{
    setTimeout(resolve,500,'promise 3');
});

const promises = [promise1,promise2,promise3];

Promise.allSettled(promises)
.then((value) => console.log(value))
.catch(err => console.error(err));