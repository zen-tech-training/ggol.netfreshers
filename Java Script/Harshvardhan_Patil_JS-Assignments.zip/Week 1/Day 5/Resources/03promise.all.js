// Promise.all waits for all the promises to be fulfilled or
// for any to be rejected

const promise1 = Promise.resolve(33);
const promise2 = 42; // Promise.reject(42);
const promise3 = new Promise((resolve,reject) =>{
    setTimeout(reject,1000,'someText');
});

Promise.all([promise1,promise2,promise3])
.then((values) =>{
    console.log(values);
})
.catch(err =>{
    console.error('Error '+err);
})
