// Promise.race - returns the result of the first promise that 
// settles (fulfilled or rejected)

let promise1 = new Promise((resolve,reject) =>{
    setTimeout(resolve,400,'promise 1');
});

let promise2 = new Promise((resolve,reject) =>{
    setTimeout(resolve,100,'promise 2');
});

let promise3 = new Promise((resolve,reject) =>{
    setTimeout(resolve,500,'promise 3');
});


let promises = [promise1,promise2,promise3];

Promise.race(promises)
.then((value) => console.log(value))
.catch(err => console.error(err));