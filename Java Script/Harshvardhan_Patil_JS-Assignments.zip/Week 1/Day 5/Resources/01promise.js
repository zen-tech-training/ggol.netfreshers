
const myPromise = new Promise((resolve,reject) =>{

    const success = false; // simulate an asynchronous operation - result
    if(success){
        resolve('The operation was successful!');
    }else{
        reject('The operation failed!');
    }
});

myPromise.then((response) =>{
    console.log('Success '+response);
}).catch((err) =>{
    console.error('Failure '+err);
});

