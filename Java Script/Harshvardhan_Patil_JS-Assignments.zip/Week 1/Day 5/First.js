function wait(delay,val)
{
    return new Promise(resolve => setTimeout(resolve,delay,val));
}

const l1=wait(1000,10);
l1.then(res => console.log(res)).catch(err => console.error(err)).finally(() => console.log("always"));


const l2=wait(3000,20);
l2.then(res => console.log(res)).catch(err => console.error(err)).finally(() => console.log("always"));


const l3=wait(500,30);
l3.then(res => console.log(res)).catch(err => console.error(err)).finally(() => console.log("always"));
