const res=2**(1/4);
console.log(res);

// Right to Left same as CPP
function defaultparam(x,y,z=0)
{
    return x+y+z;
}

console.log(defaultparam(10,10));


function CheckRest(a,b,...c)
{
    console.log('a '+a+' b '+b+' c '+c);
}
console.log(CheckRest(1,2));
console.log(CheckRest(1,2,3,4));
console.log(CheckRest(1,2,4));
console.log(CheckRest(4,3,2,2,2,2));
console.log(CheckRest(1));

function CheckSpread(a,b,c)
{
    console.log(c);
    return a+b+c;
}

const arr=[1,2,3,4,5,6];
console.log(CheckSpread(...arr));

const o1={id:21,name:"ABC"};
const o2={id:"22"};
const o={...o1,...o2};
console.log(o);

var z="abcdefg";
console.log(CheckSpread(...z));