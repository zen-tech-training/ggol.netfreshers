const myPromise = new Promise((resolve,reject)=>{
    setTimeout(() => resolve(10),1000);
});

myPromise.then((res) =>
{
    console.log(res);
    return res*res*2;
}).then((res) =>{
    console.log(res);
    return res*res*res*3;
}).then((res) => {
    console.log(res);
}).catch((err) =>{
    console.error(err);
}).finally(() => {
    console.log("Always");
});


