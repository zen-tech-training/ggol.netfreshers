const myPromise=new Promise((resolve,reject)=>{
    const val=true;
    if(!(!val))
        {
            resolve("Hehehe");
        }
        else
        {
            reject("eheheh");
        }
});

myPromise.then((res)=>{
    console.log(res);
}).catch((err)=>{
    console.error(err);
}).finally()
{
    console.log("Always");
}