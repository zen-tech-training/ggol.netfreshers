function add() {
  if (arguments.length === 2) {
    return arguments[0] + arguments[1];
  } else if (arguments.length === 3) {
    return arguments[0] + arguments[1] + arguments[2];
  } else if (arguments.length === 4) {
    return arguments[0] + arguments[1] + arguments[2] + arguments[3];
  } else {
    throw new Error("Unsupported number of arguments for add function.");
  }
}

console.log(add(2, 3));
console.log(add(2, 3, 5));
console.log(add(2, 3, 5, 7));
