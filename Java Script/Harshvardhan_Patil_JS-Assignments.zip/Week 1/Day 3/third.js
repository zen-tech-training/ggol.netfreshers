const Human = {
  init: function (name) {
    this.name = name;
  },
  speak: function () {
    console.log("Hello, I am " + this.name);
  },
  introduction: function () {
    console.log("My name is " + this.name);
  },
};

const Student = Object.create(Human);

Student.init = function (name, college, courses) {
  Human.init.call(this, name);
  this.college = college;
  this.courses = courses;
};

Student.introduction = function () {
  console.log(
    "I am a student named " + this.name + " studying at " + this.college
  );
};

Student.takeExams = function () {
  console.log("Taking exams...");
};

let john = Object.create(Student);
john.init("John Doe", "Example College", ["Math", "Science"]);

john.introduction();
john.speak();
john.takeExams();
john.introduction();
