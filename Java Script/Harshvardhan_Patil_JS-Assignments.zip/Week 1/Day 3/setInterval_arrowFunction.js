function Animal()
{
    this.count=0;
    setInterval(() =>{
        console.log(this.count);
        this.count++;
    },1000);
}
const o=new Animal();
const o1=new Animal();
// console.log(o.count);