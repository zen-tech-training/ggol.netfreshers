var empModule = (function(){
    var empList = []; // private data;

    return {
        add:function(e){
            empList.push(e);
        },
        show:function(){
            for(var index in empList){
                console.log(empList[index]);
            }
        }
    }
})();
