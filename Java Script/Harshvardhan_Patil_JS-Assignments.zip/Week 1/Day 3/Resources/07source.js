// Model

// Initialize the Model
var model = {
    _name:'default',

    get name(){
        return this._name;
    },
    set name(value){
        this._name = value;
        updateView();
    }
}

// Create one Method to update the View based on the Model
function updateView(){
    //target                                    //source
    document.getElementById('nameInput').value = model.name;
    document.getElementById('nameDisplay').textContent = model.name;
}

// Event Listener for textboxe's change event
function changeFun(evt){
    console.log('changeFun');
    // source is modified
    model.name = evt.target.value;
    console.log(model.name);
}

document.onreadystatechange = function(){

    var inputEle = document.getElementById('nameInput');
    
    inputEle.onchange = changeFun;

    updateView();
}