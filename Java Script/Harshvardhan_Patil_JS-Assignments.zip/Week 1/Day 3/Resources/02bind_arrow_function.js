// ES5 class Person

// function Person(){
//     this.age = 0;
//     setInterval(function growUp(){
//         this.age++;
//         console.log(this.age);
//     },1000);
// }

// const p1 = new Person();
// console.log(p1.age);

// // 1 ES5 using another variable to store 'this'
// function Person(){
//     var that = this;
//     this.age = 0;// 'this' belongs to Person class
//     setInterval(function growUp(){
//         that.age++; // 'this' belongs to Person class
//         console.log(that.age);
//     },1000);
// }

// const p1 = new Person();
// console.log(p1.age);

// // 2 ES5 using bind function
// function Person(){
//     this.age = 0;// 'this' belongs to Person class
//     setInterval(function growUp(){
//         this.age++; // 'this' belongs to Person class
//         console.log(this.age);
//     }.bind(this),1000);
// }

// const p1 = new Person();
// console.log(p1.age);

//3 ES2015 Arrow Function

function Person(){
    this.age = 0;
    // Arrow Function - It doesn't create any new context it uses the 
    // enclosing context i.e. here Person class context and hence it is
    // Person class's 'this'.
    setInterval(() =>{
        this.age++;
        console.log(this.age);
    },1000);
}

const p1 = new Person();
console.log(p1.age);

// Arrow Function - Lambda Expression

function add(x,y){
    return x+y;
}
console.log('Result is ',add(4,5));

let sum = (x,y) => x+y; // lambda expression
console.log('Result is ',sum(4,5));

let greet = () => "Hello ES2015!";
console.log(greet());

let mult = (x,y) => {
                        console.log('Inside mult!');
                        return x*y;
                    }
console.log('Result is ',mult(4,5));
                    