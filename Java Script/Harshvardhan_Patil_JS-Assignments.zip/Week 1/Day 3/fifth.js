const ShoppingCartModule = (function () {
  const cart = [];

  function findProductIndex(productId) {
    return cart.findIndex((item) => item.productId === productId);
  }

  return {
    addItem: function (productId, name, price, quantity = 1) {
      const index = findProductIndex(productId);
      if (index !== -1) {
        cart[index].quantity += quantity;
      } else {
        cart.push({
          productId: productId,
          name: name,
          price: price,
          quantity: quantity,
        });
      }
    },
    removeItem: function (productId) {
      const index = findProductIndex(productId);
      if (index !== -1) {
        cart.splice(index, 1);
      }
    },
    getAllItems: function () {
      return cart;
    },
    getTotalPrice: function () {
      let totalPrice = 0;
      cart.forEach((item) => {
        totalPrice += item.price * item.quantity;
      });
      return totalPrice;
    },
  };
})();

ShoppingCartModule.addItem(1, "Product A", 10.99, 2);
ShoppingCartModule.addItem(2, "Product B", 5.99);
ShoppingCartModule.addItem(1, "Product A", 10.99, 1);
console.log("All Items:", ShoppingCartModule.getAllItems());

console.log("Total Price:", ShoppingCartModule.getTotalPrice());

ShoppingCartModule.removeItem(2);

console.log(
  "All Items after removing Product B:",
  ShoppingCartModule.getAllItems()
);

console.log(
  "Total Price after removing Product B:",
  ShoppingCartModule.getTotalPrice()
);
