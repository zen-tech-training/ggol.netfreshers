function Vehicle(make, model) {
  this.make = make;
  this.model = model;
}
function Car(make, model) {
  Vehicle.call(this, make, model);
  this.wheels = 4;
}
Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car;

function Bike(make, model) {
  Vehicle.call(this, make, model);
  this.wheels = 2;
}
Bike.prototype = Object.create(Vehicle.prototype);
Bike.prototype.constructor = Bike;
