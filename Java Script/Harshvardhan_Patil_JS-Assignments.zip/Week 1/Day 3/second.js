function processArguments(arg1, arg2, arg3) {
  if (
    typeof arg1 === "string" &&
    typeof arg2 === "string" &&
    arg3 === undefined
  ) {
    return arg1 + arg2;
  } else if (
    typeof arg1 === "number" &&
    typeof arg2 === "number" &&
    arg3 === undefined
  ) {
    return arg1 + arg2;
  } else if (
    typeof arg1 === "number" &&
    typeof arg2 === "number" &&
    typeof arg3 === "number"
  ) {
    return arg1 + arg2 + arg3;
  } else if (
    typeof arg1 === "string" &&
    typeof arg2 === "number" &&
    arg3 === undefined
  ) {
    return arg1 + arg2;
  } else {
    let sum = 0;
    for (let arg of arguments) {
      if (typeof arg === "number") {
        sum += arg;
      }
    }
    return sum;
  }
}

console.log(processArguments("Hello", "World"));
console.log(processArguments(2, 3));
console.log(processArguments(1, 2, 3));
console.log(processArguments("Value is: ", 5));
console.log(processArguments(2, " is a number"));
console.log(processArguments(1, "two", 3, "four"));
