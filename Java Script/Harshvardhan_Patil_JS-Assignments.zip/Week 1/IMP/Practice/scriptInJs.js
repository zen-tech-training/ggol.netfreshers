document.addEventListener('DOMContentLoaded',function(){
    
    const todoin=document.getElementById('todokInput');
    const addbtn=document.getElementById('addTodoButton');
    const lst=document.getElementById('todoList');

    addbtn.addEventListener('click', function(){
        const txt=todoin.value.trim();

        if(txt)
        {
            const li=document.createElement('li');
            li.innerHTML=`${txt} <button class="db">Remove</button>`;
            lst.appendChild(li);

            li.querySelector('.db').addEventListener('click', ()=> li.remove());
            todoin.value='';
        }
        else
        {
            alert("Enter Valid");
        }
    })

    todoin.addEventListener('keypress', evn =>{
        if(evn.key==='Enter')
        {
            addbtn.click();
        }
    })

})