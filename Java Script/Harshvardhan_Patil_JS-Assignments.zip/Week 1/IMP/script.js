// document.addEventListener('DOMContentLoaded', function() {
//     const todoInput = document.getElementById('todokInput');
//     const addTodoButton = document.getElementById('addTodoButton');
//     const todoList = document.getElementById('todoList');

//     addTodoButton.addEventListener('click', function() {
//         const todoText = todoInput.value.trim();
//         if (todoText) {
//             const li = document.createElement('li');
//             li.innerHTML = `${todoText} <button class="deleteButton">Remove</button>`;
//             todoList.appendChild(li);

//             li.querySelector('.deleteButton').addEventListener('click', () => li.remove());

//             todoInput.value = '';
//         } else {
//             alert('Please enter a valid todo item.');
//         }
//     });

//     todoInput.addEventListener('keypress', event => {
//         if (event.key === 'Enter') addTodoButton.click();
//     });
// });
document.addEventListener('DOMContentLoaded',function(){
    const todoinput=document.getElementById('todokInput');
    const addtobun=document.getElementById('addTodoButton');
    const lst=document.getElementById('todoList');

    addtobun.addEventListener('click',function(){
        const txt=todoinput.value.trim();
        if(txt)
        {
            const li=document.createElement('li');
            li.innerHTML=`${txt} <button class="db">Remove</button>`;
            lst.appendChild(li);

            li.querySelector('.db').addEventListener('click',()=> li.remove());
            todoinput.value='';
        }
        else
        {
            alert("Enter Valid Value");
        }
    });

    todoinput.addEventListener('keypress', event =>{
        if(event.key==='Enter')
        {
            addtobun.click();
        }
    })
})