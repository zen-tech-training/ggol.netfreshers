function add(x,y){
    console.log('Inside add!');
    return x+y;
}
function mult(x,y){
    console.log('Inside mult!');
    return x*y;
}