document.addEventListener("DOMContentLoaded", function () {
  const inpttxt = document.getElementById("item-input");
  const addbtn = document.getElementById("add-button");
  const lst = document.getElementById("todoList");

  addbtn.addEventListener("click", function () {
    const txt = inpttxt.value.trim();

    if (txt) {
      const li = document.createElement("li");

      li.innerHTML = `${txt} <button class="db">Remove </button> <button class="alrd"> Mark </button>`;
      lst.appendChild(li);

      li.querySelector(".db").addEventListener("click", () => li.remove());

      li.querySelector(".alrd").addEventListener("click", () => {
        li.innerHTML = `<strike> ${txt} </strike> <button class="db">Remove </button> <button class="uald"> Unmark </button>`;

        li.querySelector(".db").addEventListener("click", () => li.remove());

        li.querySelector(".uald").addEventListener("click", () => {
          li.innerHTML = ` ${txt} <button class="db">Remove </button> <button class="uald"> Mark </button>`;

          li.querySelector(".db").addEventListener("click", () => li.remove());
        });

        li.querySelector(".db").addEventListener("click", () => li.remove());
      });

      inpttxt.value = "";
    } else {
      alert("Enter Neatly");
    }
  });

  inpttxt.addEventListener("keypress", (evt) => {
    if (evt.key === "Enter") {
      addbtn.click();
    }
  });
});
