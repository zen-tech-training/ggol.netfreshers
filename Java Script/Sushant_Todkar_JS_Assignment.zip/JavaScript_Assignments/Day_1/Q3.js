//is pallindrome

function isPalindrome(inputString) {
    const cleanedString = inputString.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    let left = 0;
    let right = cleanedString.length - 1;

    while (left < right) {
        if (cleanedString[left] !== cleanedString[right]) {
            return false;
        }
        left++;
        right--;
    }

    return true;
}


const testString1 = "Madam";
const testString2 = "hello";

console.log(`"${testString1}" is a palindrome: ${isPalindrome(testString1)}`);
console.log(`"${testString2}" is a palindrome: ${isPalindrome(testString2)}`);
