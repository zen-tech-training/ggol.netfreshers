
//Problem:   Write a function to calculate the sum of all numbers in an array.
function sumArray(numbers) {
    let total = 0;
    for (const num of numbers) {
        total += num;
    }
    return total;
}


const myNumbers = [10, 5, 3, 7, 12];
const result = sumArray(myNumbers);
console.log(`The sum of the array is: ${result}`);
