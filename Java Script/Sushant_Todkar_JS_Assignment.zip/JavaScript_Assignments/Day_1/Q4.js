//Write a function to filter an array of objects based on a specified condition.
//People array with name and age and where age is greater than 18.

function filterAdults(peopleArray) {
    // Filter out individuals whose age is greater than or equal to 18
    const adults = peopleArray.filter(person => person.age >= 18);
    return adults;
}


const people = [
    { name: 'Sushant', age: 25 },
    { name: 'Rohit', age: 17 },
    { name: 'Harsh', age: 30 },
    { name: 'Rahul', age: 16 },
   
];

const adultsOnly = filterAdults(people);
console.log(adultsOnly);
