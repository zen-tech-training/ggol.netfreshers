//Find the largest number in array

function findLargestNumber(arr) {
    if (!Array.isArray(arr) || arr.length === 0) {
        return null; // Return null for empty arrays or non-array inputs
    }

    let largest = arr[0]; // Assume the first element is the largest

    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > largest) {
            largest = arr[i]; // Update largest if we find a bigger number
        }
    }

    return largest;
}

const myArray = [10, 5, 23, 8, 42, 17];
const largestNumber = findLargestNumber(myArray);
console.log(`The largest number in the array is: ${largestNumber}`);
