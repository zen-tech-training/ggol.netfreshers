//Find Intersection of Two Arrays

function findIntersection(arr1, arr2) {
   
    const set1 = new Set(arr1);

    // Filter the second array based on the Set
    const intersection = arr2.filter(item => set1.has(item));

    return intersection;
}


const array1 = [1, 2, 3, 4, 5];
const array2 = [3, 4, 5, 6, 7];
const commonElements = findIntersection(array1, array2);
console.log(commonElements); 
