//Remove Dublicates
function removeDuplicates(arr) {
    
    const uniqueSet = new Set(arr);

   
    const uniqueArray = Array.from(uniqueSet);

    return uniqueArray;
}


const myArray = [10, 5, 10, 7, 5, 12, 7];
const result = removeDuplicates(myArray);
console.log(result); 
