function objectToArray(obj) {
    //  Object.entries() to get an array of key-value pairs
    const keyValuePairs = Object.entries(obj);

    return keyValuePairs;
}


const myObject = {
    name: 'Sushant',
    age: 30,
    city: 'Pune'
};

const keyValueArray = objectToArray(myObject);
console.log(keyValueArray);

