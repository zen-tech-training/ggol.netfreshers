//sort people by age

const people = [
    { name: 'Sushant', age: 30 },
    { name: 'Vaibhav', age: 25 },
    { name: 'Ram', age: 35 },
   
];



function sortByAge(peopleArray) {
    return peopleArray.sort((personA, personB) => personA.age - personB.age);
}


const sortedPeople = sortByAge(people);
console.log(sortedPeople);

