//Write a function to flatten a nested array.
function flattenArray(stack) {

    const unfoldedItems = stack.flat();

    return unfoldedItems;
}


const nestedPicnic = [[1, 2], [3, 4], [5, 6]];
const flatPicnic = flattenArray(nestedPicnic);
console.log(flatPicnic); 
