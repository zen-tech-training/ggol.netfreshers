const ShoppingCart = (function(){
    let cart = [];

    function findProductIndex(productId){
        return cart.findIndex(product => product.productId === productId);
    }

    return {

        addItem: function(productId, name, price) {
            const index = findProductIndex(productId);
            if (index !== -1){
                cart[index].quantity += 1;
            }else{
                cart.push({ productId, name, price, quantity: 1 });
            }
        },

        removeItem: function(productId) {
            const index = findProductIndex(productId);
            if (index !== -1){
                cart.splice(index, 1);
            }
        },

        getAllItems: function(){
            return cart;
        },

        getTotalPrice: function(){
            return cart.reduce((total, product) => total + (product.price * product.quantity), 0);
        }
    };
})();

ShoppingCart.addItem(1, 'Apple', 10);
ShoppingCart.addItem(2, 'Banana', 10);
ShoppingCart.addItem(1, 'Apple', 10); 
console.log(ShoppingCart.getAllItems());
console.log(ShoppingCart.getTotalPrice());
ShoppingCart.removeItem(1);
console.log('Item removed')
console.log(ShoppingCart.getAllItems());
