// Q1
function Addition(){
    let sum = 0;
    for(let i = 0; i < arguments.length; i++){
        if(typeof(arguments[i]) != 'number')
            return NaN;

        sum += arguments[i];
    }
    return sum;
}
// let add = Addition(1,2,12);
// console.log(add);

// Q2

function overload(){
    if(arguments.length == 2){
        if(typeof(arguments[0]) === 'string' && typeof(arguments[1]) === 'string')
            console.log(`${arguments[0]} and ${arguments[1]} are string`);
        
        else if(typeof(arguments[0]) === 'number' && typeof(arguments[1]) === 'number')
            console.log(`${arguments[0]} and ${arguments[1]} are number`);
        
        else if(typeof(arguments[0]) === 'number' && typeof(arguments[1]) === 'string')
            console.log(`One is string, other is number`);
    }else{
        console.log(`${arguments[0]}, ${arguments[1]} and ${arguments[2]} are number`);
    }
}

// let o = overload('1','1');

