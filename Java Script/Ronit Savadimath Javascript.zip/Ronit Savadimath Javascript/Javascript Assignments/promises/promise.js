function wait(ms) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`Completed after ${ms} ms`);
        }, ms);
    });
}

wait(2000)
    .then((msg) => {
        console.log(msg);
    });



function task1() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('Task 1 completed');
        }, 1000);
    });
}

function task2() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('Task 2 completed');
        }, 1500);
    });
}

function task3() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('Task 3 completed');
        }, 800);
    });
}

task1()
    .then((msg) => {
        console.log(msg);
        return task2();
    })
    .then((msg) => {
        console.log(msg);
        return task3();
    })
    .then((msg) => {
        console.log(msg);
    });


function errorProneTask() {
    return new Promise((resolve, reject) => {
        const random = Math.random();
        if (random < 0.5) {
            resolve('Success');
        } else {
            reject(new Error('Somethign went wrong'));
        }
    });
}

errorProneTask()
    .then((msg) => {
        console.log(msg);
    })
    .catch((error) => {
        console.error(error.msg);
    });



function taskA() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('Task A complete');
        }, 1200);
    });
}

function taskB() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('Task B complete');
        }, 800);
    });
}

function taskC() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('Task C complete');
        }, 1500);
    });
}

Promise.all([taskA(), taskB(), taskC()])
    .then((results) => {
        results.forEach((message) => {
            console.log(message);
        });
    });
