function Vehicle(make, model) {
    this.make = make;
    this.model = model;
}

function Car(make, model) {
    Vehicle.call(this, make, model);
    this.wheels = 4;
}

function Bike(make, model) {
    Vehicle.call(this, make, model);
    this.wheels = 2;
}

const myCar = new Car('Audi', 'A6');
const myBike = new Bike('BMW', 'Series 2');

console.log(typeof myCar);
console.log(typeof myBike);

console.log(myCar instanceof Vehicle);
console.log(myCar instanceof Car);
console.log(myCar instanceof Bike);

console.log(myBike instanceof Vehicle);
console.log(myBike instanceof Car);
console.log(myBike instanceof Bike);

console.log(myCar.constructor === Car);
console.log(myBike.constructor === Bike);

console.log(Object.getPrototypeOf(myCar) === Car.prototype);
console.log(Object.getPrototypeOf(myBike) === Bike.prototype);


