//task1
async function fetchData() {
    await new Promise((resolve) => {
        setTimeout(() => {
            resolve();
        }, 2000); 
    });

    console.log('Data fetched after 2secs using async await');
}
fetchData();

//task2 and task3
async function getUserData() {
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
        if (!response.ok) {
            throw new Error('Network error');
        }

        const userData = await response.json();
        console.log('User data:', userData);
    } catch (error) {
        console.error('Error fetching user data:', error.message);
    }
}
getUserData();


//task4
async function fetchPosts() {
    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
    const posts = await response.json();
    return posts;
}

async function fetchComments() {
    const response = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1');
    const comments = await response.json();
    return comments;
}

async function fetchAllData() {
    try {
        const [posts, comments] = await Promise.all([fetchPosts(), fetchComments()]);
        console.log('Posts:', posts);
        console.log('Comments:', comments);
    } catch (error) {
        console.error('Error fetching data:', error.message);
    }
}
fetchAllData();


//task5
async function fetchAllData() {
    try {
        const [posts, comments] = await Promise.all([fetchPosts(), fetchComments()]);
        console.log('Posts:', posts);
        console.log('Comments:', comments);
    } catch (error) {
        console.error('Error fetching data:', error.message);
    }
}
fetchAllData();

