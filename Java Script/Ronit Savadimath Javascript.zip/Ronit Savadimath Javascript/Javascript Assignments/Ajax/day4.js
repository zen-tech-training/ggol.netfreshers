function $(id) {
    return document.getElementById(id);
}

$('01button').addEventListener('click', getData);
$('02button').addEventListener('click', postData);

function getData() {
    console.log('asd')
    let uid = $('01input').value.trim();
    if (uid === '') {
        return;
    }

    const URL = `https://jsonplaceholder.typicode.com/posts/${uid}`;

    let http = new XMLHttpRequest();

    http.onreadystatechange = () => {
        if (http.readyState == 4) {
            try {
                if (http.status >= 200 && http.status <= 299) {

                    let res = JSON.parse(http.responseText);
                    $('01title').innerText = `Title:    ${res.title}`;
                    $('01id').innerText = `Id:  ${res.id}`;
                    $('01body').innerText = `Body:  ${res.body}`;
                } else {
                    $('01body').innerText = 'No data retrieved';
                }
            } catch (e) {
                $('01body').innerText = 'Something went wrong';
            }
        }
    }

    http.open('GET', URL, true);
    http.send();
}

function postData() {
    let title = $('02title').value.trim();
    let id = $('02id').value.trim();
    let body = $('02body').value.trim();
    if (title == '' || id == '' || body == '') {
        return;
    }

    const URL = `https://jsonplaceholder.typicode.com/posts`;

    let http = new XMLHttpRequest();

    http.onreadystatechange = () => {
        if (http.readyState === 4) {
            try {
                if (http.status >= 200 && http.status <= 299) {
                    console.log(http.responseText);
                } else {
                    document.getElementById('01body').innerText = 'No data retrieved';
                }
            } catch (e) {
                document.getElementById('01body').innerText = 'Something went wrong';
            }
        }
    };

    try {
        http.open('POST', URL, true);
        http.setRequestHeader('Content-Type', 'application/json');

        const data = {
            title: title,
            userId: id,
            body: body
        };

        http.send(JSON.stringify(data));
    } catch (error) {
        console.error(error.message);
    }

}