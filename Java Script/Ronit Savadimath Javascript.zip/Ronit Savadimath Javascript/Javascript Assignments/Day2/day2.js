//task1
const car = {
    make: 'audi',
    model: 'A6',
    year: 2013,
    getCarInfo: function() {
        return `${this.make} ${this.model} (${this.year})`;
    }
};
console.log(car.getCarInfo());

// task2
function Animal(name, sound) {
    this.name = name;
    this.sound = sound;
}

Animal.prototype.makeSound = function() {
    console.log(this.sound);
};

function Dog(name, sound) {
    Animal.call(this, name, sound);
}

Dog.prototype = Object.create(Animal.prototype);
Dog.prototype.constructor = Dog;

Dog.prototype.fetch = function() {
    console.log(`${this.name} fetchs`);
};

const myDog = new Dog('Toommy', 'bark');
myDog.makeSound(); 
myDog.fetch();

//task3
function BankAccount() {
    let balance = 0;

    this.deposit = function(amount) {
        balance += amount;
    };

    this.withdraw = function(amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            console.log('Insufficient funds');
        }
    };
    this.getBalance = function() {
        return balance;
    };
}

const myAccount = new BankAccount();
myAccount.deposit(100);
myAccount.withdraw(50);
console.log(myAccount.getBalance());


//task4

function Shape() {

}

Shape.prototype.getArea = function() {
    return 0;
};

function Circle(r) {
    this.radius = r;
}

Circle.prototype = Object.create(Shape.prototype);
Circle.prototype.constructor = Circle;

Circle.prototype.getArea = function() {
    return Math.PI * this.radius * this.radius;
};

function Rectangle(width, height) {
    this.width = width;
    this.height = height;
}

Rectangle.prototype = Object.create(Shape.prototype);
Rectangle.prototype.constructor = Rectangle;

Rectangle.prototype.getArea = function() {
    return this.width * this.height;
};

const myCircle = new Circle(5);
console.log(myCircle.getArea());

const myRectangle = new Rectangle(4, 5);
console.log(myRectangle.getArea()); 


//task5
function Vehicle(make, model, year) {
    this.make = make;
    this.model = model;
    this.year = year;
}

Vehicle.prototype.getDetails = function() {
    return `${this.make} ${this.model} - ${this.year}`;
};

function Car(make, model, year, doors) {
    Vehicle.call(this, make, model, year);
    this.doors = doors;
}

Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car;

Car.prototype.getDetails = function() {
    return `${this.make} ${this.model} ${this.year} model has ${this.doors} doors`;
};

const myCar = new Car('Audi', 'A2', 2019, 4);
console.log(myCar.getDetails());


//task6
function MathUtil() {

}

MathUtil.add = function(a, b) {
    return a + b
};

MathUtil.subtract = function(a, b) {
    return a - b;
};

MathUtil.multiply = function(a, b) {
    return a * b;
};

MathUtil.divide = function(a, b) {
    if (b != 0) {
        return a / b;
    } else {
        console.log('You cannot divide a number by zero');
    }
};

console.log(MathUtil.add(6, 10)); 
console.log(MathUtil.subtract(10, 3));
console.log(MathUtil.multiply(2, 11));
console.log(MathUtil.divide(33, 3));



//task7
function Book(title, author, year) {
    this.title = title;
    this.author = author;
    this.year = year;
}

Book.prototype.getSummary = function() {
    return `${this.title}  is written by ${this.author}and  published in ${this.year}`;
};

Book.prototype.setYear = function(newYear) {
    this.year = newYear;
    console.log(`New year updateis: ${newYear}`);
};

const myBook = new Book('Avengers', 'Stan Lee', 2011);
console.log(myBook.getSummary());
myBook.setYear(2018);   
console.log(myBook.getSummary());

//task8

function User(username, password) {
    this.username = username;
    this.password = password;
    this.address = null;
}

function Address(street, city, country) {
    this.street = street;
    this.city = city;
    this.country = country;
}

User.prototype.setAddress = function(address) {
    this.address = address;
};

User.prototype.getAddress = function() {
    if (this.address) {
        return `${this.address.street}, ${this.address.city}, ${this.address.country}`;
    } else {
        return 'Adress was not found';
    }
};

const myUser = new User('Ronit Savadimath', '1029qpzm');
const myAddress = new Address('Wagholi', 'Pune', 'India');
myUser.setAddress(myAddress);
console.log(myUser.getAddress());


//task9
function Shape() {

}

Shape.prototype.getArea = function() {
    return 0;
};

function Square(sideLength) {
    this.sideLength = sideLength;
}

Square.prototype = Object.create(Shape.prototype);
Square.prototype.constructor = Square;

Square.prototype.getArea = function() {
    return this.sideLength * this.sideLength;
};

function Triangle(base, height) {
    this.base = base;
    this.height = height;
}

Triangle.prototype = Object.create(Shape.prototype);
Triangle.prototype.constructor = Triangle;

Triangle.prototype.getArea = function() {
    return 0.5 * this.base * this.height;
};

const mySquare = new Square(10);
console.log(mySquare.getArea());

const myTriangle = new Triangle(10, 11);
console.log(myTriangle.getArea());


//task110
const Flyable = {
    fly: function() {
        console.log(`${this.name} is flying`);
    }
};

const Swimable = {
    swim: function() {
        console.log(`${this.name} is swimming`);
    }
};

function Duck(name) {
    this.name = name;
}

Object.assign(Duck.prototype, Flyable);
Object.assign(Duck.prototype, Swimable);

const d1 = new Duck('Donald Duck');
d1.fly();
d1.swim();




