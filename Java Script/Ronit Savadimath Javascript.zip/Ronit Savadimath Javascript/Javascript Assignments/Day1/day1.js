//q1
function reverseString(str) {
    return str.split('').reverse().join('');
}
const originalString = 'hello there';
const reversedString = reverseString(originalString);
console.log(reversedString);


//q2
function findLargestNumber(arr) {
    return Math.max(...arr);
}
const numbers = [10, 5, 20, 8, 15];
const largestNumber = findLargestNumber(numbers);
console.log(largestNumber);

//q3
function isPalindrome(str){
    let i = 0;
    let j =str.length - 1;

    while(i<j){
        if(str[i] != str[j]){
            console.log('Not palindomre')
            return;
        }
        i++
        j--
    }

    console.log('Palindrome')
}
const str1 = 'malayalam';
const str2 = 'hello';
isPalindrome(str1); 
isPalindrome(str2); 


//q4
const people = [
    { name: 'Nitin', age: 25 },
    { name: 'Krushnal', age: 30 },
    { name: 'Ronit', age: 17 },
];

function filterAdults(peopleArray) {
    return peopleArray.filter(person => person.age > 18);
}

const adults = filterAdults(people);
console.log(adults);

//q5
function sumArray(arr) {
    return arr.reduce((acc, curr) => acc + curr, 0);
}
const numbersToSum = [1, 2, 3, 4, 5];
const totalSum = sumArray(numbersToSum);
console.log(totalSum);

//q6
function removeDuplicates(arr) {
    return [...new Set(arr)];
}
const arrayWithDuplicates = [1, 2, 2, 3, 4, 4, 5];
const uniqueArray = removeDuplicates(arrayWithDuplicates);
console.log(uniqueArray);

//q7
function flattenArray(arr) {
    return arr.flat(Infinity);
}
const nestedArray = [1, [2, 3], [4, [5, 6]]];
const flattenedArray = flattenArray(nestedArray);
console.log(flattenedArray);


//q8
function findIntersection(array1, array2) {
    const set1 = new Set(array1);
    const set2 = new Set(array2);

    const intersection = [...set1].filter((element) => set2.has(element));
    return intersection;
}
const array1 = [1, 2, 3, 4];
const array2 = [3, 4, 5, 6];
const result = findIntersection(array1, array2);
console.log(result);


//q9
function objectToArray(obj) {
    return Object.entries(obj);
}
const myObj = { name: 'Ronit', age: 11 };
const resultArray = objectToArray(myObj);
console.log(resultArray);


//q10
const students = [
    { name: 'Nitin', age: 25 },
    { name: 'Krushnal', age: 30 },
    { name: 'Ronit', age: 17 },
];

function sortByProperty(arr, property) {
    return arr.sort((a, b) => a[property] - b[property]);
}
const sortedByAge = sortByProperty(people, 'age');
console.log(sortedByAge);






