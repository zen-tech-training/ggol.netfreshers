const newDiv = document.createElement('div');
newDiv.textContent = 'Hello, World!';
document.body.appendChild(newDiv);


//q11
const button = document.createElement('button');
button.textContent = 'Change Background Color';
document.body.appendChild(button);

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

button.addEventListener('click', function() {
    document.body.style.backgroundColor = getRandomColor();
});


//q12
const inputField = document.createElement('input');
const toggleButton = document.createElement('button');
toggleButton.textContent = 'Toggle Border Color';
document.body.appendChild(inputField);
document.body.appendChild(toggleButton);

const style = document.createElement('style');
style.textContent = `
    .border-color {
        border: 2px solid red;
    }
`;
document.head.appendChild(style);

toggleButton.addEventListener('click', function() {
    inputField.classList.toggle('border-color');
});


//q13
const ul = document.createElement('ul');
const addButton = document.createElement('button');
addButton.textContent = 'Add Item';
document.body.appendChild(ul);
document.body.appendChild(addButton);

let itemCount = 0;
addButton.addEventListener('click', function() {
    itemCount++;
    const li = document.createElement('li');
    li.textContent = `Item ${itemCount}`;
    ul.appendChild(li);
});


//q14
const table = document.createElement('table');
document.body.appendChild(table);

let number = 1;
for (let i = 0; i < 3; i++) {
    const row = document.createElement('tr');
    for (let j = 0; j < 3; j++) {
        const cell = document.createElement('td');
        cell.textContent = number++;
        row.appendChild(cell);
    }
    table.appendChild(row);
}


//q15
const cloneButton = document.createElement('button');
cloneButton.textContent = 'Clone Paragraph';
const paragraph = document.createElement('p');
paragraph.textContent = 'This is the original paragraph.';
document.body.appendChild(paragraph);
document.body.appendChild(cloneButton);

cloneButton.addEventListener('click', function() {
    const clonedParagraph = paragraph.cloneNode(true);
    clonedParagraph.textContent = 'This is the cloned paragraph.';
    document.body.appendChild(clonedParagraph);
});

