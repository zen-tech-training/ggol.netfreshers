function add(){
    let sum=0;

    for(i of arguments) sum+=i;

    console.log(sum);
}

// add(12,6);
// add(12,4,5);
// add(12,5,6,9);


function doSomething(){
    if(arguments.length ==2){
        var arg1=arguments[0];
        var arg2=arguments[1];

        if(typeof arg1 =='string' && typeof arg2=='string'){

        }else if(typeof arg1 =='string' && typeof arg2=='number'){
            
        }else if(typeof arg1 =='number' && typeof arg2=='string'){
            
        }else if(typeof arg1 =='string' && typeof arg2=='string'){
            
        }
    }else{
        var arg2=typeof arguments[1];
        if(typeof arguments[2] =='number' && arg1 =='number' && arg2=='number' ){
        console.log("Do something of this numbers");
        }else{
            
        }
    }
}

//Prototype


function Human(name){
    this.name=name;
}

Human.prototype.speak=function(){
    console.log("I can speack");
}


Human.prototype.introduce=function(){
    console.log(`Hello I am ${this.name}`);
}

Student.prototype=new Human("sachin");

Student.prototype.constructor = Student

function Student(college, courses){
    Human.call(this,"Virat");
    this.college=college;
    this.courses=courses;
}

var student=new Student("Sinhgad",["HTML", "CSS", "Javascript"]);

Student.prototype.introduce=function(){
    console.log(`Hello I am ${this.name} I am from ${this.college} and I am learning ${this.courses}`);
}

Student.prototype.exams=function(){
    console.log("Let's give some exams");
}

student.introduce();



//Person 



