function $(id){
    return document.getElementById(id);
}


const titleInput=$('item-name');
const addButton=$('add-item');
const todoList=$('list')

addButton.addEventListener('click',()=>{
    var node=document.createElement("li");
    var textNode=document.createTextNode(titleInput.value);
    node.appendChild(textNode);
    var removeButton=document.createElement("button");
    removeButton.innerText="Remove";
    removeButton.style.marginLeft='10px';
    node.style.margin='24px';
    node.appendChild(removeButton);
    todoList.appendChild(node);
    removeButton.addEventListener('click',()=>{
        todoList.removeChild(node);
    })
})

document.addEventListener('keypress',(event)=>{
    if(event.key == 'Enter')addButton.click();
})
