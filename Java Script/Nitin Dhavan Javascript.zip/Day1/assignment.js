function reverseString(){
    var reverseThis="This string you have to reverse";
    var newString="";

    for(let i=reverseThis.length-1; i=>0; i--){
        newString+=reverseThis[i];
    }

    console.log(`reverse String ${newString}`);

    return newString;
}

console.log(reverseString());


function largestNumber(array){
    let highest=-Infinity;
    for(i of array){
        i=Math.max(i,highest);
    }

    console.log(`Highest number ${highest}`);

    return highest;
}

console.log(largestNumber([5,20,6,9,10]));

function checkPalindrome(string){
    let left=0;
    let right=string.length()-1;
    while(left < right){
        if(string[left] != string[right]) return false;
        right--;
        left++;
    }

    return true;
}

console.log(checkPalindrome("abcba"));
console.log(checkPalindrome("abccba"));

function filterArrayObject(arr){
    arr.filter((element) => element.height >= 18);

    return arr;
}

console.log(filterArrayObject(
    [
        {
            height: 20,
        },

        {
            height: 7,
        },

        {
            height: 10,
        }
    ]
))

function sumOfNumbers(arr){
    let sum=0;

    for(let i of arr){
        sum+=i;
    }

    return sum;
}

console.log(sumOfNumbers([10,11,20]));


function removeDuplicates(arr){
    var set=new Set();
    for(let i of arr){
        set.add(i);
    }

    return set.array
}

console.log(removeDuplicates([10,10,2,3,4,4]));

function flattenArray(arr){
    let returnArray = [];

    for(let i of arr){
        if(typeof i == 'number'){
            returnArray.push(i);
        }else{
            returnArray.push(flattenArray(i));
        }
    }

    return returnArray;
}

console.log(flattenArray([10,[20,30,30,10]]));

function intersection(arr, arr1){
    let pointer1=0;
    let pointer2=0;

    let result=[];
    while(pointer1 < arr.length() && pointer2 < arr1.length()){
        if(arr[pointer1] < arr1[pointer2]){
            pointer1++;
        }else if(arr[pointer1] > arr1[pointer2]){
            pointer2++;
        }else{
            result.push(arr[pointer1]);
            pointer1++;
            pointer2++;
        }
    }

    return result;
}

console.log(intersection([1,2,3,4],[3,4,5]));

function objectToArray(obj) {
    return Object.entries(obj);
}

var obj = {name: 'Krushnal', age: 30};
var result = objectToArray(obj);
console.log(result);


function sortPeopleByAge(peopleList, propertyToSortBy) {
    return peopleList.sort((person1, person2) => (person1[propertyToSortBy] > person2[propertyToSortBy]) ? 1 : ((person2[propertyToSortBy] > person1[propertyToSortBy]) ? -1 : 0));
}

var listOfPeople = [{name: 'Krushnal', age: 30}, {name: 'Ronit', age: 20}];
var sortedListOfPeople = sortPeopleByAge(listOfPeople, 'age');
console.log(sortedListOfPeople);

