function changeColor(){
    document.getElementById('colorBox').style.backgroundColor = 'red';
}