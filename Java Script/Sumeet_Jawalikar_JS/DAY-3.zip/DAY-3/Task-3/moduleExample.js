var ShoppingCart = (function() {
    // Private array to store cart items
    var cart = [];
   
    // Function to find an item in the cart by productId
    function findItem(productId) {
      return cart.find(function(item) {
        return item.productId === productId;
      });
    }
   
    return {
      // Add item to the cart
      addItem: function(productId, name, price, quantity) {
        var item = findItem(productId);
        if (item) {
          // If the item already exists, increase the quantity
          item.quantity += quantity;
        } else {
          // If the item does not exist, add it to the cart
          cart.push({
            productId: productId,
            name: name,
            price: price,
            quantity: quantity
          });
        }
      },
   
      // Remove item from the cart by productId
      removeItem: function(productId) {
        cart = cart.filter(function(item) {
          return item.productId !== productId;
        });
      },
   
      // Get all items in the cart
      getAllItems: function() {
        return cart.slice(); // Return a copy of the cart array
      },
   
      // Get total price of all items in the cart
      getTotalPrice: function() {
        return cart.reduce(function(total, item) {
          return total + (item.price * item.quantity);
        }, 0);
      }
    };
  })();
   
  // Example usage:
  ShoppingCart.addItem(1, "Apple", 0.99, 3);
  ShoppingCart.addItem(2, "Banana", 0.79, 2);
  ShoppingCart.addItem(1, "Apple", 0.99, 1); // Adds another Apple, increasing the quantity
   
  console.log(ShoppingCart.getAllItems());
  // [{ productId: 1, name: 'Apple', price: 0.99, quantity: 4 },
  //  { productId: 2, name: 'Banana', price: 0.79, quantity: 2 }]
   
  ShoppingCart.removeItem(2); // Removes all Bananas
   
  console.log(ShoppingCart.getAllItems());
  // [{ productId: 1, name: 'Apple', price: 0.99, quantity: 4 }]
   
  console.log(ShoppingCart.getTotalPrice());
  // 3.96 (0.99 * 4)