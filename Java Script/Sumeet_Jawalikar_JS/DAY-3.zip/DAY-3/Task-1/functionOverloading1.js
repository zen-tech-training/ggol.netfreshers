
function twoArgument(arg1,arg2) {
    return arg1+arg2;
}

function threeArgument(arg1,arg2,arg3) {
    return arg1+arg2+arg3;
}

function fourArgument(arg1,arg2,arg3,arg4) {
    return arg1+arg2+arg3+arg4;
}







function functionOverload() {
    if(arguments.length === 2) {
        return twoArgument(arguments[0],arguments[1]);
    }
    else if(arguments.length === 3) {
        return threeArgument(arguments[0],arguments[1],arguments[2]);
    }
    else if(arguments.length === 4) {
        return fourArgument(arguments[0],arguments[1],arguments[2],arguments[3]);
    }
}


console.log(functionOverload(1,2));
console.log(functionOverload(1,2,3));
console.log(functionOverload(1,2,3,4));