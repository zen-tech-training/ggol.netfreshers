function overloadedFunction() {
  if (arguments.length === 2) {
    if (typeof arguments[0] === "string" && typeof arguments[1] === "string") {
      // Function with two strings
      return handleTwoStrings(arguments[0], arguments[1]);
    } else if (
      typeof arguments[0] === "number" &&
      typeof arguments[1] === "number"
    ) {
      // Function with two numbers
      return handleTwoNumbers(arguments[0], arguments[1]);
    } else if (
      typeof arguments[0] === "string" &&
      typeof arguments[1] === "number"
    ) {
      // Function with one string and one number
      return handleStringAndNumber(arguments[0], arguments[1]);
    } else if (
      typeof arguments[0] === "number" &&
      typeof arguments[1] === "string"
    ) {
      // Function with one number and one string (if needed)
      return handleNumberAndString(arguments[0], arguments[1]);
    }
  } else if (arguments.length === 3) {
    if (
      typeof arguments[0] === "number" &&
      typeof arguments[1] === "number" &&
      typeof arguments[2] === "number"
    ) {
      // Function with three numbers
      return handleThreeNumbers(arguments[0], arguments[1], arguments[2]);
    }
  }
  // Common implementation for all other combinations
  return handleOtherCombinations(arguments);
}

function handleTwoStrings(str1, str2) {
  return `Two strings: ${str1} and ${str2}`;
}

function handleTwoNumbers(num1, num2) {
  return `Two numbers: ${num1} and ${num2}`;
}

function handleThreeNumbers(num1, num2, num3) {
  return `Three numbers: ${num1}, ${num2}, and ${num3}`;
}

function handleStringAndNumber(str, num) {
  return `String and number: ${str} and ${num}`;
}

function handleNumberAndString(num, str) {
  return `Number and string: ${num} and ${str}`;
}

function handleOtherCombinations(args) {
  return `Other combination with ${args.length} arguments: ${Array.from(
    args
  ).join(", ")}`;
}

// Examples
console.log(overloadedFunction("hello", "world")); // Two strings: hello and world
console.log(overloadedFunction(5, 10)); // Two numbers: 5 and 10
console.log(overloadedFunction(1, 2, 3)); // Three numbers: 1, 2, and 3
console.log(overloadedFunction("hello", 10)); // String and number: hello and 10
console.log(overloadedFunction(10, "hello")); // Number and string: 10 and hello
console.log(overloadedFunction(true, 42, "extra")); // Other combination with 3 arguments: true, 42, extra
