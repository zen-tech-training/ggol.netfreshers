// Base / Super Class - Person
function Person(name) {
    this.name = name;
  }
   
  Person.prototype.introduce = function() {
    return `Hi, my name is ${this.name}.`;
  };
   
  // Derived / Sub Class - Developer
  function Developer(name, language) {
    Person.call(this, name); // Call the parent constructor
    this.language = language;
  }
   
  // Inherit from Person
  Developer.prototype = Object.create(Person.prototype);
  Developer.prototype.constructor = Developer;
   
  Developer.prototype.code = function() {
    return `${this.name} is coding in ${this.language}.`;
  };
   
  // Overriding the introduce method
  Developer.prototype.introduce = function() {
    return `Hi, my name is ${this.name}, and I am a developer skilled in ${this.language}.`;
  };
   
  // Creating instances of both classes
  var person = new Person("Alice");
  var developer = new Developer("Bob", "JavaScript");
   
  // Displaying prototypes and __proto__
  // console.log("Person.prototype:", Person.prototype);
  // console.log("person.__proto__:", person.__proto__);
  // console.log("Object.getPrototypeOf(person):", Object.getPrototypeOf(person));
   
  // console.log("Developer.prototype:", Developer.prototype);
  // console.log("developer.__proto__:", developer.__proto__);
  // console.log("Object.getPrototypeOf(developer):", Object.getPrototypeOf(developer));
   
  // Example usage
  console.log(person.introduce()); // Hi, my name is Alice.
  console.log(developer.introduce()); // Hi, my name is Bob, and I am a developer skilled in JavaScript.
  console.log(developer.code()); // Bob is coding in JavaScript.