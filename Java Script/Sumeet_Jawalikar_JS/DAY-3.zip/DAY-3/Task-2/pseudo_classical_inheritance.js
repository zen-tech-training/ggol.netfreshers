// Base / Super Class - Human
function Human(name) {
    this.name = name;
  }
   
  Human.prototype.speak = function() {
    return `${this.name} is speaking.`;
  };
   
  Human.prototype.introduction = function() {
    return `Hi, my name is ${this.name}.`;
  };
   
  // Derived / Sub Class - Student
  function Student(name, college, courses) {
    Human.call(this, name); // Call the parent constructor
    this.college = college;
    this.courses = courses;
  }
   
  // Inherit from Human
  Student.prototype = Object.create(Human.prototype);
  // Student.prototype = new Human(Human.prototype);
  Student.prototype.constructor = Student;
   
  // Override the introduction method
  Student.prototype.introduction = function() {
    return `Hi, my name is ${this.name}. I study at ${this.college} and my courses are ${this.courses.join(", ")}.`;
  };
   
  Student.prototype.takeExams = function() {
    return `${this.name} is taking exams for the courses: ${this.courses.join(", ")}.`;
  };
   
  // Example usage
  const human = new Human("Alice");
  console.log(human.speak()); // Alice is speaking.
  console.log(human.introduction()); // Hi, my name is Alice.
   
  const student = new Student("Bob", "MIT", ["Math", "Physics", "Computer Science"]);
  console.log(student.speak()); // Bob is speaking.
  console.log(student.introduction()); // Hi, my name is Bob. I study at MIT and my courses are Math, Physics, Computer Science.
  console.log(student.takeExams()); // Bob is taking exams for the courses: Math, Physics, Computer Science.