// Base class Vehicle
function Vehicle(make, model) {
    this.make = make;
    this.model = model;
  }
   
  // Derived class Car
  function Car(make, model) {
    Vehicle.call(this, make, model); // Call the parent constructor
    this.wheels = 4;
  }
   
  // Inherit from Vehicle
  Car.prototype = Object.create(Vehicle.prototype);
  Car.prototype.constructor = Car;
   
  // Derived class Bike
  function Bike(make, model) {
    Vehicle.call(this, make, model); // Call the parent constructor
    this.wheels = 2;
  }
   
  // Inherit from Vehicle
  Bike.prototype = Object.create(Vehicle.prototype);
  Bike.prototype.constructor = Bike;
   
  // Instantiate Car and Bike objects
  var car = new Car('Toyota', 'Corolla');
  var bike = new Bike('Yamaha', 'FZ');
   
  // Type checks
  console.log(typeof car); // object
  console.log(typeof bike); // object
   
  // instanceof checks
  console.log(car instanceof Vehicle); // true
  console.log(car instanceof Car); // true
  console.log(car instanceof Bike); // false
   
  console.log(bike instanceof Vehicle); // true
  console.log(bike instanceof Car); // false
  console.log(bike instanceof Bike); // true
   
  // Constructor property checks
  console.log(car.constructor === Car); // true
  console.log(bike.constructor === Bike); // true
   
  // getPrototypeOf checks
  console.log(Object.getPrototypeOf(car) === Car.prototype); // true
  console.log(Object.getPrototypeOf(bike) === Bike.prototype); // true
   
  // Example usage
  console.log(car); // Car { make: 'Toyota', model: 'Corolla', wheels: 4 }
  console.log(bike); // Bike { make: 'Yamaha', model: 'FZ', wheels: 2 }