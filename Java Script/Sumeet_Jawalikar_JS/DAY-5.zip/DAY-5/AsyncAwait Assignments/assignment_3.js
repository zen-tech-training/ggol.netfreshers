async function getUserData() {
    const options = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    };

    try {
        // Wrong Url -> it will through and error
        const response = await fetch('https://jsonplaceholder.ypicode.com/users/1', options);
        if (response.ok) {
            const data = await response.json();
            console.log('User data:', data);
        } else {
            console.error('Error fetching user data:', response.status);
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
}

getUserData();
