async function fetchPosts() {
    const options = {
        method:'GET',
        headers: {
            'Content-Type':'application/json'
        }
    }

    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts',options);
        if(response.ok) {
            const data = await response.json();
            return data;
        }
        else {
            console.log('Error Fetching: '+response.status);
        }
    }
    catch(error) {
        console.log(error);
    }
}


async function fetchComments() {
    const options = {
        method:'GET',
        headers: {
            'Content-Type':'application/json'
        }
    }

    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1',options);
        if(response.ok) {
            const data = await response.json();
            return data;
        }
        else {
            console.log('Error Fetching: '+response.status);
        }
    }
    catch(error) {
        console.log(error);
    }
}


async function fetchAllData() {
    try {
        const posts =  await fetchPosts();
        const comments =  await fetchComments();

        console.log("Posts: ",posts);
        console.log("Comments: ",comments);
    }
    catch(err) {
        console.log(err);
    }
   
}

fetchAllData();