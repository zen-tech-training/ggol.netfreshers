async function fetchPosts() {
    const options = {
        method:'GET',
        headers: {
            'Content-Type':'application/json'
        }
    }

    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts',options);
        if(response.ok) {
            const data = await response.json();
            return data;
        }
        else {
            console.log('Error Fetching: '+response.status);
        }
    }
    catch(error) {
        console.log(error);
    }
}


async function fetchComments() {
    const options = {
        method:'GET',
        headers: {
            'Content-Type':'application/json'
        }
    }

    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1',options);
        if(response.ok) {
            const data = await response.json();
            return data;
        }
        else {
            console.log('Error Fetching: '+response.status);
        }
    }
    catch(error) {
        console.log(error);
    }
}


async function fetchAllData() {
    try {
        const data = await Promise.all([fetchPosts(),fetchComments()]);
        console.log("All Data : ",data);
    }
    catch(err) {
        console.log(err);
    }
   
}

fetchAllData();