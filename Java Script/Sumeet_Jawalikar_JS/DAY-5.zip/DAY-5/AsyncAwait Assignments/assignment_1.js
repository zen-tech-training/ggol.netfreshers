async function fetchData() {
    const data = await new Promise((resolve,reject) => {
        setTimeout(() => resolve("Data Fetched!"),2000);
    })
    console.log(data);
}


fetchData();