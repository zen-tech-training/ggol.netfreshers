async function getUserData() {
  const options = {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  };

  const response = await fetch(
    "https://jsonplaceholder.typicode.com/users/1",
    options
  );
  if (response.ok) {
    const data = await response.json();
    console.log("User data:", data);
  } else {
    console.error("Error fetching user data:", response.status);
  }
}

getUserData();
