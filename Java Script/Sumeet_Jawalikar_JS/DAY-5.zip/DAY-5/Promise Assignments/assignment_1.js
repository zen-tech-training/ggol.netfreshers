function timeOut(time) {
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            resolve("Promise Response "+time);
        },time)
    })
} 

timeOut(2000)
    .then((res) => console.log(res))
    .catch((err) => console.log(err));