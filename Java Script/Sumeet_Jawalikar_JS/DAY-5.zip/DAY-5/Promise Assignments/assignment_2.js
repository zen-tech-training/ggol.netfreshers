function task1() {
    return new Promise((resolve,reject) => {
        setTimeout(() => resolve('Task-1 Completed'),1000);
    }) 
}

function task2() {
    return new Promise((resolve,reject) => {
        setTimeout(() => resolve('Task-2 Completed'),1000);
    }) 
}


function task3() {
    return new Promise((resolve,reject) => {
        setTimeout(() => resolve('Task-3 Completed'),1000);
    }) 
}


task1()
    .then((res) => {
        console.log(res);
        return task2();
    })
    .then((res) => {
        console.log(res);
        return task3();
    })
    .then((res) => {
        console.log(res);
    })
    .catch((err) => console.log(err));
