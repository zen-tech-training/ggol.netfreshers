function taskA() {
    return new Promise((resolve,reject) => {
        setTimeout(() => resolve('Task-A Completed'),1000);
    })
}

function taskB() {
    return new Promise((resolve,reject) => {
        setTimeout(() => resolve('Task-B Completed'),1000);
    })
}

function taskC() {
    return new Promise((resolve,reject) => {
        setTimeout(() => resolve('Task-C Completed'),1000);
    })
}

Promise.all([taskA(),taskB(),taskC()])
    .then((res) => console.log(res))
    .catch((err) => console.log(err));