function errorProneTask() {
    return new Promise((resolve,reject) => {
        const random = (Math.floor(Math.random()*5)+1);
        if(random%2) {
            resolve("Odd Number: Success");
        }
        else {
            reject("Even Number: Failed");
        }
    })
}

errorProneTask()
    .then((res) => console.log(res))
    .catch((err) => console.log(err));