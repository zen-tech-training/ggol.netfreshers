// Array of burger objects
const burgers = [
    { name: 'Burger1', image: './assets/images/burger1.png', name: 'Crispy Creme' },
    { name: 'Burger2', image: './assets/images/burger2.png', name: 'Surprise',},
    { name: 'Burger3', image: './assets/images/burger3.png', name: 'Whopper'},
    { name: 'Burger3', image: './assets/images/burger4.png', name: 'Chilli chesse' },
    { name: 'Burger3', image: './assets/images/burger5.png', name: 'Tandoor Grill' },
];
const burgerList = document.getElementById('burgerList');
class Burger {
    constructor(name, type, price,  quantity, img) {
        this.name = name;
        this.price = price;
        this.type = type;
        this.quantity = quantity;
        this.img = img;
    }
}
const myCart = [];
const prices = {
    Veg:"100",
    Egg:"150",
    Chicken:"200"
}
localStorage.setItem("myBurgersCart", "");
burgers.forEach(burger => {
    // console.log(burger);
    // Create the main burger div
    const burgerDiv = document.createElement('div');
    burgerDiv.className = 'burger';
    burgerDiv.id = 'burger';

    // Create the imgAndName span
    const imgAndNameSpan = document.createElement('span');
    imgAndNameSpan.className = 'imgAndName';

    // Create the imgContainer div
    const imgContainerDiv = document.createElement('div');
    imgContainerDiv.className = 'imgContainer';

    // Create the image element
    const burgerImage = document.createElement('img');
    burgerImage.className = 'burgerImages';
    burgerImage.id = 'burgerImage';
    burgerImage.src = burger.image;
    burgerImage.alt = burger.name;

    // Append the image to the imgContainer
    imgContainerDiv.appendChild(burgerImage);

    // Create the burgerName span
    const burgerNameSpan = document.createElement('span');
    burgerNameSpan.id = 'burgerName';
    burgerNameSpan.textContent = burger.name;
    burgerNameSpan.className = "text-lg"

    // Append imgContainer and burgerName to imgAndName
    imgAndNameSpan.appendChild(imgContainerDiv);
    imgAndNameSpan.appendChild(burgerNameSpan);

    // Create the quantityAndCart div
    const quantityAndCartDiv = document.createElement('div');
    quantityAndCartDiv.className = 'quantityAndCart';

    // Create the quantity input
    const quantityInput = document.createElement('input');
    quantityInput.type = 'number';
    quantityInput.name = 'quantity';
    quantityInput.id = 'quantity';
    // quantityInput.value = undefined;

    // Create the outer section
    const outerSection = document.createElement('section');

    // Create the inner section
    const innerSection = document.createElement('section');
    outerSection.appendChild(innerSection);

    // Create the div
    const div = document.createElement('div');
    innerSection.appendChild(div);

    // Create the select
    const select = document.createElement('select');
    select.name = 'HeadlineAct';
    select.id = 'HeadlineAct';
    select.className = 'mt-1.5 w-full rounded-lg border-gray-300 text-gray-700 text-base';
    div.appendChild(select);

    // Create the options
    const options = ['Veg', 'Egg', 'Chicken'];
    const values = ['Veg', 'Egg', 'Chicken'];
    
    for (let i = 0; i < options.length; i++) {
        const option = document.createElement('option');
        option.value = values[i];
        option.textContent = options[i];
        select.appendChild(option);
    }


    // Create the add to cart button
    const addToCartButton = document.createElement('input');
    addToCartButton.type = 'button';
    addToCartButton.value = 'Add to cart';
    addToCartButton.addEventListener('click', (event) => {
        console.log(quantityInput.value);
        if(quantityInput.value === ''){
            swal("Please add the quantity!!");
        }else{
            let newObject = new Burger(burgerNameSpan.textContent, select.value, prices[select.value], quantityInput.value, burger.image);
            myCart.push(newObject);
            localStorage.setItem("myBurgersCart", JSON.stringify(myCart));
            swal("Item added to cart!!");
        }
    });

    // Append quantity input and button to quantityAndCart
    quantityAndCartDiv.appendChild(quantityInput);
    quantityAndCartDiv.appendChild(addToCartButton);

    // Append imgAndName and quantityAndCart to burgerDiv
    burgerDiv.appendChild(imgAndNameSpan);
    burgerDiv.appendChild(outerSection);
    burgerDiv.appendChild(quantityAndCartDiv);

    // Append the burgerDiv to the body or any other container
    // document.body.appendChild(burgerDiv);
    burgerList.appendChild(burgerDiv);
});

function viewCart(){
    if(localStorage.getItem("myBurgersCart") === ""){
        swal("Please add an item in the cart");
    }else{
        window.location.href = "cart.html";
    }
}
