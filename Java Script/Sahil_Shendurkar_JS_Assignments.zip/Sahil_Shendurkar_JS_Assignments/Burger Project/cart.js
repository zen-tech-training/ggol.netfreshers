let cartItems = JSON.parse(localStorage.getItem("myBurgersCart"));
// console.log(cartItems);
const tbody = document.getElementById("tbody");
const burgerPrices = [];

function renderCartItems() {
    tbody.innerHTML = "";
    cartItems.forEach((cartItem) => {
        const tr = document.createElement('tr');
        for (const [key, value] of Object.entries(cartItem)) {
            if (key === 'img') {
                continue;
            }
            const td = document.createElement('td');
            td.textContent = value;
            tr.appendChild(td);
            if (key === "quantity") {
                let td = document.createElement('td');
                td.textContent = cartItem.price * value;
                burgerPrices.push(cartItem.price * value);
                tr.appendChild(td);
            }
        }

        const td = document.createElement('td');
        const removeButton = document.createElement('button');
        removeButton.innerText = "❌";
        removeButton.className = "removeBtn";
        removeButton.dataset.nameKey = cartItem.name;

        removeButton.addEventListener('click', (event) => {
            let newCartItems = cartItems.filter(item => item.name !== removeButton.dataset.nameKey);
            // console.log(newCartItems);
            localStorage.setItem("myBurgersCart", JSON.stringify(newCartItems));
            // renderCartItems();
            window.location.reload();
        });
        td.appendChild(removeButton);
        tr.appendChild(td);
        tbody.appendChild(tr);
    })
    showTotalPrice();

}
renderCartItems();
function showTotalPrice() {
    const finalCalSpan = document.getElementById("totalMessage");

    const finalCalculation = document.getElementById("finalCalculation");
    const button = document.createElement('button');
    button.className = "placeOrder";
    button.innerText = "Place order";

    const totalPrice = burgerPrices.reduce((acc, curr) => {
        return acc + curr
    }, 0)

    let discountedPrice = 0;

    button.style.display = 'none';
    finalCalculation.appendChild(button);


    if (totalPrice >= 500 && totalPrice < 1000 && burgerPrices.length !== 0) {

        discountedPrice = totalPrice - (totalPrice * 0.05);
        finalCalSpan.innerHTML = `Total quantity is <b>${burgerPrices.length}</b> and total price is <b>${totalPrice}</b> you will get <b>5%</b> discount &
        Total price after discount is <b>${discountedPrice}</b>`

        button.style.display = 'block';
        button.addEventListener('click', handlePlaceOrder);

    } else if (totalPrice >= 1000 && burgerPrices.length !== 0) {
        discountedPrice = totalPrice - (totalPrice * 10);
        finalCalSpan.innerHTML = `Total quantity is <b>${burgerPrices.length}</b> and total price is <b>${totalPrice}</b> you will get <b>10%</b> discount &
        Total price after discount is ${discountedPrice}`

        button.style.display = 'block';
        button.addEventListener('click', handlePlaceOrder);
    }
    else if (burgerPrices.length !== 0) {
        finalCalSpan.innerHTML = `Total quantity is <b>${burgerPrices.length}</b> and total price is <b>${totalPrice}</b>`;
        button.style.display = 'block';

        button.addEventListener('click', handlePlaceOrder);
    }

}
function handlePlaceOrder() {
    const orderConfirmation = confirm("Do you want to confirm the order");
    if (orderConfirmation) {
        var audio = new Audio('./assets/sounds/zomato_sms.mp3');
        audio.play();
        swal({
            icon: "success",
        });
        setTimeout(()=>{
            window.location.href = "thanks.html"
        }, 3000)
    }      

}