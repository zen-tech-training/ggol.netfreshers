const todoInput = document.getElementById('todoInput');
const addTodoButton = document.getElementById('addTodoButton');
const todoList = document.getElementById('todoList');

let todos = [];

function showTodos() {
    todoList.innerHTML = '';

    todos.forEach((todo, index) => {
        const todoItem = document.createElement('li');
        todoItem.innerHTML = `<span>${todo}</span>
            <button class="removeButton" data-index=${index}>Remove</button>
        `
        todoList.appendChild(todoItem);
    })

    const removeButtons = document.getElementsByClassName('removeButton');
    Array.from(removeButtons).forEach(button => {
        button.addEventListener('click', function () {
            const idx = this.getAttribute('data-index');
            removeTodo(idx);
        });
    });
}

function addTodo(){
    const todoText = todoInput.value.trim();
    if(todoText !== ''){
        todos.push(todoText);
        todoInput.value = '';
        showTodos();
    }
}

function removeTodo(index){
    todos.splice(index, 1);
    showTodos();
}

addTodoButton.addEventListener('click', addTodo);

showTodos();