function $(id) {
    return document.getElementById(id);
}
// 1
function changeText() {
    $("text").innerText = "The Text is now changed";
}

// 2 & 3
function getCount() {
    return $("myList").childNodes.length + 1;
}
let ulListItem = []
let ulList = $("myList");
let ulListChildNodes = $("myList").childNodes;
for (let val of ulListChildNodes) {
    if (val.nodeName !== "#text") {
        ulListItem.push(val);
    }
}
function addListItem() {
    console.log(ulList.childNodes);
    let li = document.createElement('li');
    li.innerText = "Item " + getCount();
    ulListItem.push(li);
    ulList.innerHTML = "";
    ulListItem.forEach((item) => {
        ulList.appendChild(item);
    })
}

function removeListItem() {
    ulList.innerHTML = ""
    ulListItem.pop();
    ulListItem.forEach((item) => {
        ulList.appendChild(item);
    });
}

// 4
function changeColor() {
    $("colorBox").style.backgroundColor = "red";
}

// 5
$("myForm").addEventListener('click', function validateForm(e) {
    e.preventDefault();
    let email = $("email").value;
    console.log(email);
})

// 6
let toggleDiv = $("toggleDiv");
function toggleVisibility() {
    if (toggleDiv.classList.contains("show")) {
        toggleDiv.classList.remove("show");
        toggleDiv.classList.add("hide");
    } else {
        toggleDiv.classList.remove("hide");
        toggleDiv.classList.add("show");
    }
}

//7
// function changeImage(){
//     var img = document.getElementById('myImage');
//     img.src = ;
// }

// 8
$('hoverDiv').addEventListener('mouseover', (e) => {
    $('hoverText').innerHTML = "Mouse is over box";
})
$('hoverDiv').addEventListener('mouseleave', (e) => {
    $('hoverText').innerHTML = "Mouse is out of box";
})

// 9
function openModal() {
    document.getElementById('myModal').style.display = 'block';
}
function closeModal() {
    document.getElementById('myModal').style.display = 'none';
}

// 10
let newDiv = document.createElement('div');
newDiv.textContent = 'Hello, World!';
document.body.appendChild(newDiv);

// 11
function changeBackgroundColor() {
    const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16);
    document.body.style.backgroundColor = randomColor;
}

// 12
function toggleHighlight() {
    const inputField = document.getElementById('inputField');
    inputField.classList.toggle('highlight');
}

// 13
let itemCount = 0;
function addItem() {
    itemCount++;
    let newItem = document.createElement('li');
    newItem.textContent = `Item ${itemCount}`;
    document.getElementById('itemList').appendChild(newItem);
}

// 14
let table = document.getElementById('numberTable');
let counter = 1;
for (let i = 0; i < 3; i++) {
    let row = document.createElement('tr');
    for (let j = 0; j < 3; j++) {
        let cell = document.createElement('td');
        cell.textContent = counter++;
        row.appendChild(cell);
    }
    table.appendChild(row);
}

// 15
function cloneParagraph() {
    let originalParagraph = document.getElementById('originalParagraph');
    let clone = originalParagraph.cloneNode(true);
    clone.textContent = 'This is the cloned paragraph.';
    document.body.appendChild(clone);
}