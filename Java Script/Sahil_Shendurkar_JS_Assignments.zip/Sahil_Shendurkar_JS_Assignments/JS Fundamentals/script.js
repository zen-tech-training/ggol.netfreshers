let o1 = document.getElementById("o1");
function reverseString(str){
    let revString = '';
    for(let i=str.length-1;i>=0;i--){
        revString += str[i];
    }
    return revString;
}
o1.innerText = reverseString("string");;


let o2 = document.getElementById("o2");
let array = [2, 15, 29, 7, 2 ,11];
let arrayElement = document.getElementById("array").innerText= array + "";
let prevLar = Number.MIN_VALUE;
for(let i=0;i<=array.length-1;i++){
    prevLar = Math.max(array[i], prevLar);
}
o2.innerText=prevLar;

let o3 = document.getElementById("o3");
let str2 = "nitin";
let reversedString = reverseString(str2);
if (reversedString===str2) {
    o3.innerText="Yes";
} else {
    o3.innerText="No";
}

let o4 = document.getElementById("o4");
let persons = [
    {
        name:'John',
        age: 21
    },
    {
        name:'Josh',
        age: 18
    },
    {
        name:'Jim',
        age:20
    }
]
// let filteredPersons = [];
// for(let person of persons){
//     if(person.age>18){
//         filteredPersons.push(JSON.stringify(person));
//     }
// }
let filteredPersons = persons.filter(p => p > 15)
o4.innerText = filteredPersons;

let o5 = document.getElementById("o5");
let array2 = [2, 4, 6, 8, 10];
let sum=0;
for(let i=0;i<array2.length;i++){
    sum+=array2[i];
}
o5.innerText = sum;

let o6 = document.getElementById("o6");
let array3 = [2, 2, 6, 8, 8, 8, 10];
let newArray = [];
for(let i=0;i<array3.length;i++){
    if(newArray.indexOf(array3[i])===-1){
        newArray.push(array3[i]);
    }else{
        continue;
    }
}
o6.innerText = newArray;

let o7 = document.getElementById("o7");
let array4 = [1, [2, 3], [4, [5, 6]]];
o7.innerText = array4.flat(Infinity);

let o8 = document.getElementById("o8");
let a1 = [1, 2, 3, 4]
let a2 = [3, 4, 5, 6]
let intersection = []
for (let i = 0; i < a1.length; i++) {
    if(a2.indexOf(a1[i])!==-1){
        intersection.push(a1[i]);
    }
}
o8.innerText=intersection;

let o9 = document.getElementById("o9");
function objectToArray(objs){
    var result = [];
    for(let obj of objs){
        for(var key in obj){
            if(obj.hasOwnProperty(key)){
                result.push([key, obj[key]]);
            }
        }
    }
    return result;
}
let objs = [
        {
            name: "Audi",
            color: "White"
        },
        {
            name: "BMW",
            color: "Black"
        }
]
o9.innerHTML = objectToArray(objs);

let o10 = document.getElementById("o10");
function sortArrayByProperty(arr, prop){
    return arr.sort((a, b)=>{
        if(a[prop] > b[prop]){
            return 1;
        }else if(a[prop] < b[prop]){
            return -1;
        }else{
            return 0;
        }
    })
}
var students = [
    {
        name:'John',
        age: 21
    },
    {
        name:'Josh',
        age: 18
    },
    {
        name:'Jim',
        age: 20
    }
]
o10.innerHTML = JSON.stringify(sortArrayByProperty(students, 'age'));