async function fetchData(){
    await new Promise(resolve => setTimeout(resolve, 200));
    console.log('Data is fetched!!');
}
fetchData();

//same for 2 and 3
async function getUserData(){
    try {
        const res = await fetch('https://jsonplaceholder.typicode.com/users/1');
        const userData = await res.json();
        console.log('User Data: ', userData);
    } catch (error) {
        console.log('Error fetching user data.', error);
    }
}
// getUserData();

async function fetchPosts(){
    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
    const posts = await response.json();
    return posts;
}

async function fetchComments(){
    const response = await fetch('https://jsonplaceholder.typicode.com/comments?postId=1');
    const comments = await response.json();
    return comments;
}

async function fetchAllData(){

    try {
        const postPromise = fetchPosts();
        const commentsPromise = fetchComments();

        const [posts, comments] = await Promise.all([postPromise, commentsPromise]);
        console.log('Posts: ', posts);
        console.log('Comments: ',comments);

    } catch (error) {
        console.log('Error: ', error);        
    }
}
// fetchAllData();

async function fetchAllData_P(){

    try {
        const [posts, comments] = await Promise.all([fetchPosts(), fetchComments()]);
        console.log('Posts: ', posts);
        console.log('Comments: ',comments);

    } catch (error) {
        console.log('Error: ', error);        
    }
}
// fetchAllData_P();