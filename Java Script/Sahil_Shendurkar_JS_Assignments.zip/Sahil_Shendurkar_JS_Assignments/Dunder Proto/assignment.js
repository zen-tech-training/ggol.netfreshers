// 1
function Human(name) {
    this.name = name;
}
Human.prototype.speak = function () {
    console.log(`${this.name} is speaking.`);
}
Human.prototype.intro = function () {
    console.log(`Hi, I am ${this.name}`);
}

function Student(name, college, courses) {
    Human.call(this, name);
    this.college = college;
    this.courses = courses;
}

Student.prototype = Object.create(Human.prototype);
Object.setPrototypeOf(Student, Human);

Student.prototype.intro = function () {
    console.log(`Hi, I am ${this.name} I love to play games`);
}
Student.prototype.takeExams = function () {
    console.log(`${this.name} is giving exams of ${this.courses}`);
}

let s1 = new Student("Sahil", "VIT", ["CS", "Java"]);
// s1.intro();
// s1.takeExams();

// 2
function Person(name, age) {
    this.name = name;
    this.age = age;
}

Person.prototype.greet = function () {
    console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
}

function Developer(name, age, language) {
    Person.call(this, name, age); //Call the constructor of the superclass
    this.language = language;
}

Developer.prototype = Object.create(Person.prototype);
Developer.prototype.constructor = Developer;

Developer.prototype.code = function () {
    console.log(`${this.name} is coding in ${this.language}.`);
}

const person = new Person("Alice", 30);
const developer = new Developer("Bob", 25, "JavaScript");

// console.log('Person prototype: ' + Person.prototype);
// console.log('Developer prototype: ' + Developer.prototype);

// console.log('Person __proto__: ' + Object.getPrototypeOf(person));
// console.log('Developer __proto__: ' + Object.getPrototypeOf(developer));

// console.log('Person Object.getPrototypeOf: ' + Object.getPrototypeOf(person));
// console.log('Developer Object.getPrototypeOf: ' + Object.getPrototypeOf(developer));

// // Display the hierarchy
// console.log('Developer prototype.__proto__: ' + Developer.prototype.__proto_);
// console.log('Developer Object.prototype: ' + Object.getPrototypeOf(Developer.prototype));

// person.greet();
// developer.greet();
// developer.code();

// Module Pattern
const shopCart = (function () {

    this.productList = [];

    function finCartItemById(productId) {
        return productList.find((item) => {
            return item.productId === productId;
        });
    }

    return {
        addItem: function (productId, name, price, quantity) {
            let existingItem = finCartItemById(productId);
            if (existingItem) {
                existingItem.quantity += existingItem;
            } else {
                productList.push({
                    productId: productId,
                    name: name,
                    price: price,
                    quantity: quantity
                });
            }
        },
        removeItem: function (productId) {
            productList = productList.filter(function (item) {
                return item.productId !== productId;
            })
        },
        getAllItems: function () {
            productList.forEach(product => {
                console.log(`Product_id: ${product.productId} Product_name: ${product.name} Product_price: ${product.price} Product_quantity: ${product.quantity}
                    `);
            });
        },
        getTotalPrice: function () {
            let totalPrice = productList.reduce((acc, item) => {
                return acc + (item.price * item.quantity);
            }, 0)
            return totalPrice;
        }
    }
})();
// shopCart.addItem(1, "Product A", 10.00, 2);
// shopCart.addItem(2, "Product B", 5.00, 1);
// shopCart.getAllItems();
// console.log("Total price:" + shopCart.getTotalPrice());

// Runtime information
function Vehicle(make, model){
    this.make = make;
    this.model = model;
}
function Car(make, model){
    Vehicle.call(this, make, model);
    this.wheels = 4;
}
Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car;

function Bike(make, model){
    Vehicle.call(this, make, model);
    this.wheels = 2;
}
Bike.prototype = Object.create(Vehicle.prototype);
Bike.prototype.constructor = Bike;

let carObj = new Car('Audi', 'R8');
let bikeObj = new Bike('Yamaha', 'FZ');

console.log(typeof carObj);
console.log(typeof bikeObj);

console.log(carObj instanceof Vehicle);
console.log(carObj instanceof Car);
console.log(carObj instanceof Bike);

console.log(bikeObj instanceof Vehicle);
console.log(bikeObj instanceof Car);
console.log(bikeObj instanceof Bike);

console.log(carObj.constructor === Car);
console.log(bikeObj.constructor === Bike);

console.log(Object.getPrototypeOf(carObj) === Car.prototype);
console.log(Object.getPrototypeOf(bikeObj) === Bike.prototype);