// Write a function that returns a promise which resolves after a specified time with a success message.
// function wait(ms){
//     const myPromise = new Promise((resolve, reject)=>{
//         setTimeout(()=>{
//             resolve(`Completed after ${ms} milliseconds`);
//         }, ms);
//     })

//     return myPromise;
// }
// wait(2000)
// .then((response)=>{
//     console.log(response);
// })
// .catch((err)=>{
//     console.log(err);
// })

// Create a series of functions that return promises and chain them together to perform a sequence of async operations
// const task1 = function (ms) {
//     return new Promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve("Task 1 complete.");
//         }, ms)
//     })
// }

// const task2 = function(ms){
//     return new Promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve("Task 2 complete.");
//         }, ms)
//     })
// }

// const task3 = function(ms){
//     return new Promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve("Task 3 complete.");
//         }, ms)
//     })
// }

// task1(1000)
// .then((response)=>{
//     console.log(response);
//     return task2(2000);
// })
// .then((response)=>{
//     console.log(response);
//     return task3(4000);
// })
// .then((response)=>{
//     console.log(response);
// })
// .catch((err)=>{
//     console.log(err);
// })

// Write a promise that simulates an error condition and handle it using `catch()
// const myPromise = new Promise((resolve, reject)=>{
//     let success = false;
//     if(success){
//         resolve("Success in promise");
//     }else{
//         reject("Failure in promise");
//     }
// })

// myPromise
// .then((response)=>{
//     console.log(response);
// }).catch((err)=>{
//     console.log(err);
// })

// Create multiple promises and use `Promise.all()` to wait for all of them to complete.
// function taskA(){
//     return new Promise(resolve =>{
//         setTimeout(()=>{
//             resolve('Task A is complete');
//         }, 2000);
//     })
// }

// function taskB(){
//     return new Promise(resolve =>{
//         setTimeout(()=>{
//             resolve('Task B is complete');
//         }, 3000);
//     })
// }

// function taskC(){
//     return new Promise(resolve =>{
//         setTimeout(()=>{
//             resolve('Task C is complete');
//         }, 1500);
//     })
// }
// Promise.all([taskA(), taskB(), taskC()])
// .then(results =>{
//     console.log('All task are completed');
//     console.log(results);
// })
// .catch(err=>{
//     console.log(err);
// })