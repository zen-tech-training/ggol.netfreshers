
document.addEventListener('DOMContentLoaded', () => {
    const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
    const cartTable = document.getElementById('cart-items');
    let totalAmount = 0;
    let discountedPrice = 0;

    cartItems.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <th scope="col"><img src="${item.icon}" alt="${item.name} Icon" width="50"></th>
            <td>${item.name}</td>
            <td>${item.quantity}</td>
            <td>${item.price}</td>
            <td>${(item.price) * (item.quantity)}</td>
            <td><button type="button" class="btn btn-danger" name="removeButton" class="remButton btn-block">x</button></td>
        `;
        cartTable.appendChild(row);
        totalAmount += item.quantity * item.price;

        if (totalAmount > 500 && totalAmount < 1000) {
            discountedPrice = 0.95 * totalAmount;
        } 
        else if (totalAmount >= 1000) {
            discountedPrice = 0.90 * totalAmount;
        } 
        else {
            discountedPrice = totalAmount;
        }

        document.getElementById('total-amount').textContent = totalAmount;
        document.getElementById('final-price').textContent = discountedPrice;
    });
});
document.getElementById('checkOut').onclick = function () {
    localStorage.clear();
    window.location.href = "./index.html"
}

document.getElementById('cart-items').addEventListener('click', function(event) {
    if (event.target.name === 'removeButton') {
        const row = event.target.closest('tr');
        console.log(row)
        const itemPrice = parseFloat(row.querySelector('td:nth-child(4)').textContent);
        const itemQuantity = parseInt(row.querySelector('td:nth-child(3)').textContent);
        const itemName = (row.querySelector('td:nth-child(2)').textContent);

        const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
        const updatedCartItems = cartItems.filter(item => item.name !== itemName);
        localStorage.setItem('cart', JSON.stringify(updatedCartItems));

        totalAmount = parseFloat(document.getElementById('total-amount').textContent);
        discountedPrice = parseFloat(document.getElementById('final-price').textContent);
        totalAmount -= itemPrice * itemQuantity;
        console.log(totalAmount, discountedPrice)
        document.getElementById('total-amount').textContent = totalAmount;
        if (totalAmount > 500 && totalAmount < 1000) {
            discountedPrice = 0.95 * totalAmount;
        } 
        else if (totalAmount >= 1000) {
            discountedPrice = 0.90 * totalAmount;
        } 
        else {
            discountedPrice = totalAmount;
        }
        
        document.getElementById('final-price').textContent = discountedPrice;

        row.remove();
        
    }
});

