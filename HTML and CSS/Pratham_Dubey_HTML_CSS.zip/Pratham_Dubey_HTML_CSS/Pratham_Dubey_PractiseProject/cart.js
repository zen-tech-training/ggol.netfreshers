let cart = [];
 
function addcart(name, price, icon) {
    const quantity = event.target.nextElementSibling.value;
    const type = event.target.nextElementSibling.id;
    price = parseInt(price)
    if (quantity && quantity > 0) {
        cart.push({ name, price,  icon, type, quantity });
        alert(`${name} added to cart!`);
        localStorage.setItem('cart', JSON.stringify(cart));
    } else {
        alert('Please enter a valid quantity.');
    }
}

document.getElementById('cartButton').onclick = function(){
    window.location.href = "/cart.html"
}

