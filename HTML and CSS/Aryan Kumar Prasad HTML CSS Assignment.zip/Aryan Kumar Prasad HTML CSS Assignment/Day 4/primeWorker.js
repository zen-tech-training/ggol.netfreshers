
self.onmessage = function (event) {
  const limit = event.data;
  let primeCount = 0;

  for (let num = 2; num <= limit; num++) {
      if (isPrime(num)) {
          primeCount++;
      }
  }

  self.postMessage(primeCount);
};

function isPrime(num) {
  for (let i = 2; i <= Math.sqrt(num); i++) {
      if (num % i === 0) {
          return false;
      }
  }
  return num > 1; // 0 and 1 are not prime numbers
}