const burgerCategorySelect = document.getElementById("burgerCategory");
const burgerTypeSelect = document.getElementById("burgerType");
const quantityInput = document.getElementById("quantity");

const cartItems = [];

function addToCart() {
  const category = burgerCategorySelect.value;
  const type = burgerTypeSelect.value;
  const quantity = parseInt(quantityInput.value);
  const price = getPriceByCategory(category);

  const cartItem = {
    name: type,
    category,
    quantity,
    price,
  };

  cartItems.push(cartItem);
  console.log("Added to cart:", cartItem);
}

function getPriceByCategory(category) {
  switch (category) {
    case "Veg":
      return 100;
    case "Egg":
      return 150;
    case "Chicken":
      return 200;
    default:
      return 0;
  }
}

document.getElementById("bt").addEventListener("click", function () {
  window.location.href = "CartPage.html";
});
