
function bigLoop(){
    var no=0;
    for(var i=0;i<1000000000;i++){
        no = i;
    }
    alert(no+' iterations completed!');
}