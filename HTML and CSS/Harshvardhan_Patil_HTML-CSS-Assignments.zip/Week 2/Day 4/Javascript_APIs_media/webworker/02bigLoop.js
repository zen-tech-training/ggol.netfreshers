
var no=0;

function bigLoop(){
    
    for(var i=0;i<1000000000;i++){
        no = i;
    }
}

bigLoop();

// Communication should happen from this to main thread
postMessage(no);