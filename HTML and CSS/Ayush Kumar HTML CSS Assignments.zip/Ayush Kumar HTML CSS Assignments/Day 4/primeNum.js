// Function to check if a number is prime
function isPrime(num) {
  if (num <= 1) return false;
  for (let i = 2; i <= Math.sqrt(num); i++) {
    if (num % i === 0) return false;
  }
  return true;
}

// Function to find prime numbers less than a given input
function findPrimes(limit) {
  const primes = [];
  for (let i = 2; i < limit; i++) {
    if (isPrime(i)) {
      primes.push(i);
    }
  }
  return primes;
}

// Listen for messages from the main thread
self.addEventListener("message", (event) => {
  const inputNumber = parseInt(event.data);
  const primeNumbers = findPrimes(inputNumber);
  self.postMessage(primeNumbers);
});
