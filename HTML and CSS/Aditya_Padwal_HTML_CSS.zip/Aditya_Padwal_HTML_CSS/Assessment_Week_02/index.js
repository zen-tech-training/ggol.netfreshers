const input = document.getElementById(`input-number`);
const button = document.getElementById(`submit-button`);

function validateInputForm() {
    // getting input element
    const numberInput = document.getElementById('input-number');

    // trimming the input value
    const mobileNumber = numberInput.value.trim();
    
    // checking if the input is empty
    if (mobileNumber === '') {
        alert('Please enter your mobile number.');
        return false;
    }
    
    // checking if the input is a 10-digit number
    const mobileNumberPattern = /^\d{10}$/;
    if (!mobileNumberPattern.test(mobileNumber)) {
        alert('Please enter a valid 10-digit mobile number.');
        numberInput.value = '';
        return false;
    }
    
    alert('Mobile number is valid. Redirecting to burgers page...');
    window.location.href = './burgers.html'; // Redirect to the /burgers page
    return true;
}

// Event listener for adding an item to shopping cart
button.addEventListener('click', validateInputForm);

// Event listener for pressing the enter key
input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        validateInputForm();
    }
});

// Focus on input field on page load
document.addEventListener('DOMContentLoaded', function () {
    input.focus();
});