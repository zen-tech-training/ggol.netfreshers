const table = document.getElementById(`table-body`);
const totalQuantityLabel = document.getElementById(`total-quantity`);
const totalPriceLabel = document.getElementById(`total-price`);
const discountLabel = document.getElementById(`discount`);
const finalPriceLabel = document.getElementById(`final-price`);
const placeOrderButton = document.getElementById(`submit-button`);

let totalQuantity = 0;
let totalPrice = 0;
let discountedPrice = 0;

function getCartProductsFromLocalStorage() {
    var cart = JSON.parse(localStorage.getItem(`cart`)) || [];

    cart.forEach((product) => {
        var row = document.createElement(`tr`);

        var burgerType = document.createElement(`td`);
        burgerType.textContent = product[`type`];

        var burgerCategory = document.createElement(`td`);
        burgerCategory.textContent = product[`category`];

        var priceCell = document.createElement(`td`);
        priceCell.textContent = product[`price`];

        var quantityCell = document.createElement(`td`);
        quantityCell.textContent = product[`quantity`];

        var totalPriceCell = document.createElement(`td`);
        totalPriceCell.textContent = product[`price`] * product[`quantity`];

        var removeCell = document.createElement(`td`);
        var removeButton = document.createElement(`p`);
        removeButton.textContent = "❌";
        removeButton.classList.add(`removeButton`);
        removeButton.addEventListener("click", () => {
            removeFromCart(product);
        });
        removeCell.appendChild(removeButton);

        row.appendChild(burgerType);
        row.appendChild(burgerCategory);
        row.appendChild(priceCell);
        row.appendChild(quantityCell);
        row.appendChild(totalPriceCell);
        row.appendChild(removeCell);

        table.appendChild(row);

        totalQuantity += product[`quantity`];
        totalPrice += product[`price`] * product[`quantity`];
    });

    updateTotals();
}

function removeFromCart(product) {
    var cart = JSON.parse(localStorage.getItem(`cart`)) || [];
    var updatedCart = cart.filter((item) => {
        return ((item.type !== product.type) || (item.category !== product.category));
    });
    localStorage.setItem(`cart`, JSON.stringify(updatedCart));
    location.reload();
}

function updateTotals() {
    totalQuantityLabel.textContent = totalQuantity;
    totalPriceLabel.textContent = totalPrice;

    if (totalPrice >= 500 && totalPrice < 1000) {
        discountLabel.textContent = "5%";
        discountedPrice = totalPrice * 0.95;
    } else if (totalPrice >= 1000) {
        discountLabel.textContent = "10%";
        discountedPrice = totalPrice * 0.9;
    } else {
        discountLabel.textContent = "0%";
        discountedPrice = totalPrice;
    }

    finalPriceLabel.textContent = discountedPrice.toFixed(2);
}

placeOrderButton.addEventListener("click", () => {
    if(totalPrice === 0){
        alert(`You do not any items to proceed :)`);
        return false;
    }

    alert(`Total Quantity is ${totalQuantity} and Total Price is ${totalPrice}. You will get ${discountLabel.textContent} discount. Total Price after Discount is Rs. ${discountedPrice.toFixed(2)}/-`);
    localStorage.removeItem(`cart`);
    location.reload();
});

getCartProductsFromLocalStorage();