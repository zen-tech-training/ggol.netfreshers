const submitButton = document.getElementById(`submit-button`);

// cart product structure
class Burger {
    constructor(type, category, quantity, price) {
        this.type = type;
        this.category = category;
        this.quantity = quantity;
        this.price = price;
    }
}

// adding products to cart
function addToCart(type, categoryId, quantityId) {
    const category = document.getElementById(categoryId).value;
    const quantity = parseInt(document.getElementById(quantityId).value);
    if(quantity > 5) {
        alert(`Sorry, you cannot buy more than 5 burgers!`);
        return false;
    }
    let price;

    switch (category) {
        case 'Veg':
            price = 100;
            break;
        case 'Egg':
            price = 150;
            break;
        case 'Chicken':
            price = 200;
            break;
    }

    const burger = new Burger(type, category, quantity, price * quantity);
    pushCartToLocalStorage(burger);
}

// updating cart products in local storage
function pushCartToLocalStorage(burger) {
    var cart = JSON.parse(localStorage.getItem(`cart`)) || [];

    var existingItem = cart.find((item) => (item.type === burger.type) && (item.category === burger.category));
    if(existingItem) {
        existingItem.quantity += burger.quantity;
    } else {
        cart.push(burger);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`Added ${burger.quantity} ${burger.category} ${burger.type} in cart`);
}

submitButton.addEventListener(`click`, redirectToCheckoutPage);

function redirectToCheckoutPage() {
    alert(`Redirecting to the checkout page...`);
    window.location.href = './checkout.html'; // Redirect to the /burgers page
}
