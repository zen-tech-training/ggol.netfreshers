// main.js
const worker = new Worker("webWorker.js");

worker.onmessage = function (event) {
  const primeCount = event.data;
  console.log(`Found ${primeCount} prime numbers up to the limit.`);
};

const limitInput = document.getElementById("limit");
const calculateButton = document.getElementById("calculate");

calculateButton.addEventListener("click", () => {
  const limit = parseInt(limitInput.value);
  worker.postMessage(limit);
});
