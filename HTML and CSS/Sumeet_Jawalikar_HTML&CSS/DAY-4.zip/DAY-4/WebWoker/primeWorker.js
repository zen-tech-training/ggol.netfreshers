// // prime-worker.js
// self.onmessage = function(event) {
//     const limit = event.data;
//     const primeCount = countPrimes(limit);
//     self.postMessage(primeCount);
//   };

//   function countPrimes(limit) {
//     let count = 0;
//     for (let i = 2; i <= limit; i++) {
//       if (isPrime(i)) {
//         count++;
//       }
//     }
//     return count;
//   }

//   function isPrime(num) {
//     if (num < 2) return false;
//     for (let i = 2; i <= Math.sqrt(num); i++) {
//       if (num % i === 0) {
//         return false;
//       }
//     }
//     return true;
//   }

// New Code

// primeWorker.js

// Function to check if a number is prime
function isPrime(num) {
  if (num <= 1) return false;
  for (let i = 2; i * i <= num; i++) {
    if (num % i === 0) return false;
  }
  return true;
}

// Web Worker logic
self.onmessage = function (e) {
  const limit = e.data; // Get the limit from the main thread

  let primeCount = 0;
  for (let i = 2; i <= limit; i++) {
    if (isPrime(i)) {
      primeCount++;
    }
  }

  // Send the result back to the main thread
  self.postMessage(primeCount);
};
