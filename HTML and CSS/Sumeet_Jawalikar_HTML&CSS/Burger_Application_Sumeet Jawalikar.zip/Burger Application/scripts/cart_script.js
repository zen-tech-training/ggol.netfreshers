
const cartData = JSON.parse(localStorage.getItem("cartData"));

function addRow() {
  const tableBody = document.querySelector("table tbody");
  for (const key in cartData) {
    console.log(cartData[key]);
    const row = document.createElement("tr");
    const burgerType = document.createElement("td");
    const burgerCategory = document.createElement("td");
    const burgerPrice = document.createElement("td");
    const burgerQuantity = document.createElement("td");
    const burgerTotalPrice = document.createElement("td");
    const burgerRemove = document.createElement("td");
    const removeButton = document.createElement("button");
    burgerType.textContent = cartData[key].type;
    burgerCategory.textContent = cartData[key].category;
    burgerQuantity.textContent = cartData[key].quantity;
    burgerPrice.textContent = cartData[key].price;
    burgerTotalPrice.textContent = cartData[key].price * cartData[key].quantity;
    removeButton.textContent = "❌";
    removeButton.addEventListener("click", () => removeItem(key));
    burgerRemove.appendChild(removeButton);
    row.appendChild(burgerType);
    row.appendChild(burgerCategory);
    row.appendChild(burgerPrice);
    row.appendChild(burgerQuantity);
    row.appendChild(burgerTotalPrice);
    row.appendChild(burgerRemove);
    tableBody.appendChild(row);
  }
}

function removeItem(index) {
  cartData.splice(index, 1);
  localStorage.setItem("cartData", JSON.stringify(cartData));
  updateTable();
}

function updateTable() {
  const tableBody = document.querySelector("table tbody");
  tableBody.innerHTML = "";
  addRow();
}

addRow();

const placeOrder = document.getElementById("placeOrder");

placeOrder.addEventListener("click", function () {
  const content = document.getElementById("content");
  const para = document.createElement("p");
  if (cartData.length === 0) {
    para.textContent =
      "Your cart is empty. Please add items to your cart before placing an order.";
    content.appendChild(para);
    return;
  }
  let overAllCost = 0;
  let totalQuantity = 0;
  for (const key in cartData) {
    console.log(cartData[key]);
    totalQuantity += cartData[key].quantity;
    overAllCost += cartData[key].price * cartData[key].quantity;
  }
  let discount = 0;
  if (overAllCost >= 500 && overAllCost < 1000) {
    discount = overAllCost * 0.05;
    const discountTotal = overAllCost-discount;
    para.innerHTML = `Total Quantity is <strong>${totalQuantity}</strong> and Total Price is <strong>Rs. ${overAllCost}</strong> you will get <strong>5%</strong> discount & 
  Total Price after Discount is <strong>Rs. ${discountTotal}</strong>`;
  } else if (overAllCost >= 1000) {
    discount = overAllCost * 0.1;
    const discountTotal = overAllCost-discount;
    para.innerHTML = `Total Quantity is <strong>${totalQuantity}</strong> and Total Price is <strong>Rs. ${overAllCost}</strong> you will get <strong>10%</strong> discount & 
  Total Price after Discount is <strong>Rs. ${discountTotal}</strong>`;
  } else {
    para.innerHTML = `Total Quantity is <strong>${totalQuantity}</strong> and Total Price is <strong>Rs. ${overAllCost}</strong>`;
  }
  content.appendChild(para);
});
