// JavaScript Magic Starts Here

function updatePrice(selectId, priceId) {
  var category = document.getElementById(selectId).value;
  var priceElement = document.getElementById(priceId);

  // Update the price based on the selected category
  switch (category) {
    case "Veg":
      priceElement.innerHTML = "Rs 100";
      break;
    case "Non-veg":
      priceElement.innerHTML = "Rs 200";
      break;
    case "Egg":
      priceElement.innerHTML = "Rs 150";
      break;
    default:
      priceElement.innerHTML = "Rs 0";
  }
}

// Event listeners for the category selects
document.getElementById("categories1").addEventListener("change", function() {
  updatePrice("categories1", "price1");
});

document.getElementById("categories2").addEventListener("change", function() {
  updatePrice("categories2", "price2");
});

document.getElementById("categories3").addEventListener("change", function() {
  updatePrice("categories3", "price3");
});

document.getElementById("categories4").addEventListener("change", function() {
  updatePrice("categories4", "price4");
});

document.getElementById("categories5").addEventListener("change", function() {
  updatePrice("categories5", "price5");
});

class BurgerCartItem {
  constructor(type, category, quantity, price) {
    this.type = type;
    this.category = category;
    this.quantity = quantity;
    this.price = price;
  }
}

const cartItems = [];

const btnAdd = document.querySelectorAll('.btnAdd');
const btnViewCart = document.getElementById("btnViewCart");



btnAdd.forEach(btn => {
  btn.addEventListener('click', function() {
    const row = this.closest('.row');
    const priceElement = row.querySelector('#price1, #price2,#price3,#price4,#price5');
    const quantityInput = row.querySelector('#qnumber1, #qnumber2,#qnumber3,#qnumber4,#qnumber5');
    const categorySelect = row.querySelector('#categories1, #categories2,#categories3,#categories4,#categories5');
    const nameElement = row.querySelector('h5');
    const quantity = parseInt(quantityInput.value);
    const price = parseFloat(priceElement.innerText.slice(2));
    const category = categorySelect.value;
    const name = nameElement.textContent;
    const item = new BurgerCartItem(name, category, quantity, price);

    // Check if the item already exists in the cart
    const existingItem = cartItems.find(i => i.type === item.type && i.category === item.category);
    if (existingItem) {
      // Update the quantity of the existing item
      existingItem.quantity += item.quantity;
    } else {
      // Add the new item to the cart
      cartItems.push(item);
    }

    console.log(cartItems);
    localStorage.setItem("cartData", JSON.stringify(cartItems));
    quantityInput.value = "";
    categorySelect.value = "Veg";
    alert("Item Added to Cart!");
  });
})

btnViewCart.addEventListener("click", function() {
  // You can now access the `cartItems` array to display the cart contents
  window.location.href = "./cart.html";
});
