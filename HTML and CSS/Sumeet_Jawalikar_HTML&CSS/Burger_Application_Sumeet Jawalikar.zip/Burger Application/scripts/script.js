const form = document.getElementById("form");
form.onsubmit = function (e) {
  e.preventDefault();
  const err = document.getElementById("err"); // Select the correct element
  err.textContent = ""; // Set the error message
  const inputNumber = document.getElementById("mobileNumber");
  const len = inputNumber.value.length;
  if (len !== 10) {
    err.textContent = "Enter the 10-digit number";
    return;
  }
  // const formUrl = './burgersPage';
  inputNumber.value = "";
  window.location.href = "./burgersPage.html";
};
